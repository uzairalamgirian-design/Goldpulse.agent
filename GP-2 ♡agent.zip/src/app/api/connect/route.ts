import { NextResponse } from "next/server";
import { getConnections, maskSecret, updateConnection } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await getConnections();
  return NextResponse.json(
    {
      connections: rows.map((c) => ({
        id: c.id,
        kind: c.kind,
        label: c.label,
        endpoint: c.endpoint,
        account: c.account,
        secretMasked: c.secretMasked || maskSecret(c.account),
        symbol: c.symbol,
        suffix: c.suffix,
        status: c.status,
        enabled: c.enabled,
        lastHeartbeat: c.lastHeartbeat,
        spread: c.spread,
        latencyMs: c.latencyMs,
      })),
    },
    { headers: { "cache-control": "no-store" } },
  );
}

export async function POST(req: Request) {
  try {
    const b = await req.json();
    const id = String(b.id);
    const patch: Record<string, unknown> = {};
    if (typeof b.enabled === "boolean") patch.enabled = b.enabled;
    if (typeof b.label === "string") patch.label = b.label;
    if (typeof b.endpoint === "string") patch.endpoint = b.endpoint;
    if (typeof b.account === "string") patch.account = b.account;
    if (typeof b.symbol === "string") patch.symbol = b.symbol;
    if (typeof b.suffix === "string") patch.suffix = b.suffix;
    if (typeof b.status === "string") patch.status = b.status;
    if (typeof b.secret === "string" && b.secret.length) patch.secretMasked = maskSecret(b.secret);
    patch.lastHeartbeat = new Date();
    const rows = await updateConnection(id, patch);
    return NextResponse.json({ ok: true, count: rows.length });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}
