import { NextResponse } from "next/server";
import { getSettings, saveSettings } from "@/lib/store";
import type { Settings } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET() {
  const settings = await getSettings();
  return NextResponse.json({ settings }, { headers: { "cache-control": "no-store" } });
}

export async function PUT(req: Request) {
  try {
    const body = (await req.json()) as Partial<Settings>;
    const current = await getSettings();
    const merged: Settings = {
      ...current,
      ...body,
      gates: { ...current.gates, ...(body.gates ?? {}) },
      alerts: { ...current.alerts, ...(body.alerts ?? {}) },
    };
    await saveSettings(merged);
    return NextResponse.json({ settings: merged });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}
