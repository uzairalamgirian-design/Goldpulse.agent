import { NextResponse } from "next/server";
import { engineView, sessionAt, scenarioRemaining } from "@/lib/market";

export const dynamic = "force-dynamic";

export async function GET() {
  const now = Date.now();
  const view = engineView();
  const session = sessionAt(new Date(now));
  return NextResponse.json({
    status: "ok",
    service: "goldpulse-30-agent",
    version: "1.4.0",
    ts: now,
    uptimeSec: Math.round(process.uptime()),
    feed: {
      source: "XAUUSD Live-Simulation Engine",
      price: view.price,
      session: session.label,
      ticks: view.ticks.length,
    },
    scenarioActiveMs: scenarioRemaining(),
  });
}
