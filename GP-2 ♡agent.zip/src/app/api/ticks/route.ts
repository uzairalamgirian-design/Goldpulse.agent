import { NextResponse } from "next/server";
import { buildSnapshot } from "@/lib/confluence";
import { armScenario, scenarioRemaining } from "@/lib/market";
import { drawdownLock, getSettings, seedSignalsIfEmpty } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await seedSignalsIfEmpty();
    const settings = await getSettings();
    const lock = await drawdownLock(settings);
    const snap = buildSnapshot(settings, { locked: lock.locked, reason: lock.reason });
    return NextResponse.json(
      { snapshot: snap, lock },
      { headers: { "cache-control": "no-store, max-age=0" } },
    );
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    if (body.action === "scenario") {
      armScenario(body.dir === "SELL" ? -1 : 1, Number(body.durationMs) || 180_000);
      return NextResponse.json({ ok: true, scenarioActiveMs: scenarioRemaining() });
    }
    if (body.action === "capture") {
      const settings = await getSettings();
      const lock = await drawdownLock(settings);
      const captureId = `snap-${Date.now().toString(36)}-${Math.floor(Math.random() * 1e4).toString(36)}`;
      const snap = buildSnapshot(settings, { locked: lock.locked, reason: lock.reason }, captureId);
      return NextResponse.json({ snapshot: snap, lock, captureId }, { headers: { "cache-control": "no-store" } });
    }
    return NextResponse.json({ error: "unknown action" }, { status: 400 });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}
