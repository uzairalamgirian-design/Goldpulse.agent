import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { signals } from "@/db/schema";
import { listSignals, seedSignalsIfEmpty, stats } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await seedSignalsIfEmpty();
    const [rows, s] = await Promise.all([listSignals(), stats()]);
    return NextResponse.json({ signals: rows, stats: s }, { headers: { "cache-control": "no-store" } });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const b = await req.json();
    const id = `sig-${Date.now().toString(36)}-${Math.floor(Math.random() * 1e4).toString(36)}`;
    await db.insert(signals).values({
      id,
      symbol: b.symbol ?? "XAUUSDc",
      broker: b.broker ?? "Sim",
      accountMode: b.accountMode ?? "cent",
      direction: b.direction,
      score: String(b.score),
      entry: String(b.entry),
      entryLow: String(b.entryLow ?? b.entry),
      entryHigh: String(b.entryHigh ?? b.entry),
      sl: String(b.sl),
      tp1: String(b.tp1),
      tp2: String(b.tp2),
      tp3: String(b.tp3),
      lotSize: String(b.lotSize),
      riskUsd: String(b.riskUsd),
      rr: String(b.rr ?? 2.5),
      session: b.session ?? "—",
      outcome: "pending",
      pnlUsd: "0",
      gates: b.gates ?? [],
      note: b.note ?? null,
    });
    return NextResponse.json({ ok: true, id });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}

export async function PATCH(req: Request) {
  try {
    const b = await req.json();
    const outcome = String(b.outcome);
    const pnl = Number(b.pnlUsd ?? 0);
    await db
      .update(signals)
      .set({ outcome, pnlUsd: String(pnl), note: b.note ?? undefined })
      .where(eq(signals.id, String(b.id)));
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}
