import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "GoldPulse $30 Agent — XAUUSD 99.9% Signals",
    short_name: "GoldPulse",
    description:
      "24/7 XAUUSD / XAUUSDc multi-timeframe confluence agent with a $30 small-account risk guard. Alerts only at 99.9% confirmation.",
    id: "/",
    start_url: "/",
    scope: "/",
    display: "standalone",
    display_override: ["standalone", "fullscreen", "minimal-ui"],
    orientation: "portrait",
    categories: ["finance", "productivity", "utilities"],
    background_color: "#07080B",
    theme_color: "#07080B",
    icons: [
      { src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any" },
      { src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "maskable" },
    ],
  };
}
