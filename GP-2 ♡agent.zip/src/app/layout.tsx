import type { Metadata, Viewport } from "next";
import { Archivo, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const archivo = Archivo({
  subsets: ["latin"],
  variable: "--font-archivo",
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
  display: "swap",
});

export const metadata: Metadata = {
  title: "GoldPulse $30 Agent — XAUUSD 99.9% Confirmation Signals",
  description:
    "Mobile-installable 24/7 XAUUSD / XAUUSDc signal agent. Strict multi-timeframe confluence, 8 gold safety gates, and a $30 small-account risk guard. Alerts only at 99.9% confirmation.",
  applicationName: "GoldPulse",
  manifest: "/manifest",
  keywords: ["XAUUSD", "gold", "trading signals", "Exness", "XM", "MT5", "risk management", "PWA"],
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "GoldPulse",
  },
  formatDetection: { telephone: false },
  icons: { icon: [{ url: "/icon.svg", type: "image/svg+xml" }] },
};

export const viewport: Viewport = {
  themeColor: "#07080B",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${archivo.variable} ${jetbrains.variable}`}>
      <body className="min-h-[100dvh] bg-void text-bone antialiased">{children}</body>
    </html>
  );
}
