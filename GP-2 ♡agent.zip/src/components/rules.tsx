"use client";

import { Btn, IconWarn, Micro, Panel, Pill, Rule, Segmented, Slider, Toggle } from "@/components/ui";
import type { Settings } from "@/lib/types";

const GATE_LABELS: Array<{ id: string; label: string; hint: string }> = [
  { id: "h4", label: "H4 higher-timeframe trend bias", hint: "Price structure + EMA 50/200 must agree before anything else is considered." },
  { id: "h1", label: "H1 trend & EMA alignment", hint: "Trend-side positioning of price relative to the H1 EMA 50." },
  { id: "m15", label: "M15 pullback to dynamic value", hint: "Retest of the EMA 21 / structure zone rather than chasing a breakout." },
  { id: "m5", label: "M5 candlestick confirmation", hint: "Engulfing, pin bar or marubozu close in the direction of the bias." },
  { id: "indicators", label: "EMA ribbon · RSI · MACD · ADX", hint: "Ribbon stack, momentum band, histogram alignment and ADX > 22." },
  { id: "rr", label: "ATR stop geometry · minimum R:R", hint: "Volatility-adjusted stop with reward of at least your minimum multiple." },
  { id: "session", label: "Session & liquidity filter", hint: "Prioritises London and the London/New York overlap." },
  { id: "safety", label: "Spread spike · USD news · drawdown lock", hint: "Hard vetoes — any one of these silences the agent." },
];

export function RulesScreen({
  settings,
  patch,
  onReset,
}: {
  settings: Settings;
  patch: (p: Partial<Settings>) => void;
  onReset: () => void;
}) {
  const cent = settings.accountMode === "cent";

  return (
    <div className="space-y-3 pb-4">
      <Panel title="Broker & Account Math" right={<Pill tone="gold">{cent ? "3,000 USC" : "$30.00 USD"}</Pill>}>
        <Segmented
          options={[
            { value: "cent" as const, label: "Exness Cent", sub: "XAUUSDc · 3,000 USC" },
            { value: "standard" as const, label: "Standard", sub: "XAUUSD · $30 USD" },
          ]}
          value={settings.accountMode}
          onChange={(v) =>
            patch(
              v === "cent"
                ? { accountMode: "cent", symbol: "XAUUSDc", balance: 3000, maxRiskUsd: 1.5 }
                : { accountMode: "standard", symbol: "XAUUSD", balance: 30, maxRiskUsd: 1.5 },
            )
          }
        />
        <div className="px-3 py-3 text-[10.5px] leading-[1.6] text-graphite">
          {cent ? (
            <>
              Standard Cent quotes gold as <span className="num text-gold">XAUUSDc</span>. Your balance reads{" "}
              <span className="num text-gold">3,000 USC</span> but the dollar risk is identical to a $30 account — every lot-size calculation
              below is expressed in USD and displayed in USC.
            </>
          ) : (
            <>
              Standard accounts quote <span className="num text-gold">XAUUSD</span> on a $30 USD balance. The minimum tradable size is{" "}
              <span className="num text-gold">0.01 lot</span> (1 oz), so a $1.00 stop costs $1.00 — that is already 3.3% of the account. Keep
              stops tight or stand aside.
            </>
          )}
        </div>
      </Panel>

      <Panel title="Confirmation Threshold">
        <Slider
          label="Alert threshold"
          value={settings.threshold}
          min={90}
          max={100}
          step={0.1}
          onChange={(v) => patch({ threshold: v })}
          format={(v) => `${v.toFixed(1)}%`}
          hint="99.9% demands all eight gates green with no compromise. Anything lower will fire on ordinary trend days."
        />
        <Slider
          label="Alert cooldown"
          value={settings.cooldownMin}
          min={0}
          max={240}
          step={5}
          onChange={(v) => patch({ cooldownMin: v })}
          format={(v) => `${v} min`}
          hint="Minimum silence between two alerts so one session cannot flood your phone."
        />
      </Panel>

      <Panel title="Beginner Alert Settings">
        <Slider
          label="Win-rate alert threshold"
          value={settings.alertThreshold}
          min={50}
          max={99.9}
          step={0.1}
          onChange={(v) => patch({ alertThreshold: v })}
          format={(v) => `${v.toFixed(1)}%`}
          hint="Only setups at or above this win confirmation rate will alert you. 85% is the recommended high-confidence level."
        />
        <Toggle
          on={settings.urgentAlerts}
          onChange={(v) => patch({ urgentAlerts: v })}
          label="Urgent multi-ping alert mode"
          hint="When RSI hits <30 or >70 and a confirmed pattern lines up, a full-screen banner plus an alarm repeats every 5 seconds until you acknowledge it."
        />
        <Toggle
          on={settings.mode === "xm"}
          onChange={(v) => patch({ mode: v ? "xm" : "preview", xm: { ...settings.xm, connected: v } })}
          label="Read charts from my XM account"
          hint="Off = Preview Snapshot Mode using the built-in simulator. On = the analyzer reads your connected XM bridge feed continuously."
        />
      </Panel>

      <Panel title="$30 Risk Protection">
        <Slider
          label="Max risk per trade"
          value={settings.riskPct}
          min={0.5}
          max={5}
          step={0.1}
          onChange={(v) => patch({ riskPct: v })}
          format={(v) => `${v.toFixed(1)}%`}
          hint={`Hard cap: ${cent ? (settings.maxRiskUsd * 100).toFixed(0) + " USC" : "$" + settings.maxRiskUsd.toFixed(2)} per trade regardless of percentage.`}
        />
        <Slider
          label="Hard risk cap"
          value={settings.maxRiskUsd}
          min={0.25}
          max={3}
          step={0.05}
          onChange={(v) => patch({ maxRiskUsd: v })}
          format={(v) => (cent ? `${(v * 100).toFixed(0)} USC` : `$${v.toFixed(2)}`)}
          hint="The absolute dollar ceiling on stop-loss damage for a single position."
        />
        <Slider
          label="Minimum reward multiple"
          value={settings.minRR}
          min={1.5}
          max={4}
          step={0.1}
          onChange={(v) => patch({ minRR: v })}
          format={(v) => `1 : ${v.toFixed(1)}`}
          hint="Setups whose ATR geometry cannot deliver this multiple are rejected outright."
        />
        <Slider
          label="Minimum lot"
          value={settings.minLot}
          min={0.01}
          max={0.1}
          step={0.01}
          onChange={(v) => patch({ minLot: v, lotStep: v })}
          format={(v) => `${v.toFixed(2)} lot`}
          hint="Exness Standard Cent and XM Micro both allow 0.01 lot. Some brokers only offer 0.10 on standard accounts."
        />
      </Panel>

      <Panel title="Daily Drawdown Lock">
        <Slider
          label="Consecutive losses before lockout"
          value={settings.maxConsecutiveLosses}
          min={1}
          max={5}
          step={1}
          onChange={(v) => patch({ maxConsecutiveLosses: v })}
          format={(v) => `${v} in a row`}
          hint="When this many losing signals occur consecutively, alerts pause until the next trading day."
        />
        <Slider
          label="Daily drawdown lock"
          value={settings.dailyDrawdownPct}
          min={3}
          max={25}
          step={1}
          onChange={(v) => patch({ dailyDrawdownPct: v })}
          format={(v) => `${v}%`}
          hint={`On a $30 balance a 10% daily drawdown is $3.00 — three bad trades. The lock protects the remaining equity.`}
        />
      </Panel>

      <Panel title="Gold Market Safety Gates">
        <Toggle
          on={settings.sessionFilter}
          onChange={(v) => patch({ sessionFilter: v })}
          label="Session filter"
          hint="Block or down-weight signals during the thin rollover window and the Asian range."
        />
        <Toggle
          on={settings.spreadGuard}
          onChange={(v) => patch({ spreadGuard: v })}
          label="Spread spike guard"
          hint="Veto any signal when the live XAUUSD spread widens beyond the 0.45 guard."
        />
        <Toggle
          on={settings.newsFilter}
          onChange={(v) => patch({ newsFilter: v })}
          label="High-impact USD news filter"
          hint="Pause alerts 30 minutes before and after NFP, CPI, FOMC decisions and Fed speeches."
        />
      </Panel>

      <Panel title="Eight Confluence Gates">
        {GATE_LABELS.map((g) => (
          <Toggle
            key={g.id}
            on={settings.gates[g.id] !== false}
            onChange={(v) => patch({ gates: { ...settings.gates, [g.id]: v } })}
            label={g.label}
            hint={g.hint}
          />
        ))}
      </Panel>

      <Panel title="Alert Delivery">
        <Toggle on={settings.alerts.push} onChange={(v) => patch({ alerts: { ...settings.alerts, push: v } })} label="High-priority push notification" hint="Delivered through the installed PWA even when the screen is locked." />
        <Toggle on={settings.alerts.sound} onChange={(v) => patch({ alerts: { ...settings.alerts, sound: v } })} label="Loud audio chime" hint="Four-tone ascending alert, distinct from any other app on the phone." />
        <Toggle on={settings.alerts.vibrate} onChange={(v) => patch({ alerts: { ...settings.alerts, vibrate: v } })} label="Haptic vibration" hint="Double-pulse pattern so a phone face-down on the desk still gets your attention." />
        <Toggle on={settings.alerts.wakeLock} onChange={(v) => patch({ alerts: { ...settings.alerts, wakeLock: v } })} label="Screen wake lock while watching" hint="Stops the phone sleeping during an active watch session. Uses more battery." />
      </Panel>

      <Panel title="Reset">
        <div className="flex items-center justify-between gap-3 px-3 py-3">
          <p className="text-[10.5px] leading-[1.55] text-slate">
            Restores the default 99.9% threshold, 2% risk and all eight gates enabled.
          </p>
          <Btn variant="danger" onClick={onReset}>Reset</Btn>
        </div>
      </Panel>

      <div className="border border-golddk/40 bg-golddk/8 px-3 py-3">
        <div className="flex items-start gap-2">
          <IconWarn size={15} className="mt-[1px] shrink-0 text-gold" />
          <div>
            <Micro className="text-gold">Risk disclaimer</Micro>
            <p className="mt-1.5 text-[10.5px] leading-[1.6] text-graphite">
              A 99.9% score describes technical confluence across timeframes and indicators. It is <strong className="text-bone">not</strong> a
              guarantee of profit and does not account for slippage, requotes, execution latency or broker-side events. Gold CFDs are leveraged
              products with a high risk of rapid loss — on a $30 balance a single oversized position can liquidate the account. Signals are for
              manual execution only; GoldPulse never places orders on your behalf.
            </p>
          </div>
        </div>
      </div>

      <Rule />
    </div>
  );
}
