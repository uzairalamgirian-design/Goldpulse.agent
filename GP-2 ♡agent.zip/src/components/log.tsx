"use client";

import { BalanceCurve } from "@/components/chart";
import { Btn, Micro, Panel, Pill, Rule, Stat } from "@/components/ui";

export interface SignalDTO {
  id: string;
  createdAt: string;
  symbol: string;
  broker: string;
  accountMode: string;
  direction: string;
  score: string;
  entry: string;
  entryLow: string;
  entryHigh: string;
  sl: string;
  tp1: string;
  tp2: string;
  tp3: string;
  lotSize: string;
  riskUsd: string;
  rr: string;
  session: string;
  outcome: string;
  pnlUsd: string;
  gates: unknown;
  note: string | null;
}

export interface StatsDTO {
  total: number;
  closed: number;
  wins: number;
  losses: number;
  winRate: number;
  netPnl: number;
  skipped: number;
}

export function LogScreen({
  signals,
  stats,
  startBalance,
  accountMode,
  onOutcome,
}: {
  signals: SignalDTO[];
  stats: StatsDTO;
  startBalance: number;
  accountMode: "cent" | "standard";
  onOutcome: (id: string, outcome: "win" | "loss" | "skipped") => void;
}) {
  const cent = accountMode === "cent";
  const money = (usd: number) => (cent ? `${(usd * 100).toFixed(2)} USC` : `$${usd.toFixed(2)}`);

  const ordered = [...signals].sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt));
  const curve: number[] = [30];
  for (const s of ordered) {
    if (s.outcome === "skipped" || s.outcome === "pending") continue;
    curve.push(Math.max(0, curve[curve.length - 1] + Number(s.pnlUsd ?? 0)));
  }
  const equity = curve[curve.length - 1];
  const growth = ((equity - 30) / 30) * 100;

  return (
    <div className="space-y-3 pb-4">
      <Panel title="$30 Growth Tracker" right={<Pill tone={growth >= 0 ? "up" : "down"}>{growth >= 0 ? "+" : ""}{growth.toFixed(1)}%</Pill>}>
        <div className="grid grid-cols-3 gap-px bg-rule">
          <Stat label="Tracked equity" value={`$${equity.toFixed(2)}`} sub={cent ? `${(equity * 100).toFixed(0)} USC` : "USD balance"} tone={growth >= 0 ? "up" : "down"} />
          <Stat label="Net P&L" value={money(stats.netPnl)} sub={`${stats.total} alerts logged`} tone={stats.netPnl >= 0 ? "up" : "down"} />
          <Stat label="Win rate" value={`${stats.winRate.toFixed(1)}%`} sub={`${stats.wins}W · ${stats.losses}L · ${stats.skipped} skipped`} tone="gold" />
        </div>
        <div className="px-3 pb-3 pt-1">
          <BalanceCurve points={curve} start={startBalance} />
        </div>
      </Panel>

      <Panel
        title="Signal History"
        right={<span className="num text-[10px] text-slate">every 99.9% alert</span>}
      >
        {signals.length === 0 ? (
          <div className="px-3 py-8 text-center">
            <Micro>No signals logged yet</Micro>
            <p className="mt-2 text-[11px] leading-[1.6] text-slate">
              The log fills the moment the confirmation engine crosses the threshold and you record the trade.
            </p>
          </div>
        ) : (
          signals.map((s) => {
            const dirUp = s.direction === "BUY";
            const outcomeTone = s.outcome === "win" ? "up" : s.outcome === "loss" ? "down" : s.outcome === "skipped" ? "neutral" : "gold";
            return (
              <article key={s.id} className="border-b border-rule">
                <div className="flex items-start justify-between gap-2 px-3 py-2.5">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`num text-[13px] font-bold ${dirUp ? "text-up" : "text-down"}`}>{s.direction}</span>
                      <span className="num text-[11px] text-bone">{s.symbol}</span>
                      <span className="num text-[10px] text-gold">{Number(s.score).toFixed(2)}%</span>
                    </div>
                    <div className="num mt-1 text-[10px] leading-[1.6] text-graphite">
                      E {Number(s.entry).toFixed(2)} · SL {Number(s.sl).toFixed(2)} · TP {Number(s.tp2).toFixed(2)}
                    </div>
                    <div className="num mt-0.5 text-[9.5px] leading-[1.6] text-slate">
                      {s.lotSize} lot · risk {money(Number(s.riskUsd))} · 1:{Number(s.rr).toFixed(1)} · {s.session}
                    </div>
                    <div className="mt-1 text-[9.5px] leading-[1.5] text-slate">
                      {new Date(s.createdAt).toLocaleString(undefined, { month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit" })} · {s.note ?? "—"}
                    </div>
                  </div>
                  <div className="shrink-0 text-right">
                    <Pill tone={outcomeTone as "up" | "down" | "neutral" | "gold"}>{s.outcome}</Pill>
                    <div className={`num mt-1.5 text-[12px] ${Number(s.pnlUsd) > 0 ? "text-up" : Number(s.pnlUsd) < 0 ? "text-down" : "text-slate"}`}>
                      {Number(s.pnlUsd) > 0 ? "+" : ""}
                      {money(Number(s.pnlUsd))}
                    </div>
                  </div>
                </div>
                {s.outcome === "pending" ? (
                  <div className="grid grid-cols-3 gap-px border-t border-rule bg-rule">
                    <Btn variant="ghost" className="rounded-none border-0 bg-panel py-2" onClick={() => onOutcome(s.id, "win")}>Win</Btn>
                    <Btn variant="ghost" className="rounded-none border-0 bg-panel py-2" onClick={() => onOutcome(s.id, "loss")}>Loss</Btn>
                    <Btn variant="ghost" className="rounded-none border-0 bg-panel py-2" onClick={() => onOutcome(s.id, "skipped")}>Skipped</Btn>
                  </div>
                ) : (
                  <div className="flex gap-px border-t border-rule bg-rule">
                    {(["win", "loss", "skipped"] as const).map((o) => (
                      <button
                        key={o}
                        type="button"
                        onClick={() => onOutcome(s.id, o)}
                        className={`flex-1 py-1.5 text-[9px] font-semibold tracking-[0.14em] uppercase transition-colors ${
                          s.outcome === o ? "bg-gold/18 text-gold" : "bg-panel text-slate hover:text-bone"
                        }`}
                      >
                        {o}
                      </button>
                    ))}
                  </div>
                )}
              </article>
            );
          })
        )}
      </Panel>

      <Panel title="Session Breakdown">
        {["London / New York Overlap", "London Session", "New York Session", "Asian Session"].map((label) => {
          const rows = signals.filter((s) => s.session === label);
          const wins = rows.filter((s) => s.outcome === "win").length;
          const closed = rows.filter((s) => s.outcome === "win" || s.outcome === "loss").length;
          const rate = closed ? (wins / closed) * 100 : 0;
          return (
            <div key={label} className="flex items-center gap-3 border-b border-rule px-3 py-2.5">
              <div className="min-w-0 flex-1">
                <div className="text-[11px] text-bone">{label}</div>
                <div className="mt-1 h-[3px] w-full bg-void">
                  <div className="h-full bg-gold transition-[width] duration-300" style={{ width: `${rate}%` }} />
                </div>
              </div>
              <div className="num shrink-0 text-[11px] text-graphite">
                {wins}/{closed} · {rate.toFixed(0)}%
              </div>
            </div>
          );
        })}
      </Panel>

      <div className="px-1 text-[10px] leading-[1.6] text-slate">
        Balance curve starts at $30.00 and replays recorded outcomes only. Simulated results do not include spread, swap or slippage.
      </div>
      <Rule />
    </div>
  );
}
