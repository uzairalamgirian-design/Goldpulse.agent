"use client";

import { useState } from "react";
import {
  Btn,
  Field,
  IconBell,
  IconCheck,
  IconDownload,
  IconLock,
  IconPlug,
  IconRefresh,
  IconSpeaker,
  IconWarn,
  Micro,
  Panel,
  Pill,
  Rule,
} from "@/components/ui";

export interface ConnectionDTO {
  id: string;
  kind: string;
  label: string;
  endpoint: string | null;
  account: string | null;
  secretMasked: string | null;
  symbol: string;
  suffix: string;
  status: string;
  enabled: boolean;
  lastHeartbeat: string | null;
  spread: string | number | null;
  latencyMs: number | null;
}

export interface TestResult {
  id: string;
  latencyMs: number;
  spread: number;
  spreadPoints: number;
  session: string;
  liquidity: string;
  status: string;
  notes: string;
  price: number;
}

const KIND_COPY: Record<string, { title: string; blurb: string; fields: string[] }> = {
  exness: {
    title: "Exness Connector",
    blurb:
      "REST/WebSocket trading terminal for Standard Cent (XAUUSDc, recommended for a $30 balance) and Standard (XAUUSD). Credentials are held server-side and only ever returned masked.",
    fields: ["Server", "Trading account", "API secret"],
  },
  xm: {
    title: "XM · MT4 / MT5 Webhook Bridge",
    blurb:
      "An Expert Advisor on your MT4/MT5 terminal forwards ticks and candles to this webhook. Symbol suffix mapping resolves XAUUSD, XAUUSDm, XAUUSD# and XAUUSDc to a single instrument.",
    fields: ["Webhook endpoint", "Login ID", "Bridge token"],
  },
  sim: {
    title: "XAUUSD Live-Simulation & Replay Engine",
    blurb:
      "Session-aware gold price engine with London breakouts, New York pullbacks and scripted news spikes. Runs entirely on-device so you can test the 99.9% trigger and the $30 position sizer immediately.",
    fields: ["Engine", "Scenario profile"],
  },
};

export function ConnectScreen({
  connections,
  testResult,
  testingId,
  onTest,
  onUpdate,
  onInstall,
  canInstall,
  standalone,
  onNotifyTest,
  onSoundTest,
  onVibrateTest,
}: {
  connections: ConnectionDTO[];
  testResult: TestResult | null;
  testingId: string | null;
  onTest: (id: string) => void;
  onUpdate: (id: string, patch: Record<string, unknown>) => void;
  onInstall: () => void;
  canInstall: boolean;
  standalone: boolean;
  onNotifyTest: () => void;
  onSoundTest: () => void;
  onVibrateTest: () => void;
}) {
  const [editing, setEditing] = useState<string | null>(null);
  const [draftSecret, setDraftSecret] = useState("");

  return (
    <div className="space-y-3 pb-4">
      {/* ── install band ── */}
      <section className="relative overflow-hidden border border-golddk/40">
        <img
          src="images/desk-atmosphere.jpg"
          alt=""
          aria-hidden
          className="absolute inset-0 h-full w-full object-cover object-left opacity-45"
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).style.display = "none";
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-void via-void/85 to-void/25" />
        <div className="relative px-4 py-5">
          <Micro className="text-gold">Install on your phone</Micro>
          <h2 className="mt-2 text-[26px] leading-[1.05] font-extrabold tracking-[-0.02em] text-bone">
            Keep the agent in your
            <br />
            pocket, awake all session.
          </h2>
          <p className="mt-2.5 max-w-[46ch] text-[11.5px] leading-[1.65] text-graphite">
            GoldPulse installs as a standalone home-screen app. It launches full-screen without a browser bar, keeps the watch loop running, and
            raises high-priority push alerts with a chime and haptic pulse the moment a setup reaches the threshold.
          </p>
          <div className="mt-3.5 flex flex-wrap gap-2">
            {standalone ? (
              <Pill tone="up"><IconCheck size={12} /> Installed &amp; running standalone</Pill>
            ) : (
              <Btn variant="gold" onClick={onInstall} disabled={!canInstall}>
                <IconDownload size={14} /> {canInstall ? "Add to home screen" : "Use your browser menu"}
              </Btn>
            )}
          </div>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            {[
              { os: "iOS · Safari", steps: "Share ▸ Add to Home Screen ▸ Add. Then allow notifications when the app first opens." },
              { os: "Android · Chrome", steps: "Menu ▸ Install app ▸ Install. Pin it to your home screen for one-tap access." },
            ].map((p) => (
              <div key={p.os} className="border border-rule bg-void/70 px-3 py-2.5">
                <Micro className="text-gold">{p.os}</Micro>
                <p className="mt-1.5 text-[10.5px] leading-[1.55] text-graphite">{p.steps}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── connectors ── */}
      {connections.map((c) => {
        const copy = KIND_COPY[c.kind] ?? KIND_COPY.sim;
        const tone = c.status === "connected" ? "up" : c.status === "degraded" ? "gold" : "neutral";
        return (
          <Panel
            key={c.id}
            title={copy.title}
            right={
              <div className="flex items-center gap-2">
                <Pill tone={tone as "up" | "gold" | "neutral"}>{c.status}</Pill>
                <button
                  type="button"
                  onClick={() => onUpdate(c.id, { enabled: !c.enabled })}
                  className={`relative h-[18px] w-[38px] border transition-colors ${c.enabled ? "border-gold bg-gold/25" : "border-rule2 bg-void"}`}
                  aria-label={`Toggle ${copy.title}`}
                >
                  <span className={`absolute top-[2px] h-[12px] w-[16px] transition-all duration-150 ${c.enabled ? "left-[19px] bg-gold" : "left-[2px] bg-slate"}`} />
                </button>
              </div>
            }
          >
            <p className="px-3 py-2.5 text-[10.5px] leading-[1.6] text-graphite">{copy.blurb}</p>

            <Field label="Endpoint" value={c.endpoint ?? ""} onChange={(v) => onUpdate(c.id, { endpoint: v })} />
            <Field label="Account / login" value={c.account ?? ""} onChange={(v) => onUpdate(c.id, { account: v })} />
            <div className="border-b border-rule px-3 py-2.5">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <Micro>API secret</Micro>
                  <div className="num mt-1.5 flex items-center gap-2 text-[13px] text-bone">
                    <IconLock size={13} className="shrink-0 text-gold" />
                    <span className="truncate">{c.secretMasked || "not configured"}</span>
                  </div>
                </div>
                <Btn variant="quiet" onClick={() => setEditing(editing === c.id ? null : c.id)}>
                  {editing === c.id ? "Cancel" : "Replace"}
                </Btn>
              </div>
              {editing === c.id ? (
                <div className="mt-2 flex gap-2">
                  <input
                    type="password"
                    value={draftSecret}
                    onChange={(e) => setDraftSecret(e.target.value)}
                    placeholder="paste new secret — stored masked"
                    className="num flex-1 border border-rule bg-void px-2 py-2 text-[12px] text-bone placeholder:text-slate/60 focus:border-gold focus:outline-none"
                  />
                  <Btn
                    variant="gold"
                    onClick={() => {
                      onUpdate(c.id, { secret: draftSecret });
                      setDraftSecret("");
                      setEditing(null);
                    }}
                  >
                    Save
                  </Btn>
                </div>
              ) : null}
            </div>

            <div className="grid grid-cols-3 gap-px bg-rule">
              <div className="bg-panel px-3 py-2.5">
                <Micro>Symbol</Micro>
                <div className="num mt-1 text-[13px] text-bone">{c.symbol}</div>
                <div className="mt-1 text-[9px] text-slate">suffix “{c.suffix || "none"}”</div>
              </div>
              <div className="bg-panel px-3 py-2.5">
                <Micro>Spread</Micro>
                <div className="num mt-1 text-[13px] text-gold">{c.spread != null ? Number(c.spread).toFixed(2) : "—"}</div>
                <div className="mt-1 text-[9px] text-slate">{c.spread != null ? `${Math.round(Number(c.spread) * 100)} points` : "not sampled"}</div>
              </div>
              <div className="bg-panel px-3 py-2.5">
                <Micro>Latency</Micro>
                <div className="num mt-1 text-[13px] text-bone">{c.latencyMs != null ? `${c.latencyMs} ms` : "—"}</div>
                <div className="mt-1 text-[9px] text-slate">bridge round-trip</div>
              </div>
            </div>

            <div className="flex items-center gap-2 border-t border-rule px-3 py-2.5">
              <Btn variant="ghost" onClick={() => onTest(c.id)} disabled={testingId === c.id}>
                <IconRefresh size={13} /> {testingId === c.id ? "Testing…" : "Run connection test"}
              </Btn>
              <span className="num text-[9.5px] text-slate">
                heartbeat {c.lastHeartbeat ? new Date(c.lastHeartbeat).toLocaleTimeString() : "—"}
              </span>
            </div>

            {testResult && testResult.id === c.id ? (
              <div className="border-t border-rule bg-gold/8 px-3 py-2.5">
                <div className="flex items-center gap-2">
                  <IconCheck size={13} className="text-up" />
                  <span className="micro text-gold">Test result</span>
                </div>
                <div className="num mt-2 grid grid-cols-3 gap-2 text-[11px] text-bone">
                  <span>latency {testResult.latencyMs} ms</span>
                  <span>spread {testResult.spread.toFixed(2)}</span>
                  <span>bid/ask {testResult.price.toFixed(2)}</span>
                </div>
                <p className="mt-2 text-[10px] leading-[1.55] text-graphite">
                  {testResult.session} · {testResult.liquidity} liquidity — {testResult.notes}
                </p>
              </div>
            ) : null}
          </Panel>
        );
      })}

      {/* ── alert delivery ── */}
      <Panel title="Phone Alert Delivery Test" right={<IconBell size={14} className="text-gold" />}>
        <p className="px-3 py-2.5 text-[10.5px] leading-[1.6] text-graphite">
          Run all three before you rely on overnight monitoring. The notification is delivered by the service worker, so it appears even when the
          app is not in the foreground.
        </p>
        <div className="grid grid-cols-3 gap-px border-t border-rule bg-rule">
          <Btn variant="ghost" className="rounded-none border-0 bg-panel py-3" onClick={onNotifyTest}>
            <IconBell size={14} /> Push
          </Btn>
          <Btn variant="ghost" className="rounded-none border-0 bg-panel py-3" onClick={onSoundTest}>
            <IconSpeaker size={14} /> Chime
          </Btn>
          <Btn variant="ghost" className="rounded-none border-0 bg-panel py-3" onClick={onVibrateTest}>
            <IconRefresh size={14} /> Haptic
          </Btn>
        </div>
      </Panel>

      {/* ── 24/7 notes ── */}
      <Panel title="Keeping the Watch Alive 24/7">
        <ol className="px-3 py-2.5">
          {[
            "Grant the notification permission on first launch — iOS prompts only once.",
            "Enable the screen wake lock in Rules while a session is live, or keep the phone on charge.",
            "iOS suspends background tabs aggressively: keep the installed app open, or run the same account against the cloud worker endpoint in Connect ▸ Endpoint.",
            "Android Chrome keeps the service worker alive far longer; a pinned PWA will usually hold the socket for the whole New York session.",
            "The watch loop auto-reconnects with exponential backoff and resumes the confluence evaluation from the last complete candle.",
          ].map((t, i) => (
            <li key={i} className="flex gap-2.5 border-b border-rule py-2.5 last:border-0">
              <span className="num shrink-0 text-[10px] text-gold">{String(i + 1).padStart(2, "0")}</span>
              <span className="text-[10.5px] leading-[1.6] text-graphite">{t}</span>
            </li>
          ))}
        </ol>
      </Panel>

      {/* ── security ── */}
      <Panel title="Security &amp; Credential Handling">
        <div className="flex items-start gap-2 px-3 py-3">
          <IconLock size={15} className="mt-[1px] shrink-0 text-gold" />
          <p className="text-[10.5px] leading-[1.6] text-graphite">
            Every key is masked at the API boundary — the browser only ever receives a masked suffix, never the raw secret. Credentials are read from
            server-side environment variables and are never hard-coded, logged or shipped in the client bundle. GoldPulse has no order-placement
            permission: it can read quotes and emit alerts, nothing more.
          </p>
        </div>
      </Panel>

      {/* ── disclaimer ── */}
      <div className="relative overflow-hidden border border-down/35">
        <img
          src="images/panel-texture.jpg"
          alt=""
          aria-hidden
          className="absolute inset-0 h-full w-full object-cover opacity-25"
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).style.display = "none";
          }}
        />
        <div className="absolute inset-0 bg-void/80" />
        <div className="relative flex items-start gap-2.5 px-3.5 py-3.5">
          <IconWarn size={16} className="mt-[1px] shrink-0 text-down" />
          <div>
            <Micro className="text-down">Risk disclaimer</Micro>
            <p className="mt-1.5 text-[10.5px] leading-[1.65] text-graphite">
              GoldPulse reports technical confluence. A 99.9% score is a measure of indicator and timeframe agreement — it is not a prediction and
              not financial advice. Gold CFDs are leveraged instruments; losses can exceed deposits on some account types. Trading XAUUSD on a $30
              balance leaves no room for error: one oversized lot or a single gap through your stop can end the account. Always size positions with
              the risk guard, use a hard stop at your broker, and never risk capital you cannot afford to lose.
            </p>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between px-1">
        <Micro>GoldPulse $30 Agent</Micro>
        <span className="num text-[9.5px] text-slate">build 1.4.0 · sim feed</span>
      </div>
      <Rule />
    </div>
  );
}
