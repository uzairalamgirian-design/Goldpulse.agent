"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { CandleChart } from "@/components/chart";
import { DecisionBanner, ProbabilityPanel, SnapshotPanel, XMBridgePanel } from "@/components/decision";
import { Btn, Field, IconBell, IconCheck, IconCopy, IconLock, IconTarget, IconWarn, Micro, Panel, Pill, Rule, Segmented, Slider, Stat } from "@/components/ui";
import { computeRisk } from "@/lib/risk";
import type { Gate, Settings, Snapshot, TradePlan } from "@/lib/types";

/* ---------------------- vertical segmented meter ---------------------- */
export function ScoreMeter({ score, threshold, armed }: { score: number; threshold: number; armed: boolean }) {
  const segments = 22;
  const filled = Math.round((score / 100) * segments);
  return (
    <div className="flex w-[26px] shrink-0 flex-col-reverse gap-[3px]" aria-hidden>
      {Array.from({ length: segments }).map((_, i) => {
        const on = i < filled;
        const top = i >= segments - 2;
        return (
          <div
            key={i}
            className="flex-1 transition-colors duration-150"
            style={{
              background: on ? (armed ? "#f5d488" : top ? "#e8b23a" : "#8a6417") : "#171c23",
              boxShadow: on && armed ? "0 0 8px rgba(232,178,58,0.65)" : "none",
            }}
          />
        );
      })}
    </div>
  );
}

function GateRow({ gate, enabled }: { gate: Gate; enabled: boolean }) {
  const tone =
    gate.state === "green"
      ? { border: "#35d07f", bg: "rgba(53,208,127,0.07)", text: "#35d07f" }
      : gate.state === "veto"
        ? { border: "#ff4d4d", bg: "rgba(255,77,77,0.09)", text: "#ff4d4d" }
        : { border: "#2a323d", bg: "transparent", text: "#8d9199" };
  return (
    <div
      className="flex items-start gap-2.5 border-b border-rule px-3 py-2.5 transition-colors duration-200"
      style={{ background: enabled ? tone.bg : "transparent", opacity: enabled ? 1 : 0.38 }}
    >
      <div className="mt-[2px] flex h-[18px] w-[18px] shrink-0 items-center justify-center border" style={{ borderColor: tone.border, color: tone.text }}>
        {gate.state === "green" ? <IconCheck size={12} /> : gate.state === "veto" ? <IconWarn size={12} /> : <span className="block h-[5px] w-[5px]" style={{ background: tone.border }} />}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline justify-between gap-2">
          <span className="text-[11.5px] leading-tight font-semibold text-bone">
            <span className="num mr-1.5 text-[10px] text-slate">{String(gate.index).padStart(2, "0")}</span>
            {gate.label}
          </span>
          <span className="num shrink-0 text-[10px]" style={{ color: tone.text }}>
            {gate.contribution.toFixed(1)}/{gate.weight}
          </span>
        </div>
        <div className="mt-1 text-[10.5px] leading-[1.45] text-graphite">{gate.detail}</div>
      </div>
    </div>
  );
}

/* --------------------------- risk guard ----------------------------- */
export function RiskGuard({ settings, plan }: { settings: Settings; plan: TradePlan | null }) {
  const [slDistance, setSlDistance] = useState<number>(plan?.slDistance ?? 2.4);
  const [riskPct, setRiskPct] = useState<number>(settings.riskPct);

  useEffect(() => {
    if (plan?.slDistance) setSlDistance(Math.round(plan.slDistance * 100) / 100);
  }, [plan?.slDistance, plan?.entry]);
  useEffect(() => setRiskPct(settings.riskPct), [settings.riskPct]);

  const risk = useMemo(
    () =>
      computeRisk({
        accountMode: settings.accountMode,
        balance: settings.balance,
        riskPct,
        maxRiskUsd: settings.maxRiskUsd,
        slDistance,
        minLot: settings.minLot,
        lotStep: settings.lotStep,
        rr: 2.5,
        minRR: settings.minRR,
      }),
    [settings, riskPct, slDistance],
  );

  return (
    <Panel title="$30 Account Risk & Lot Size Guard" right={<Pill tone={risk.blocked ? "down" : "up"}>{risk.blocked ? "BLOCKED" : "CLEARED"}</Pill>}>
      <Slider
        label="Stop-loss distance"
        value={slDistance}
        min={0.1}
        max={12}
        step={0.1}
        onChange={setSlDistance}
        format={(v) => `$${v.toFixed(2)}  ·  ${Math.round(v * 100)} pts`}
        hint={`Maximum SL for ${settings.minLot.toFixed(2)} lot inside your ${riskPct.toFixed(1)}% budget is $${risk.maxSlForMinLot.toFixed(2)}.`}
      />
      <Slider
        label="Risk per trade"
        value={riskPct}
        min={0.5}
        max={5}
        step={0.1}
        onChange={setRiskPct}
        format={(v) => `${v.toFixed(1)}%  ·  ${risk.riskBudgetLabel}`}
        hint="2–5% of equity is the survivable band on a $30 balance. Above 3% the drawdown lock will engage quickly."
      />

      <div className="grid grid-cols-2 gap-px bg-rule">
        <Stat label="Equity" value={risk.balanceLabel} sub={risk.accountCurrency === "USC" ? "Standard Cent · USC cents" : "Standard · USD"} />
        <Stat label="Risk budget" value={risk.riskBudgetLabel} sub={`capped at ${settings.accountMode === "cent" ? (settings.maxRiskUsd * 100).toFixed(0) + " USC" : "$" + settings.maxRiskUsd.toFixed(2)}`} tone="gold" />
        <Stat label="Exact lot size" value={risk.lotExact.toFixed(4)} sub={`rounded to ${settings.lotStep.toFixed(2)} step → ${risk.lot.toFixed(2)} lot`} />
        <Stat label="Capital at risk" value={risk.riskLabel} sub={`${risk.riskPct.toFixed(2)}% of equity`} tone={risk.riskPct > 5 ? "down" : "default"} />
      </div>

      {risk.blocked && risk.blockReason ? (
        <div className="flex items-start gap-2 border-t border-down/40 bg-down/10 px-3 py-2.5">
          <span className="mt-[1px] text-down"><IconWarn size={14} /></span>
          <p className="text-[11px] leading-[1.5] text-down">{risk.blockReason}</p>
        </div>
      ) : null}
      {risk.warnings.length ? (
        <div className="border-t border-rule px-3 py-2.5">
          {risk.warnings.map((w) => (
            <p key={w} className="flex items-start gap-2 text-[10.5px] leading-[1.5] text-gold">
              <span className="mt-[5px] h-[3px] w-[3px] shrink-0 bg-gold" />
              {w}
            </p>
          ))}
        </div>
      ) : null}
      <div className="border-t border-rule px-3 py-2">
        <Micro>Contract</Micro>
        <p className="num mt-1 text-[10px] leading-relaxed text-graphite">{risk.contractNote}</p>
      </div>
    </Panel>
  );
}

/* --------------------------- trade ticket --------------------------- */
export function TradeTicket({
  plan,
  snapshot,
  settings,
  onCopy,
  onLog,
  logged,
}: {
  plan: TradePlan;
  snapshot: Snapshot;
  settings: Settings;
  onCopy: (text: string) => void;
  onLog: () => void;
  logged: boolean;
}) {
  const cent = settings.accountMode === "cent";
  const riskLabel = cent ? `${(plan.riskUsd * 100).toFixed(2)} USC` : `$${plan.riskUsd.toFixed(2)}`;
  const dirUp = plan.direction === "BUY";

  const ticket = [
    `GOLDPULSE — ${plan.symbol} CONFLUENCE TICKET`,
    `Direction : ${plan.direction}`,
    `Entry zone: ${plan.entryLow.toFixed(2)} – ${plan.entryHigh.toFixed(2)} (mid ${plan.entry.toFixed(2)})`,
    `Stop loss : ${plan.sl.toFixed(2)}  (${plan.slDistance.toFixed(2)} / ${Math.round(plan.slDistance * 100)} pts)`,
    `TP1 2.0R  : ${plan.tp1.toFixed(2)}`,
    `TP2 2.5R  : ${plan.tp2.toFixed(2)}`,
    `TP3 3.5R  : ${plan.tp3.toFixed(2)}`,
    `Lot size  : ${plan.lotSize.toFixed(2)}`,
    `Risk      : ${riskLabel} (${plan.riskPct.toFixed(2)}%)`,
    `ATR(14)   : $${plan.atr.toFixed(2)}`,
    `Session   : ${snapshot.session.label}`,
    `Score     : ${snapshot.score.toFixed(3)}%`,
  ].join("\n");

  return (
    <div className="sheet-up border border-gold/45 bg-panel">
      <div className="flex items-center justify-between gap-2 border-b border-gold/30 bg-gold/10 px-3 py-2">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping bg-gold opacity-70" />
            <span className="relative inline-flex h-2 w-2 bg-gold" />
          </span>
          <span className="micro text-gold">99.9% Trade Ready · strict confluence</span>
        </div>
        <span className="num text-[10px] text-gold/80">{new Date(snapshot.ts).toUTCString().slice(17, 25)} UTC</span>
      </div>

      <div className="flex items-stretch gap-px bg-rule">
        <div className="flex-1 bg-panel px-3 py-3">
          <Micro>Direction</Micro>
          <div className={`num mt-1 text-[34px] leading-none font-bold ${dirUp ? "text-up" : "text-down"}`}>{plan.direction}</div>
          <div className="mt-1.5 text-[10px] text-graphite">{dirUp ? "Bullish continuation" : "Bearish continuation"} · {plan.symbol}</div>
        </div>
        <div className="w-[42%] bg-panel px-3 py-3">
          <Micro>Entry zone</Micro>
          <div className="num mt-1 text-[17px] leading-tight text-gold">
            {plan.entryLow.toFixed(2)}
            <span className="text-slate"> – </span>
            {plan.entryHigh.toFixed(2)}
          </div>
          <div className="num mt-1 text-[10px] text-graphite">mid {plan.entry.toFixed(2)}</div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-px bg-rule">
        {[
          { l: "ATR Stop-Loss", v: plan.sl.toFixed(2), s: `${plan.slDistance.toFixed(2)} away`, tone: "text-down" },
          { l: "TP1 · 2.0R", v: plan.tp1.toFixed(2), s: "scale 50%", tone: "text-up" },
          { l: "TP2 · 2.5R", v: plan.tp2.toFixed(2), s: "scale 30%", tone: "text-up" },
        ].map((r) => (
          <div key={r.l} className="bg-panel px-3 py-2.5">
            <Micro>{r.l}</Micro>
            <div className={`num mt-1 text-[17px] leading-none ${r.tone}`}>{r.v}</div>
            <div className="mt-1 text-[10px] text-slate">{r.s}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-px bg-rule">
        {[
          { l: "TP3 · 3.5R", v: plan.tp3.toFixed(2), s: "runner 20%" },
          { l: "Lot", v: plan.lotSize.toFixed(2), s: "safe size" },
          { l: "Risk", v: riskLabel, s: `${plan.riskPct.toFixed(2)}% of equity` },
        ].map((r) => (
          <div key={r.l} className="bg-panel px-3 py-2.5">
            <Micro>{r.l}</Micro>
            <div className="num mt-1 text-[15px] leading-none text-bone">{r.v}</div>
            <div className="mt-1 truncate text-[9.5px] text-slate">{r.s}</div>
          </div>
        ))}
      </div>

      {plan.blocked ? (
        <div className="flex items-start gap-2 border-t border-down/40 bg-down/12 px-3 py-2.5">
          <IconLock size={14} className="mt-[1px] shrink-0 text-down" />
          <p className="text-[11px] leading-[1.5] text-down">
            <strong className="font-semibold">Risk guard veto — do not place this order.</strong> {plan.blockReason}
          </p>
        </div>
      ) : null}
      {plan.warnings.map((w) => (
        <p key={w} className="border-t border-rule px-3 py-2 text-[10px] leading-[1.5] text-gold">⚠ {w}</p>
      ))}

      <div className="grid grid-cols-[1fr_1fr] gap-px border-t border-rule bg-rule">
        <Btn variant="gold" className="rounded-none py-3" onClick={() => onCopy(ticket)} disabled={plan.blocked}>
          <IconCopy size={14} /> Copy trade parameters
        </Btn>
        <Btn variant="ghost" className="rounded-none py-3" onClick={onLog} disabled={logged || plan.blocked}>
          {logged ? <IconCheck size={14} /> : <IconTarget size={14} />} {logged ? "Logged to history" : "Log this signal"}
        </Btn>
      </div>
    </div>
  );
}

/* ---------------------------- agent screen --------------------------- */
export function AgentScreen({
  snapshot,
  settings,
  patch,
  onArmScenario,
  onCopy,
  onLog,
  loggedIds,
  watchOn,
  onCapture,
  capturing,
  onTestUrgent,
  onTestBridge,
  bridgeTest,
}: {
  snapshot: Snapshot | null;
  settings: Settings;
  patch: (p: Partial<Settings>) => void;
  onArmScenario: (dir: "BUY" | "SELL") => void;
  onCopy: (text: string) => void;
  onLog: () => void;
  loggedIds: string[];
  watchOn: boolean;
  onCapture: () => void;
  capturing: boolean;
  onTestUrgent: () => void;
  onTestBridge: () => void;
  bridgeTest: string | null;
}) {
  const [bloom, setBloom] = useState(false);
  const prevArmed = useRef(false);
  const [tab, setTab] = useState<"M5" | "M15">("M5");

  useEffect(() => {
    if (snapshot?.armed && !prevArmed.current) {
      setBloom(true);
      const t = setTimeout(() => setBloom(false), 950);
      return () => clearTimeout(t);
    }
    prevArmed.current = snapshot?.armed ?? false;
  }, [snapshot?.armed]);

  if (!snapshot) {
    return (
      <div className="space-y-3 p-3">
        <Panel className="sweep relative overflow-hidden">
          <div className="flex h-[300px] items-center justify-center">
            <div className="text-center">
              <div className="num text-[28px] text-gold phosphor">····</div>
              <Micro className="mt-2">Capturing the XAUUSD chart…</Micro>
            </div>
          </div>
        </Panel>
      </div>
    );
  }

  const candles = snapshot.candles[tab];
  const i5 = snapshot.indicators.M5;
  const i15 = snapshot.indicators.M15;
  const plan = snapshot.plan;
  const armed = snapshot.armed;
  const analysis = snapshot.analysis;
  const planKey = plan ? `${plan.direction}-${plan.entry.toFixed(2)}` : "none";

  return (
    <div className="relative grid gap-3 pb-4 lg:grid-cols-[minmax(0,1fr)_380px] lg:items-start">
      {bloom ? <div className="bloom pointer-events-none fixed inset-0 z-40 bg-gold/12" /> : null}

      <div className="space-y-3">
        {/* ── 1. giant decision banner ── */}
        <DecisionBanner analysis={analysis} settings={settings} onCopy={onCopy} />

        {/* ── 2. live chart with blue ghost candles ── */}
        <section className="relative border border-rule bg-panel">
          <header className="flex items-center justify-between gap-2 border-b border-rule px-3 py-2">
            <div className="flex items-center gap-2">
              <span className="micro text-gold">{settings.symbol}</span>
              <span className="micro text-slate">·</span>
              <span className="micro text-graphite">{snapshot.session.label}</span>
            </div>
            <Segmented
              className="w-[122px]"
              options={[
                { value: "M5" as const, label: "M5" },
                { value: "M15" as const, label: "M15" },
              ]}
              value={tab}
              onChange={setTab}
            />
          </header>
          <CandleChart candles={candles} plan={plan} analysis={analysis} height={330} frame />
          <div className="grid grid-cols-4 gap-px border-t border-rule bg-rule">
            <Stat label="Detected Patterns" value={String(analysis.patterns.length)} sub={analysis.patterns[0]?.name ?? "none on this chart"} tone={analysis.patterns.length ? "gold" : "default"} />
            <Stat label="RSI (14)" value={analysis.rsiZone.value.toFixed(1)} sub={analysis.rsiZone.state === "neutral" ? "normal range" : analysis.rsiZone.state === "oversold" ? "oversold reversal forming" : "overbought reversal forming"} tone={analysis.rsiZone.state === "neutral" ? "default" : analysis.rsiZone.state === "oversold" ? "up" : "down"} />
            <Stat label="Blue Projection" value={analysis.targetPrice.toFixed(2)} sub={`next 5 bars · ${analysis.direction ?? "flat"} bias`} tone="gold" />
            <Stat label="Live Price" value={snapshot.price.toFixed(2)} sub={`spread ${snapshot.spread.toFixed(2)}`} />
          </div>
        </section>

        {/* ── 3. snapshot capture ── */}
        <SnapshotPanel analysis={analysis} onCapture={onCapture} capturing={capturing} settings={settings} patch={patch} />

        {/* ── 4. probability & risk breakdown ── */}
        <ProbabilityPanel analysis={analysis} settings={settings} patch={patch} />

        {/* ── 5. strict confluence gates ── */}
        <Panel
          title="Confluence Score · 8 Gold Gates"
          right={
            <div className="flex items-center gap-2">
              <span className={`num text-[17px] leading-none font-bold ${armed ? "text-gold phosphor" : "text-bone"}`}>{snapshot.score.toFixed(1)}%</span>
              <span className="micro text-slate">/ {settings.threshold.toFixed(1)}%</span>
            </div>
          }
        >
          <div className="flex gap-3 px-3 py-3">
            <ScoreMeter score={snapshot.score} threshold={settings.threshold} armed={armed} />
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-2">
                <Micro>Strict confirmation threshold</Micro>
                <span className="num text-[11px] text-gold">{settings.threshold.toFixed(1)}%</span>
              </div>
              <div className="mt-1.5 h-[6px] w-full bg-void">
                <div className="h-full transition-[width] duration-200" style={{ width: `${Math.min(100, snapshot.score)}%`, background: armed ? "#f5d488" : "#8a6417" }} />
              </div>
              <p className="mt-2.5 text-[10.5px] leading-[1.55] text-graphite">
                {armed
                  ? "All eight gates are green. The 99.9% confirmation threshold is met — place the trade manually at your broker."
                  : snapshot.drawdownLocked
                    ? `Alerts are paused: ${snapshot.drawdownReason}`
                    : `${snapshot.gates.filter((g) => g.state === "green").length} of 8 gates green. The alert banner above uses the ${settings.alertThreshold.toFixed(0)}% probability bar; this panel is the stricter ${settings.threshold.toFixed(1)}% confluence check.`}
              </p>
              {snapshot.direction ? (
                <div className="mt-2.5 flex flex-wrap gap-1.5">
                  <Pill tone={snapshot.direction === "BUY" ? "up" : "down"}>{snapshot.direction} bias</Pill>
                  <Pill>ATR {i5.atr.toFixed(2)}</Pill>
                  <Pill>ADX {i15.adx.toFixed(0)}</Pill>
                  {snapshot.news ? <Pill tone="down">News in {snapshot.news.minutesTo}m</Pill> : <Pill tone="neutral">No USD news in window</Pill>}
                </div>
              ) : null}
            </div>
          </div>
          <Rule />
          {snapshot.gates.map((g) => (
            <GateRow key={g.id} gate={g} enabled={settings.gates[g.id] !== false} />
          ))}
        </Panel>
      </div>

      <div className="space-y-3">
        {/* ── urgent alert controls ── */}
        <Panel title="Urgent Trade Opportunity Alerts" right={<IconBell size={14} className="text-gold" />}>
          <div className="px-3 py-3">
            <p className="text-[11px] leading-[1.6] text-graphite">
              When RSI hits an extreme <span className="text-bone">(&lt;30 oversold or &gt;70 overbought)</span> and a confirmed pattern lines up
              above your win-rate bar, GoldPulse switches into <span className="text-gold">Urgent Multi-Alert Mode</span>: a pulsing full-screen
              banner plus a high-priority notification and an urgent alarm every 5 seconds until you acknowledge it.
            </p>
            <div className="mt-3">
              <Btn variant="gold" full onClick={onTestUrgent}>
                <IconBell size={15} /> Test Urgent Alert
              </Btn>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <Btn variant="ghost" onClick={() => onArmScenario("BUY")}>Arm A+ BUY</Btn>
              <Btn variant="ghost" onClick={() => onArmScenario("SELL")}>Arm A+ SELL</Btn>
            </div>
          </div>
        </Panel>

        {/* ── strict trade ready / standing by ── */}
        {armed && plan ? (
          <TradeTicket plan={plan} snapshot={snapshot} settings={settings} onCopy={onCopy} onLog={onLog} logged={loggedIds.includes(planKey)} />
        ) : (
          <Panel title="Strict 99.9% Confluence" right={<Pill tone={watchOn ? "gold" : "neutral"}>{watchOn ? "WATCHING" : "PAUSED"}</Pill>}>
            <div className="px-3 py-4">
              <div className="flex items-start gap-3">
                <div className="mt-[3px] h-[38px] w-[3px] bg-gold/40" />
                <p className="text-[12px] leading-[1.55] text-bone">
                  {snapshot.gates.filter((g) => g.state === "green").length} of 8 gates green. The strict {settings.threshold.toFixed(1)}% ticket
                  unlocks only on full confluence — the probability panel above is what you trade from day to day.
                </p>
              </div>
            </div>
          </Panel>
        )}

        {/* ── XM bridge ── */}
        <XMBridgePanel settings={settings} patch={patch} onTest={onTestBridge} testState={bridgeTest} />

        {/* ── interactive risk guard ── */}
        <RiskGuard settings={settings} plan={plan} />

        {/* ── raw ticket ── */}
        <Panel title="Manual Order Bridge">
          <Field label="Broker symbol" value={settings.symbol} disabled hint="Suffix mapping is applied by the XM/MT bridge automatically." />
          <div className="grid grid-cols-2 gap-px bg-rule">
            <Stat label="Live bid" value={snapshot.bid.toFixed(2)} sub="sell side" />
            <Stat label="Live ask" value={snapshot.ask.toFixed(2)} sub="buy side" tone="gold" />
          </div>
        </Panel>
      </div>
    </div>
  );
}
