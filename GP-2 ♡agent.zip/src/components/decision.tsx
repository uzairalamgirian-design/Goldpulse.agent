"use client";

import { Btn, IconBell, IconCheck, IconCopy, IconTarget, IconWarn, Micro, Panel, Pill, Slider, Toggle } from "@/components/ui";
import type { ChartSnapshotAnalysis, Settings } from "@/lib/types";

/* ================================================================== *
 *  1. Giant trade decision banner                                     *
 * ================================================================== */

export function buildTicket(a: ChartSnapshotAnalysis, s: Settings): string {
  const money = (usd: number) => (s.accountMode === "cent" ? `${(usd * 100).toFixed(2)} USC` : `$${usd.toFixed(2)}`);
  return [
    "GOLDPULSE — XAUUSD TRADE TICKET",
    "================================",
    `DECISION  : ${a.headline}`,
    `PAIR      : ${a.pair}   (${s.accountMode === "cent" ? "Exness Standard Cent = XAUUSDc" : "XM / Exness Standard = XAUUSD"})`,
    `ENTRY     : ${a.headlineNumbers.entry}   (zone ${a.entryLow.toFixed(2)} – ${a.entryHigh.toFixed(2)})`,
    `LOT SIZE  : ${a.headlineNumbers.lot}   (safe for a $30 account)`,
    `STOP LOSS : ${a.headlineNumbers.sl}   (risk ${money(a.riskUsd)} / ${Math.abs(a.entry - a.sl).toFixed(2)} points)`,
    `TAKE PROF : ${a.headlineNumbers.tp}   (reward ${money(a.rewardUsd)})`,
    `TP2       : ${a.tp2.toFixed(2)}`,
    `TP3       : ${a.tp3.toFixed(2)}`,
    `WIN PROB  : ${a.winProb}%   |   LOSS RISK : ${a.lossProb}%`,
    `--------------------------------`,
    "HOW TO ENTER:",
    "1. Open XM MT4/MT5 or the Exness app",
    `2. Select ${a.pair}, set lot ${a.headlineNumbers.lot}`,
    `3. ${a.direction === "SELL" ? "Sell" : "Buy"} at ${a.headlineNumbers.entry}`,
    `4. Set SL ${a.headlineNumbers.sl} and TP ${a.headlineNumbers.tp}`,
    "5. Do not risk more than 2% on a $30 account",
  ].join("\n");
}

export function DecisionBanner({
  analysis,
  settings,
  onCopy,
}: {
  analysis: ChartSnapshotAnalysis;
  settings: Settings;
  onCopy: (text: string) => void;
}) {
  const buy = analysis.decision === "STRONG_BUY";
  const sell = analysis.decision === "STRONG_SELL";
  const waiting = analysis.decision === "WAIT";
  const accent = buy ? "#35d07f" : sell ? "#ff4d4d" : "#e8b23a";
  const bg = buy ? "rgba(53,208,127,0.10)" : sell ? "rgba(255,77,77,0.10)" : "rgba(232,178,58,0.08)";

  const nums = [
    { label: "Entry Price", value: analysis.headlineNumbers.entry, sub: `zone ${analysis.entryLow.toFixed(2)} – ${analysis.entryHigh.toFixed(2)}` },
    { label: "Lot Size", value: analysis.headlineNumbers.lot, sub: "auto-safe for $30" },
    { label: "Stop Loss", value: analysis.headlineNumbers.sl, sub: `${Math.abs(analysis.entry - analysis.sl).toFixed(2)} pts · risk ${analysis.riskUsd.toFixed(2)}` },
    { label: "Take Profit", value: analysis.headlineNumbers.tp, sub: `reward ${analysis.rewardUsd.toFixed(2)} · 1:${analysis.rr.toFixed(1)}` },
  ];

  return (
    <section className="relative overflow-hidden border-2" style={{ borderColor: accent, background: bg }}>
      <div className="absolute inset-0 opacity-[0.16]" style={{ background: `radial-gradient(120% 140% at 12% 0%, ${accent}, transparent 62%)` }} />
      <div className="relative">
        <div className="flex items-center justify-between gap-2 border-b px-3 py-2" style={{ borderColor: accent, background: bg }}>
          <div className="flex items-center gap-2">
            {!waiting ? <span className="relative flex h-2.5 w-2.5"><span className="absolute inline-flex h-full w-full animate-ping opacity-75" style={{ background: accent }} /><span className="relative inline-flex h-2.5 w-2.5" style={{ background: accent }} /></span> : null}
            <span className="micro" style={{ color: accent }}>{waiting ? "NO TRADE RIGHT NOW" : "ACTION REQUIRED"}</span>
          </div>
          <span className="num text-[9.5px] text-slate">{new Date(analysis.capturedAt).toUTCString().slice(17, 25)} UTC</span>
        </div>

        <div className="px-3 pt-3 pb-2">
          <h2
            className="text-[24px] leading-[1.02] font-extrabold tracking-[-0.025em] sm:text-[32px]"
            style={{ color: accent, textShadow: `0 0 26px ${accent}55` }}
          >
            {analysis.headline}
          </h2>
          <p className="mt-2 max-w-[62ch] text-[11.5px] leading-[1.6] text-graphite">{analysis.subline}</p>

          <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
            <Pill tone={buy ? "up" : sell ? "down" : "gold"}>
              {analysis.direction ?? "NEUTRAL"} · {analysis.pair}
            </Pill>
            <Pill tone="gold">WIN {analysis.winProb}%</Pill>
            <Pill tone="neutral">LOSS RISK {analysis.lossProb}%</Pill>
            <Pill tone="neutral">{settings.accountMode === "cent" ? "3,000 USC CENT" : "$30 USD"}</Pill>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-px bg-rule sm:grid-cols-4">
          {nums.map((n) => (
            <div key={n.label} className="bg-panel px-3 py-2.5">
              <Micro>{n.label}</Micro>
              <div className="num mt-1.5 text-[26px] leading-none font-bold" style={{ color: accent }}>
                {n.value}
              </div>
              <div className="num mt-1.5 text-[9.5px] text-slate">{n.sub}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-px border-t bg-rule sm:grid-cols-[1fr_auto]">
          <button
            type="button"
            onClick={() => onCopy(buildTicket(analysis, settings))}
            disabled={waiting}
            className="flex items-center justify-center gap-2 px-4 py-3.5 text-[12px] font-extrabold tracking-[0.14em] uppercase transition-opacity disabled:opacity-35"
            style={{ background: accent, color: "#07080b" }}
          >
            <IconCopy size={16} /> Copy All for XM / Exness
          </button>
          <div className="flex items-center justify-center gap-2 bg-panel px-4 py-3">
            <IconTarget size={14} className="text-gold" />
            <span className="num text-[10px] text-graphite">
              TP2 {analysis.tp2.toFixed(2)} · TP3 {analysis.tp3.toFixed(2)}
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ================================================================== *
 *  2. Chart snapshot capture panel                                    *
 * ================================================================== */

export function SnapshotPanel({
  analysis,
  onCapture,
  capturing,
  settings,
  patch,
}: {
  analysis: ChartSnapshotAnalysis;
  onCapture: () => void;
  capturing: boolean;
  settings: Settings;
  patch: (p: Partial<Settings>) => void;
}) {
  const zones = analysis.zones;
  return (
    <Panel
      title="Chart Snapshot Captured (Live Visual Analysis)"
      right={<Pill tone="gold">{analysis.brokerMode === "xm" ? "MY XM ACCOUNT" : "PREVIEW SNAPSHOT MODE"}</Pill>}
    >
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 border-b border-rule px-3 py-2.5">
        {[
          ["Snapshot ID", analysis.snapshotId],
          ["Captured", new Date(analysis.capturedAt).toLocaleTimeString()],
          ["Pair", analysis.pair],
          ["Timeframe", "M15 / M5 · H1 / H4 bias"],
        ].map(([k, v]) => (
          <div key={k}>
            <Micro>{k}</Micro>
            <div className="num mt-1 text-[10.5px] text-bone">{v}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-px bg-rule">
        {zones.map((z) => (
          <div key={z.label} className="bg-panel px-3 py-2.5">
            <Micro>{z.label}</Micro>
            <div className="num mt-1 text-[12px] text-gold">
              {z.low.toFixed(2)} — {z.high.toFixed(2)}
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2 border-t border-rule px-3 py-2.5">
        <Btn variant="gold" onClick={onCapture} disabled={capturing}>
          {capturing ? "Analysing new snapshot…" : "Capture New Chart Snapshot & Analyse"}
        </Btn>
        <span className="num text-[9.5px] text-slate">snaps the exact chart moment and re-predicts from it</span>
      </div>

      <div className="border-t border-rule">
        <Toggle
          on={settings.mode === "xm"}
          onChange={(v) => patch({ mode: v ? "xm" : "preview", xm: { ...settings.xm, connected: v } })}
          label="My XM Account Mode"
          hint="Preview Snapshot Mode (active now) uses built-in chart snapshots. Switch this on once your XM bridge is live and the same analyzer reads your own XM charts continuously."
        />
      </div>
    </Panel>
  );
}

/* ================================================================== *
 *  3. Probability & risk breakdown                                    *
 * ================================================================== */

export function ProbabilityPanel({
  analysis,
  settings,
  patch,
}: {
  analysis: ChartSnapshotAnalysis;
  settings: Settings;
  patch: (p: Partial<Settings>) => void;
}) {
  return (
    <Panel
      title="Win Probability vs Loss Risk"
      right={
        <span className="num text-[15px] font-bold" style={{ color: analysis.winProb >= settings.alertThreshold ? "#35d07f" : "#e8b23a" }}>
          {analysis.winProb}%
        </span>
      }
    >
      {/* bars */}
      <div className="px-3 pt-3">
        <div className="flex items-baseline justify-between">
          <Micro className="text-up">Win Confirmation Rate</Micro>
          <span className="num text-[19px] font-bold text-up">{analysis.winProb}%</span>
        </div>
        <div className="mt-1.5 h-[12px] w-full bg-void">
          <div className="h-full transition-[width] duration-300" style={{ width: `${analysis.winProb}%`, background: "linear-gradient(90deg,#1f8f5c,#35d07f)" }} />
        </div>

        <div className="mt-3 flex items-baseline justify-between">
          <Micro className="text-down">Loss Risk Rate</Micro>
          <span className="num text-[19px] font-bold text-down">{analysis.lossProb}%</span>
        </div>
        <div className="mt-1.5 h-[12px] w-full bg-void">
          <div className="h-full transition-[width] duration-300" style={{ width: `${analysis.lossProb}%`, background: "linear-gradient(90deg,#8f1f1f,#ff4d4d)" }} />
        </div>
      </div>

      <div className="mt-1">
        <Slider
          label="High-confidence alert threshold"
          value={settings.alertThreshold}
          min={50}
          max={99.9}
          step={0.1}
          onChange={(v) => patch({ alertThreshold: v })}
          format={(v) => `${v.toFixed(1)}%`}
          hint="Setups at or above this win rate will alert you. 85% is the recommended high-confidence level; push it to 99.9% for only perfect confluence."
        />
      </div>

      {/* green checklist */}
      <div className="border-t border-rule bg-up/[0.06]">
        <div className="flex items-center gap-2 px-3 pt-3">
          <IconCheck size={15} className="text-up" />
          <span className="micro text-up">Why this trade will win</span>
        </div>
        <ol className="px-3 pb-3">
          {analysis.winReasons.map((r, i) => (
            <li key={r.id} className="flex gap-2.5 border-b border-up/10 py-2 last:border-0">
              <span className="num shrink-0 text-[10px] text-up">{String(i + 1).padStart(2, "0")}</span>
              <span>
                <span className="block text-[11px] leading-[1.5] text-bone">{r.text}</span>
                <span className="mt-0.5 block text-[10px] leading-[1.5] text-up/75">{r.urdu}</span>
              </span>
            </li>
          ))}
          {analysis.winReasons.length === 0 ? <li className="py-2 text-[11px] text-slate">No confirming reasons yet — the setup is not ready.</li> : null}
        </ol>
      </div>

      {/* red warning box */}
      <div className="border-t border-rule bg-down/[0.07]">
        <div className="flex items-center gap-2 px-3 pt-3">
          <IconWarn size={15} className="text-down" />
          <span className="micro text-down">Why it could fail · loss risk reasons</span>
        </div>
        <ul className="px-3 pb-3">
          {analysis.riskReasons.map((r) => (
            <li key={r.id} className="border-b border-down/10 py-2.5 last:border-0">
              <div className="flex items-start gap-2">
                <span
                  className="mt-[3px] h-[7px] w-[7px] shrink-0"
                  style={{ background: r.severity === "high" ? "#ff4d4d" : r.severity === "medium" ? "#e8b23a" : "#8d9199" }}
                />
                <div className="min-w-0">
                  <div className="flex items-baseline gap-2">
                    <span className="text-[11px] font-semibold text-bone">{r.title}</span>
                    {r.price !== null ? <span className="num text-[9.5px] text-gold">@ {r.price.toFixed(2)}</span> : null}
                    <span className="micro text-slate">{r.severity}</span>
                  </div>
                  <p className="mt-1 text-[10px] leading-[1.6] text-graphite">{r.detail}</p>
                </div>
              </div>
            </li>
          ))}
          {analysis.riskReasons.length === 0 ? (
            <li className="py-2 text-[11px] text-slate">No major obstacles detected around price right now.</li>
          ) : null}
        </ul>
      </div>
    </Panel>
  );
}

/* ================================================================== *
 *  4. Urgent multi-ping overlay                                       *
 * ================================================================== */

export function UrgentOverlay({ analysis, onAck, ping }: { analysis: ChartSnapshotAnalysis; onAck: () => void; ping: number }) {
  const buy = analysis.decision === "STRONG_BUY";
  const accent = buy ? "#35d07f" : "#ff4d4d";
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4" style={{ background: "rgba(7,8,11,0.93)" }}>
      <div
        className="absolute inset-0"
        style={{ background: `radial-gradient(120% 90% at 50% 0%, ${accent}22, transparent 65%)`, animation: "bloom 1.4s ease-in-out infinite" }}
      />
      <div className="relative w-full max-w-[520px] border-2" style={{ borderColor: accent, background: "#0d1014" }}>
        <div className="flex items-center justify-between px-3 py-2" style={{ background: accent }}>
          <div className="flex items-center gap-2">
            <IconBell size={15} className="text-void" />
            <span className="micro text-void">Urgent Trade Opportunity</span>
          </div>
          <span className="num text-[9px] text-void/75">PING #{ping}</span>
        </div>
        <div className="px-4 py-5 text-center">
          <div className="text-[22px] leading-[1.1] font-extrabold tracking-[-0.02em] sm:text-[30px]" style={{ color: accent }}>
            TRADE READY ON XAUUSD
          </div>
          <div className="mt-1.5 text-[13px] font-bold tracking-[0.12em] text-bone uppercase">Open XM / Exness Now!</div>
          <div className="mt-3 text-[13px] text-graphite">{analysis.headline}</div>

          <div className="mt-4 grid grid-cols-2 gap-px bg-rule">
            {[
              ["Entry", analysis.headlineNumbers.entry],
              ["Lot", analysis.headlineNumbers.lot],
              ["Stop Loss", analysis.headlineNumbers.sl],
              ["Take Profit", analysis.headlineNumbers.tp],
            ].map(([k, v]) => (
              <div key={k} className="bg-panel px-3 py-2.5">
                <Micro>{k}</Micro>
                <div className="num mt-1 text-[20px] leading-none font-bold" style={{ color: accent }}>
                  {v}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-3 flex items-center justify-center gap-2">
            <Pill tone={buy ? "up" : "down"}>WIN {analysis.winProb}%</Pill>
            <Pill tone="neutral">RSI {analysis.rsiZone.value.toFixed(0)}</Pill>
            <Pill tone="neutral">LOSS RISK {analysis.lossProb}%</Pill>
          </div>

          <button
            type="button"
            onClick={onAck}
            className="mt-5 w-full px-4 py-4 text-[13px] font-extrabold tracking-[0.16em] uppercase"
            style={{ background: accent, color: "#07080b" }}
          >
            Acknowledge & Stop Alert
          </button>
          <p className="mt-2.5 text-[9.5px] leading-[1.5] text-slate">
            This alert repeats with sound every 5 seconds until you acknowledge it. GoldPulse never places the order — you do, manually.
          </p>
        </div>
      </div>
    </div>
  );
}

/* ================================================================== *
 *  5. XM Account Live Bridge                                          *
 * ================================================================== */

export function XMBridgePanel({
  settings,
  patch,
  onTest,
  testState,
}: {
  settings: Settings;
  patch: (p: Partial<Settings>) => void;
  onTest: () => void;
  testState: string | null;
}) {
  const xm = settings.xm;
  const setXm = (p: Partial<typeof xm>) => patch({ xm: { ...xm, ...p } });

  return (
    <Panel
      title="XM Account Live Bridge"
      right={<Pill tone={xm.connected ? "up" : "neutral"}>{xm.connected ? "CONNECTED" : "NOT CONNECTED"}</Pill>}
    >
      <div className="grid grid-cols-2 gap-px bg-rule">
        <button
          type="button"
          onClick={() => patch({ mode: "preview" })}
          className={`px-3 py-3 text-left transition-colors ${settings.mode === "preview" ? "bg-gold/18" : "bg-panel hover:bg-panel2"}`}
        >
          <span className={`micro block ${settings.mode === "preview" ? "text-gold" : "text-slate"}`}>Preview Snapshot Mode</span>
          <span className="mt-1.5 block text-[10px] leading-[1.5] text-graphite">
            Active now. Uses built-in XAUUSD chart snapshots and the live simulator so you can see visual analysis and predictions immediately.
          </span>
        </button>
        <button
          type="button"
          onClick={() => patch({ mode: "xm", xm: { ...xm, connected: true } })}
          className={`px-3 py-3 text-left transition-colors ${settings.mode === "xm" ? "bg-gold/18" : "bg-panel hover:bg-panel2"}`}
        >
          <span className={`micro block ${settings.mode === "xm" ? "text-gold" : "text-slate"}`}>My XM Account Mode</span>
          <span className="mt-1.5 block text-[10px] leading-[1.5] text-graphite">
            When connected, the same analyzer reads your own XM feed/bridge continuously and alerts you on high-confirmation setups.
          </span>
        </button>
      </div>

      <label className="block border-b border-rule px-3 py-2.5">
        <Micro>XM Server</Micro>
        <input
          value={xm.server}
          onChange={(e) => setXm({ server: e.target.value })}
          placeholder="XMGlobal-MT5 4"
          className="num mt-1.5 w-full bg-transparent text-[12.5px] text-bone placeholder:text-slate/60 focus:outline-none"
        />
      </label>

      <div className="border-b border-rule px-3 py-2.5">
        <Micro>Account Mode</Micro>
        <div className="mt-1.5 grid grid-cols-2 gap-px bg-rule">
          {(["demo", "real"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setXm({ accountMode: m })}
              className={`py-2 text-[10px] font-semibold tracking-[0.14em] uppercase transition-colors ${
                xm.accountMode === m ? "bg-gold text-void" : "bg-panel text-graphite hover:text-bone"
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>

      <label className="block border-b border-rule px-3 py-2.5">
        <Micro>Symbol</Micro>
        <input
          value={xm.symbol}
          onChange={(e) => setXm({ symbol: e.target.value })}
          placeholder="XAUUSDm"
          className="num mt-1.5 w-full bg-transparent text-[12.5px] text-bone placeholder:text-slate/60 focus:outline-none"
        />
      </label>

      <label className="block border-b border-rule px-3 py-2.5">
        <Micro>Chart Snapshot / Webhook / Bridge Feed URL</Micro>
        <input
          value={xm.feedUrl}
          onChange={(e) => setXm({ feedUrl: e.target.value })}
          placeholder="https://your-bridge.example.com/xauusd"
          className="num mt-1.5 w-full bg-transparent text-[12.5px] text-bone placeholder:text-slate/60 focus:outline-none"
        />
        <div className="mt-1 text-[9.5px] leading-[1.5] text-slate">
          Your MT4/MT5 Expert Advisor posts ticks and chart snapshots here. Keys are stored server-side and never shown in full.
        </div>
      </label>

      <div className="flex flex-wrap items-center gap-2 px-3 py-2.5">
        <Btn variant={xm.connected ? "danger" : "gold"} onClick={() => setXm({ connected: !xm.connected, lastSync: Date.now() })}>
          {xm.connected ? "Disconnect My XM Account" : "Connect My XM Account"}
        </Btn>
        <Btn variant="ghost" onClick={onTest}>
          <IconTarget size={13} /> Test Bridge
        </Btn>
        {testState ? <span className="num text-[9.5px] text-up">{testState}</span> : null}
      </div>
    </Panel>
  );
}
