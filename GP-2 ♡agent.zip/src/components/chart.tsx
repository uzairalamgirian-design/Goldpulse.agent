"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { emaSeries } from "@/lib/indicators";
import type { Candle, ChartSnapshotAnalysis, TradePlan } from "@/lib/types";

function useWidth<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  const [w, setW] = useState(720);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const update = () => setW(Math.max(240, el.clientWidth));
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, w] as const;
}

const UP = "#35d07f";
const DOWN = "#ff4d4d";
const GHOST = "#3b82f6";

export function CandleChart({
  candles,
  plan,
  analysis,
  height = 320,
  frame = true,
}: {
  candles: Candle[];
  plan: TradePlan | null;
  analysis?: ChartSnapshotAnalysis | null;
  height?: number;
  frame?: boolean;
}) {
  const [ref, w] = useWidth<HTMLDivElement>();
  const count = 54;
  const future = 6;
  const view = candles.slice(-count);

  const lines = useMemo(() => {
    const e9 = emaSeries(candles, 9).slice(-count);
    const e21 = emaSeries(candles, 21).slice(-count);
    const e50 = emaSeries(candles, 50).slice(-count);
    const e200 = emaSeries(candles, 200).slice(-count);
    return [
      { key: "EMA200", data: e200, color: "#4b5361", width: 1.1, dash: "5 4" },
      { key: "EMA50", data: e50, color: "#8d9199", width: 1.1, dash: "" },
      { key: "EMA21", data: e21, color: "#e8b23a", width: 1.5, dash: "" },
      { key: "EMA9", data: e9, color: "#f5d488", width: 1.3, dash: "" },
    ];
  }, [candles.length, candles[candles.length - 1]?.t]);

  if (view.length < 2) {
    return (
      <div ref={ref} style={{ height }} className="flex items-center justify-center border border-rule bg-panel">
        <span className="micro text-slate">Warming up the feed…</span>
      </div>
    );
  }

  const padR = 86;
  const padL = 10;
  const padT = 14;
  const padB = 24;
  const plotW = Math.max(160, w - padR - padL);
  const plotH = height - padT - padB;

  let min = Math.min(...view.map((c) => c.l));
  let max = Math.max(...view.map((c) => c.h));
  const ghost = analysis?.projection ?? [];
  for (const g of ghost) {
    min = Math.min(min, g.l);
    max = Math.max(max, g.h);
  }
  if (plan) {
    min = Math.min(min, plan.sl, plan.tp1);
    max = Math.max(max, plan.sl, plan.tp1);
  }
  if (analysis) {
    min = Math.min(min, analysis.targetPrice);
    max = Math.max(max, analysis.targetPrice);
  }
  const span = Math.max(0.4, max - min);
  min -= span * 0.12;
  max += span * 0.12;

  const total = count + future;
  const x = (i: number) => padL + (i + 0.5) * (plotW / total);
  const y = (p: number) => padT + ((max - p) / (max - min)) * plotH;
  const step = plotW / total;
  const bodyW = Math.max(2, step * 0.6);
  const offset = count - view.length;

  const gridCount = 5;
  const grid = Array.from({ length: gridCount }, (_, i) => min + ((max - min) * i) / (gridCount - 1));
  const poly = (data: number[]) => data.map((v, i) => `${x(i + offset).toFixed(1)},${y(v).toFixed(1)}`).join(" ");

  const last = view[view.length - 1];
  const timeLabels = [0, Math.floor(view.length / 3), Math.floor((view.length * 2) / 3), view.length - 1].map((i) => {
    const d = new Date(view[i].t);
    return { i, label: `${String(d.getUTCHours()).padStart(2, "0")}:${String(d.getUTCMinutes()).padStart(2, "0")}` };
  });

  const patternX = (t: number) => {
    const idx = view.findIndex((c) => c.t === t);
    return idx >= 0 ? x(idx) : x(count - 1);
  };

  return (
    <div ref={ref} className="relative w-full overflow-hidden" style={{ height }}>
      <svg width={w} height={height} className="block">
        <defs>
          <linearGradient id="chart-fade" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#e8b23a" stopOpacity="0.12" />
            <stop offset="1" stopColor="#e8b23a" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="ghost-fade" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#3b82f6" stopOpacity="0.16" />
            <stop offset="1" stopColor="#3b82f6" stopOpacity="0.03" />
          </linearGradient>
          <filter id="glow-blue" x="-60%" y="-60%" width="220%" height="220%">
            <feGaussianBlur stdDeviation="5" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <filter id="glow-amber" x="-60%" y="-60%" width="220%" height="220%">
            <feGaussianBlur stdDeviation="4" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* future projection backdrop */}
        <rect x={x(count - 1) + step * 0.5} y={padT} width={plotW - (x(count - 1) + step * 0.5 - padL)} height={plotH} fill="url(#ghost-fade)" />
        <line x1={x(count - 1) + step * 0.5} x2={x(count - 1) + step * 0.5} y1={padT} y2={padT + plotH} stroke="#3b82f6" strokeWidth="1" strokeDasharray="3 4" opacity="0.5" />

        {grid.map((g, i) => (
          <g key={i}>
            <line x1={padL} x2={w - padR} y1={y(g)} y2={y(g)} stroke="#1c222b" strokeWidth="1" />
            <text x={w - padR + 8} y={y(g) + 3.5} fill="#565c66" fontSize="9.5" fontFamily="var(--font-mono)">
              {g.toFixed(2)}
            </text>
          </g>
        ))}

        {/* support / resistance bands */}
        {(analysis?.levels ?? []).slice(0, 5).map((l) => {
          const above = l.price > (analysis?.entry ?? last.c);
          return (
            <g key={l.id}>
              <rect x={padL} y={y(l.price) - 2} width={plotW} height="4" fill={above ? "#ff4d4d" : "#35d07f"} opacity={0.1 + l.strength * 0.14} />
              <line x1={padL} x2={w - padR} y1={y(l.price)} y2={y(l.price)} stroke={above ? "#ff4d4d" : "#35d07f"} strokeWidth="0.9" strokeDasharray="2 5" opacity="0.6" />
            </g>
          );
        })}

        {timeLabels.map((t) => (
          <text key={t.i} x={x(t.i)} y={height - 7} fill="#565c66" fontSize="9" textAnchor="middle" fontFamily="var(--font-mono)">
            {t.label}
          </text>
        ))}

        {plan ? (
          <rect
            x={padL}
            y={y(plan.entryHigh)}
            width={plotW}
            height={Math.max(2, y(plan.entryLow) - y(plan.entryHigh))}
            fill="url(#chart-fade)"
            stroke="#8a6417"
            strokeWidth="0.8"
            strokeDasharray="3 3"
          />
        ) : null}

        {/* historical candles */}
        {view.map((c, i) => {
          const up = c.c >= c.o;
          const col = up ? UP : DOWN;
          const top = y(Math.max(c.o, c.c));
          const bot = y(Math.min(c.o, c.c));
          return (
            <g key={c.t + "-" + i}>
              <line x1={x(i)} x2={x(i)} y1={y(c.h)} y2={y(c.l)} stroke={col} strokeWidth="1" opacity="0.85" />
              <rect x={x(i) - bodyW / 2} y={top} width={bodyW} height={Math.max(1.2, bot - top)} fill={col} opacity="0.92" />
            </g>
          );
        })}

        {lines.map((l) => (
          <polyline key={l.key} points={poly(l.data)} fill="none" stroke={l.color} strokeWidth={l.width} strokeDasharray={l.dash} strokeLinejoin="round" opacity="0.9" />
        ))}

        {/* ---- BLUE GHOST / FUTURE CANDLES ---- */}
        {ghost.map((g) => {
          const gi = count + 1 + g.i;
          const top = y(Math.max(g.o, g.c));
          const bot = y(Math.min(g.o, g.c));
          return (
            <g key={"ghost-" + g.i} filter="url(#glow-blue)">
              <line x1={x(gi)} x2={x(gi)} y1={y(g.h)} y2={y(g.l)} stroke={GHOST} strokeWidth="1.3" opacity="0.85" />
              <rect
                x={x(gi) - bodyW / 2}
                y={top}
                width={bodyW}
                height={Math.max(1.5, bot - top)}
                fill={GHOST}
                opacity={0.32 + g.i * 0.05}
                stroke={GHOST}
                strokeWidth="1.2"
                strokeDasharray="3 2"
              />
            </g>
          );
        })}

        {/* projected target line */}
        {analysis ? (
          <g>
            <line x1={x(count - 1)} x2={w - padR} y1={y(analysis.targetPrice)} y2={y(analysis.targetPrice)} stroke={GHOST} strokeWidth="1.4" strokeDasharray="7 4" />
            <rect x={w - padR + 2} y={y(analysis.targetPrice) - 9} width={padR - 6} height="18" fill={GHOST} />
            <text x={w - padR + 7} y={y(analysis.targetPrice) + 4} fill="#04101f" fontSize="9.5" fontWeight="700" fontFamily="var(--font-mono)">
              TGT {analysis.targetPrice.toFixed(2)}
            </text>
          </g>
        ) : null}

        {/* plan geometry */}
        {plan ? (
          <>
            <line x1={padL} x2={w - padR} y1={y(plan.entry)} y2={y(plan.entry)} stroke="#e8b23a" strokeWidth="1.2" />
            <line x1={padL} x2={w - padR} y1={y(plan.sl)} y2={y(plan.sl)} stroke={DOWN} strokeWidth="1.1" strokeDasharray="6 4" />
            {[plan.tp1, plan.tp2, plan.tp3].map((p, i) => (
              <line key={i} x1={padL} x2={w - padR} y1={y(p)} y2={y(p)} stroke={UP} strokeWidth="1" strokeDasharray="4 4" opacity="0.85" />
            ))}
            {[
              { p: plan.entry, l: plan.direction === "BUY" ? "BUY" : "SELL", c: "#e8b23a" },
              { p: plan.sl, l: "SL", c: DOWN },
              { p: plan.tp1, l: "TP1", c: UP },
            ].map((t) => (
              <g key={t.l}>
                <rect x={padL} y={y(t.p) - 8} width={t.l.length * 6.4 + 26} height="15" fill="#07080b" opacity="0.86" />
                <text x={padL + 5} y={y(t.p) + 3} fill={t.c} fontSize="9" fontFamily="var(--font-mono)" letterSpacing="0.05em">
                  {t.l} {t.p.toFixed(2)}
                </text>
              </g>
            ))}
          </>
        ) : null}

        {/* ---- PATTERN LABELS ---- */}
        {(analysis?.patterns ?? []).slice(0, 4).map((p, idx) => {
          const px = patternX(p.at);
          const py = y(p.price);
          const col = p.tone === "bullish" ? UP : p.tone === "bearish" ? DOWN : "#e8b23a";
          const label = p.name.toUpperCase();
          const boxW = label.length * 5.4 + 14;
          const boxY = Math.max(padT + 12, py - 34 - idx * 4);
          return (
            <g key={p.id}>
              <line x1={px} x2={px} y1={boxY + 18} y2={py} stroke={col} strokeWidth="1" strokeDasharray="2 3" opacity="0.85" />
              <circle cx={px} cy={py} r="3.4" fill={col} filter="url(#glow-amber)" />
              <rect x={Math.min(px - boxW / 2, w - padR - boxW - 2)} y={boxY} width={boxW} height="17" fill="#07080b" stroke={col} strokeWidth="1" opacity="0.95" />
              <text
                x={Math.min(px - boxW / 2, w - padR - boxW - 2) + 7}
                y={boxY + 12}
                fill={col}
                fontSize="8.4"
                letterSpacing="0.09em"
                fontFamily="var(--font-display)"
                fontWeight="700"
              >
                {label}
              </text>
            </g>
          );
        })}

        {/* live price tag */}
        <g>
          <line x1={padL} x2={w - padR} y1={y(last.c)} y2={y(last.c)} stroke="#f5d488" strokeWidth="0.8" strokeDasharray="2 5" opacity="0.6" />
          <rect x={w - padR + 2} y={y(last.c) - 8} width={padR - 6} height="16" fill="#e8b23a" />
          <text x={w - padR + 7} y={y(last.c) + 4} fill="#07080b" fontSize="10" fontFamily="var(--font-mono)" fontWeight="700">
            {last.c.toFixed(2)}
          </text>
        </g>
      </svg>

      {/* RSI extreme badge */}
      {analysis && analysis.rsiZone.state !== "neutral" ? (
        <div
          className="pointer-events-none absolute top-2 right-[92px] flex items-center gap-1.5 border px-2 py-1"
          style={{
            borderColor: analysis.rsiZone.state === "oversold" ? UP : DOWN,
            background: analysis.rsiZone.state === "oversold" ? "rgba(53,208,127,0.14)" : "rgba(255,77,77,0.14)",
            boxShadow: `0 0 18px ${analysis.rsiZone.state === "oversold" ? "rgba(53,208,127,0.4)" : "rgba(255,77,77,0.4)"}`,
          }}
        >
          <span className="h-[6px] w-[6px]" style={{ background: analysis.rsiZone.state === "oversold" ? UP : DOWN }} />
          <span className="micro" style={{ color: analysis.rsiZone.state === "oversold" ? UP : DOWN }}>
            RSI {analysis.rsiZone.value.toFixed(0)} · {analysis.rsiZone.state === "oversold" ? "OVERSOLD REVERSAL" : "OVERBOUGHT REVERSAL"}
          </span>
        </div>
      ) : null}

      {/* snapshot frame */}
      {frame ? (
        <div className="pointer-events-none absolute inset-0">
          {[
            "top-0 left-0 border-t-2 border-l-2",
            "top-0 right-0 border-t-2 border-r-2",
            "bottom-0 left-0 border-b-2 border-l-2",
            "bottom-0 right-0 border-b-2 border-r-2",
          ].map((c) => (
            <span key={c} className={`absolute h-5 w-5 border-gold/70 ${c}`} />
          ))}
          <div className="absolute inset-x-0 top-1/2 h-px bg-gold/20" />
        </div>
      ) : null}

      {/* legend */}
      <div className="pointer-events-none absolute bottom-6 left-2 flex flex-wrap gap-x-3 gap-y-1">
        {lines.map((l) => (
          <span key={l.key} className="micro flex items-center gap-1.5 text-[8px] text-slate">
            <span className="inline-block h-[2px] w-3.5" style={{ background: l.color }} />
            {l.key}
          </span>
        ))}
        <span className="micro flex items-center gap-1.5 text-[8px]" style={{ color: GHOST }}>
          <span className="inline-block h-[2px] w-3.5" style={{ background: GHOST }} />
          NEXT 5 BARS
        </span>
      </div>
    </div>
  );
}

export function Sparkline({ data, up, width = 116, height = 34 }: { data: number[]; up: boolean; width?: number; height?: number }) {
  if (data.length < 2) return <div style={{ width, height }} />;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const span = Math.max(0.001, max - min);
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * width},${height - ((v - min) / span) * (height - 4) - 2}`).join(" ");
  const color = up ? UP : DOWN;
  return (
    <svg width={width} height={height} className="block">
      <polyline points={`0,${height} ${pts} ${width},${height}`} fill={color} opacity="0.12" stroke="none" />
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.4" strokeLinejoin="round" />
    </svg>
  );
}

export function BalanceCurve({ points, start = 30 }: { points: number[]; start?: number }) {
  const [ref, w] = useWidth<HTMLDivElement>();
  const h = 132;
  const data = points.length > 1 ? points : [start, start];
  const min = Math.min(...data, start) * 0.985;
  const max = Math.max(...data, start) * 1.015;
  const span = Math.max(0.5, max - min);
  const x = (i: number) => (i / (data.length - 1)) * w;
  const y = (v: number) => 8 + ((max - v) / span) * (h - 22);
  const line = data.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
  const rising = data[data.length - 1] >= start;
  const color = rising ? UP : DOWN;

  return (
    <div ref={ref} className="relative w-full" style={{ height: h }}>
      <svg width={w} height={h} className="block">
        <defs>
          <linearGradient id="bal-fade" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={color} stopOpacity="0.28" />
            <stop offset="1" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0, 0.5, 1].map((f) => (
          <line key={f} x1="0" x2={w} y1={8 + f * (h - 22)} y2={8 + f * (h - 22)} stroke="#1c222b" strokeWidth="1" />
        ))}
        <polyline points={`${line} ${w},${h} 0,${h}`} fill="url(#bal-fade)" stroke="none" />
        <polyline points={line} fill="none" stroke={color} strokeWidth="1.8" strokeLinejoin="round" />
        <line x1="0" x2={w} y1={y(start)} y2={y(start)} stroke="#e8b23a" strokeWidth="1" strokeDasharray="4 4" opacity="0.55" />
        <circle cx={x(data.length - 1)} cy={y(data[data.length - 1])} r="3.2" fill={color} />
      </svg>
      <div className="absolute inset-x-0 bottom-0 flex justify-between px-1">
        <span className="micro text-slate">$30.00 start</span>
        <span className="micro" style={{ color }}>
          ${data[data.length - 1].toFixed(2)}
        </span>
      </div>
    </div>
  );
}
