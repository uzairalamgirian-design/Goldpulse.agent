"use client";

import type { ReactNode } from "react";

/* ----------------------------- icons ----------------------------- */
const S = (p: { children: ReactNode; size?: number; className?: string; stroke?: number }) => (
  <svg
    width={p.size ?? 18}
    height={p.size ?? 18}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={p.stroke ?? 1.6}
    strokeLinecap="round"
    strokeLinejoin="round"
    className={p.className}
    aria-hidden
  >
    {p.children}
  </svg>
);

export const IconPulse = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <path d="M2 12h4l2.5-7 4 14 3-9 2 2h4.5" />
  </S>
);
export const IconRules = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <path d="M4 6h10M18 6h2M4 12h2M10 12h10M4 18h8M16 18h4" />
    <circle cx="16" cy="6" r="2" />
    <circle cx="8" cy="12" r="2" />
    <circle cx="14" cy="18" r="2" />
  </S>
);
export const IconLog = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <path d="M4 20V10M9 20V4M14 20v-7M19 20V7" />
    <path d="M3 20h18" />
  </S>
);
export const IconPlug = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <path d="M9 2v6M15 2v6" />
    <path d="M6 8h12v3a6 6 0 0 1-6 6 6 6 0 0 1-6-6z" />
    <path d="M12 17v5" />
  </S>
);
export const IconBell = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <path d="M18 8a6 6 0 1 0-12 0c0 7-3 8-3 8h18s-3-1-3-8" />
    <path d="M13.7 21a2 2 0 0 1-3.4 0" />
  </S>
);
export const IconSpeaker = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <path d="M11 5 6 9H2v6h4l5 4z" />
    <path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13" />
  </S>
);
export const IconCopy = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <rect x="9" y="9" width="12" height="12" rx="2" />
    <path d="M5 15V5a2 2 0 0 1 2-2h10" />
  </S>
);
export const IconCheck = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <path d="M20 6 9 17l-5-5" />
  </S>
);
export const IconLock = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <rect x="4" y="10" width="16" height="11" rx="2" />
    <path d="M8 10V7a4 4 0 1 1 8 0v3" />
  </S>
);
export const IconWarn = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <path d="M12 3 2 20h20z" />
    <path d="M12 9v5M12 17.5v.5" />
  </S>
);
export const IconDownload = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <path d="M12 3v12M7 11l5 5 5-5" />
    <path d="M4 20h16" />
  </S>
);
export const IconRefresh = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <path d="M20 11a8 8 0 1 0-2.3 5.7" />
    <path d="M20 5v6h-6" />
  </S>
);
export const IconTarget = (p: { size?: number; className?: string }) => (
  <S {...p}>
    <circle cx="12" cy="12" r="9" />
    <circle cx="12" cy="12" r="5" />
    <circle cx="12" cy="12" r="1.4" />
  </S>
);

/* --------------------------- primitives -------------------------- */
export function Micro({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`micro text-slate ${className}`}>{children}</div>;
}

export function Panel({
  children,
  className = "",
  title,
  right,
}: {
  children: ReactNode;
  className?: string;
  title?: string;
  right?: ReactNode;
}) {
  return (
    <section className={`border border-rule bg-panel panel-edge ${className}`}>
      {title ? (
        <header className="flex items-center justify-between gap-3 border-b border-rule px-3 py-2">
          <div className="micro text-graphite">{title}</div>
          {right}
        </header>
      ) : null}
      {children}
    </section>
  );
}

export function Stat({
  label,
  value,
  sub,
  tone = "default",
  className = "",
}: {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  tone?: "default" | "gold" | "up" | "down";
  className?: string;
}) {
  const toneClass =
    tone === "gold" ? "text-gold phosphor" : tone === "up" ? "text-up" : tone === "down" ? "text-down" : "text-bone";
  return (
    <div className={`px-3 py-2.5 ${className}`}>
      <Micro>{label}</Micro>
      <div className={`num mt-1.5 text-[19px] leading-none font-medium ${toneClass}`}>{value}</div>
      {sub ? <div className="mt-1.5 text-[11px] leading-tight text-slate">{sub}</div> : null}
    </div>
  );
}

export function Btn({
  children,
  onClick,
  variant = "ghost",
  className = "",
  disabled,
  type = "button",
  full,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "gold" | "ghost" | "danger" | "quiet";
  className?: string;
  disabled?: boolean;
  type?: "button" | "submit";
  full?: boolean;
}) {
  const base =
    "inline-flex items-center justify-center gap-2 px-3 py-2.5 text-[11px] font-semibold tracking-[0.12em] uppercase transition-colors duration-150 disabled:opacity-35 disabled:cursor-not-allowed focus:outline-none focus-visible:ring-2 focus-visible:ring-gold/70";
  const styles: Record<string, string> = {
    gold: "bg-gold text-void hover:bg-goldlt border border-gold",
    ghost: "border border-rule2 text-bone hover:border-gold hover:text-gold bg-panel2",
    danger: "border border-down/50 text-down hover:bg-down/10 bg-panel2",
    quiet: "text-graphite hover:text-bone border border-transparent",
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled} className={`${base} ${styles[variant]} ${full ? "w-full" : ""} ${className}`}>
      {children}
    </button>
  );
}

export function Toggle({
  on,
  onChange,
  label,
  hint,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  label: string;
  hint?: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!on)}
      className="flex w-full items-center justify-between gap-3 border-b border-rule px-3 py-2.5 text-left transition-colors hover:bg-panel2 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold/60"
    >
      <span className="min-w-0">
        <span className="block text-[12px] font-medium text-bone">{label}</span>
        {hint ? <span className="mt-0.5 block text-[10px] leading-snug text-slate">{hint}</span> : null}
      </span>
      <span
        className={`relative h-[18px] w-[38px] shrink-0 border transition-colors duration-150 ${on ? "border-gold bg-gold/25" : "border-rule2 bg-void"}`}
      >
        <span
          className={`absolute top-[2px] h-[12px] w-[16px] transition-all duration-150 ${on ? "left-[19px] bg-gold" : "left-[2px] bg-slate"}`}
        />
      </span>
    </button>
  );
}

export function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
  format,
  hint,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  format: (v: number) => string;
  hint?: string;
}) {
  return (
    <div className="border-b border-rule px-3 py-3">
      <div className="flex items-baseline justify-between gap-3">
        <div className="micro text-graphite">{label}</div>
        <div className="num text-[15px] text-gold">{format(value)}</div>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-2.5 w-full"
        aria-label={label}
      />
      {hint ? <div className="mt-1.5 text-[10px] leading-snug text-slate">{hint}</div> : null}
    </div>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  className = "",
}: {
  options: Array<{ value: T; label: string; sub?: string }>;
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={`grid gap-px bg-rule ${className}`} style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0,1fr))` }}>
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(o.value)}
            className={`px-2 py-2.5 text-center transition-colors duration-150 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold/60 ${
              active ? "bg-gold text-void" : "bg-panel text-graphite hover:bg-panel2 hover:text-bone"
            }`}
          >
            <span className="micro block">{o.label}</span>
            {o.sub ? <span className={`num mt-1 block text-[10px] ${active ? "text-void/70" : "text-slate"}`}>{o.sub}</span> : null}
          </button>
        );
      })}
    </div>
  );
}

export function Field({
  label,
  value,
  placeholder,
  onChange,
  type = "text",
  mono = true,
  disabled,
  hint,
}: {
  label: string;
  value: string;
  placeholder?: string;
  onChange?: (v: string) => void;
  type?: string;
  mono?: boolean;
  disabled?: boolean;
  hint?: string;
}) {
  return (
    <label className="block border-b border-rule px-3 py-2.5">
      <Micro>{label}</Micro>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        disabled={disabled}
        onChange={(e) => onChange?.(e.target.value)}
        className={`mt-1.5 w-full bg-transparent text-[13px] text-bone placeholder:text-slate/60 focus:outline-none disabled:text-slate ${mono ? "num" : ""}`}
      />
      {hint ? <div className="mt-1 text-[10px] text-slate">{hint}</div> : null}
    </label>
  );
}

export function Pill({ children, tone = "neutral" }: { children: ReactNode; tone?: "neutral" | "gold" | "up" | "down" }) {
  const map = {
    neutral: "border-rule2 text-graphite",
    gold: "border-gold/50 text-gold bg-gold/10",
    up: "border-up/45 text-up bg-up/10",
    down: "border-down/45 text-down bg-down/10",
  };
  return <span className={`micro inline-flex items-center gap-1.5 border px-2 py-1 ${map[tone]}`}>{children}</span>;
}

export function Rule({ className = "" }: { className?: string }) {
  return <div className={`h-px w-full bg-rule ${className}`} />;
}
