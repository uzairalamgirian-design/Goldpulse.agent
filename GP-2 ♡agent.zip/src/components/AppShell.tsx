"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AgentScreen } from "@/components/agent";
import { UrgentOverlay } from "@/components/decision";
import { ConnectScreen, type ConnectionDTO, type TestResult } from "@/components/connect";
import { LogScreen, type SignalDTO, type StatsDTO } from "@/components/log";
import { RulesScreen } from "@/components/rules";
import { IconLog, IconPulse, IconPlug, IconRules, Micro, Pill } from "@/components/ui";
import { chime, copyText, ensureNotificationPermission, isStandalone, notify, promptInstall, registerSW, setWakeLock, trackInstallPrompt, vibrate } from "@/lib/pwa";
import { DEFAULT_SETTINGS, type Settings, type Snapshot } from "@/lib/types";

type Tab = "agent" | "rules" | "log" | "connect";

const EMPTY_STATS: StatsDTO = { total: 0, closed: 0, wins: 0, losses: 0, winRate: 0, netPnl: 0, skipped: 0 };

export default function AppShell() {
  const [tab, setTab] = useState<Tab>("agent");
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [signals, setSignals] = useState<SignalDTO[]>([]);
  const [stats, setStats] = useState<StatsDTO>(EMPTY_STATS);
  const [connections, setConnections] = useState<ConnectionDTO[]>([]);
  const [watchOn, setWatchOn] = useState(true);
  const [toast, setToast] = useState<string | null>(null);
  const [canInstall, setCanInstall] = useState(false);
  const [standalone, setStandalone] = useState(false);
  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [flash, setFlash] = useState<"none" | "up" | "down">("none");
  const [loggedIds, setLoggedIds] = useState<string[]>([]);
  const [capturing, setCapturing] = useState(false);
  const [bridgeTest, setBridgeTest] = useState<string | null>(null);
  const [urgent, setUrgent] = useState<Snapshot["analysis"] | null>(null);
  const [urgentPing, setUrgentPing] = useState(1);
  const ackRef = useRef<string | null>(null);
  const urgentRef = useRef<string | null>(null);

  const priceRef = useRef<number | null>(null);
  const firedRef = useRef<Set<string>>(new Set());
  const prevArmedRef = useRef(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const settingsRef = useRef<Settings>(DEFAULT_SETTINGS);

  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  /* ------------------------- boot ------------------------- */
  useEffect(() => {
    registerSW();
    setStandalone(isStandalone());
    const off = trackInstallPrompt(() => setCanInstall(true));
    return off;
  }, []);

  useEffect(() => {
    const load = async () => {
      try {
        const [s, sig, con] = await Promise.all([
          fetch("/api/settings").then((r) => r.json()),
          fetch("/api/signals").then((r) => r.json()),
          fetch("/api/connect").then((r) => r.json()),
        ]);
        if (s.settings) setSettings(s.settings as Settings);
        if (sig.signals) {
          setSignals(sig.signals as SignalDTO[]);
          setStats(sig.stats ?? EMPTY_STATS);
        }
        if (con.connections) setConnections(con.connections as ConnectionDTO[]);
      } catch {
        /* the polling loop will retry */
      }
    };
    void load();
  }, []);

  /* ------------------ live tick / snapshot loop ------------------ */
  const poll = useCallback(async () => {
    try {
      const res = await fetch("/api/ticks", { cache: "no-store" });
      if (!res.ok) throw new Error("feed unavailable");
      const data = await res.json();
      if (data.snapshot) {
        const snap = data.snapshot as Snapshot;
        setSnapshot(snap);
        const prev = priceRef.current;
        if (prev !== null && Math.abs(snap.price - prev) > 0.0001) {
          setFlash(snap.price > prev ? "up" : "down");
          window.setTimeout(() => setFlash("none"), 240);
        }
        priceRef.current = snap.price;
      }
    } catch {
      /* keep the loop alive; the UI shows the stale state until it recovers */
    }
  }, []);

  useEffect(() => {
    void poll();
    const id = window.setInterval(() => void poll(), 1500);
    const vis = () => {
      if (document.visibilityState === "visible") void poll();
    };
    document.addEventListener("visibilitychange", vis);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", vis);
    };
  }, [poll]);

  /* ------------------------- alerts ------------------------- */
  useEffect(() => {
    if (!snapshot) return;
    const plan = snapshot.plan;
    const key = plan ? `${plan.direction}-${plan.entry.toFixed(2)}` : "none";

    if (snapshot.armed && !prevArmedRef.current && plan && !firedRef.current.has(key)) {
      firedRef.current.add(key);
      if (watchOn) {
        if (settings.alerts.sound) chime("alert");
        if (settings.alerts.vibrate) vibrate([60, 90, 60, 90, 180]);
        if (settings.alerts.push) {
          void ensureNotificationPermission().then(() =>
            void notify(
              `GOLDPULSE 99.9% — ${plan.direction} ${plan.symbol}`,
              `Entry ${plan.entryLow.toFixed(2)}–${plan.entryHigh.toFixed(2)} · SL ${plan.sl.toFixed(2)} · TP2 ${plan.tp2.toFixed(2)} · ${plan.lotSize.toFixed(2)} lot`,
            ),
          );
        }
        setToast(`99.9% ${plan.direction} ${plan.symbol} — ${plan.entry.toFixed(2)}`);
        window.setTimeout(() => setToast(null), 6000);
      }
    }
    prevArmedRef.current = snapshot.armed;
  }, [snapshot, watchOn, settings.alerts]);

  useEffect(() => {
    if (watchOn && settings.alerts.wakeLock) void setWakeLock(true);
    if (!watchOn) void setWakeLock(false);
  }, [watchOn, settings.alerts.wakeLock]);

  /* ------------------------- actions ------------------------- */
  const patch = useCallback((p: Partial<Settings>) => {
    setSettings((cur) => ({ ...cur, ...p, gates: { ...cur.gates, ...(p.gates ?? {}) }, alerts: { ...cur.alerts, ...(p.alerts ?? {}) } }));
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      void fetch("/api/settings", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(settingsRef.current),
      });
    }, 450);
  }, []);

  const refreshSignals = useCallback(async () => {
    try {
      const sig = await fetch("/api/signals").then((r) => r.json());
      if (sig.signals) {
        setSignals(sig.signals as SignalDTO[]);
        setStats(sig.stats ?? EMPTY_STATS);
      }
    } catch {
      /* non-critical */
    }
  }, []);

  const onArmScenario = useCallback(
    async (dir: "BUY" | "SELL") => {
      await fetch("/api/ticks", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "scenario", dir }),
      }).catch(() => undefined);
      firedRef.current.clear();
      prevArmedRef.current = false;
      void poll();
      setToast(`Simulator armed — ${dir} breakout scenario streaming`);
      window.setTimeout(() => setToast(null), 3500);
    },
    [poll],
  );

  const onLog = useCallback(async () => {
    const plan = snapshot?.plan;
    if (!plan || !snapshot) return;
    await fetch("/api/signals", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        symbol: plan.symbol,
        broker: settings.broker === "xm" ? "XM · MT5 Bridge" : settings.broker === "exness" ? "Exness · Standard Cent" : "Simulation Engine",
        accountMode: settings.accountMode,
        direction: plan.direction,
        score: snapshot.score,
        entry: plan.entry,
        entryLow: plan.entryLow,
        entryHigh: plan.entryHigh,
        sl: plan.sl,
        tp1: plan.tp1,
        tp2: plan.tp2,
        tp3: plan.tp3,
        lotSize: plan.lotSize,
        riskUsd: plan.riskUsd,
        rr: 2.5,
        session: snapshot.session.label,
        gates: snapshot.gates,
        note: `${plan.direction} confluence at ${snapshot.score.toFixed(2)}% · ATR ${plan.atr.toFixed(2)}`,
      }),
    }).catch(() => undefined);
    setLoggedIds((cur) => [...cur, `${plan.direction}-${plan.entry.toFixed(2)}`]);
    void refreshSignals();
    setToast("Signal logged to history");
    window.setTimeout(() => setToast(null), 2500);
  }, [snapshot, settings, refreshSignals]);

  const onOutcome = useCallback(
    async (id: string, outcome: "win" | "loss" | "skipped") => {
      const row = signals.find((s) => s.id === id);
      const risk = Number(row?.riskUsd ?? 0);
      const pnl = outcome === "win" ? risk * 2.5 : outcome === "loss" ? -risk : 0;
      await fetch("/api/signals", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id, outcome, pnlUsd: pnl }),
      }).catch(() => undefined);
      void refreshSignals();
    },
    [signals, refreshSignals],
  );

  const onCopy = useCallback(async (text: string) => {
    const ok = await copyText(text);
    setToast(ok ? "Trade parameters copied to clipboard" : "Copy failed — select the ticket manually");
    window.setTimeout(() => setToast(null), 2600);
  }, []);

  const onTest = useCallback(async (id: string) => {
    setTestingId(id);
    try {
      const r = await fetch("/api/connect/test", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id }),
      }).then((x) => x.json());
      if (r.ok) setTestResult(r as TestResult);
      const con = await fetch("/api/connect").then((x) => x.json());
      if (con.connections) setConnections(con.connections as ConnectionDTO[]);
    } finally {
      setTestingId(null);
    }
  }, []);

  const onUpdate = useCallback(async (id: string, p: Record<string, unknown>) => {
    setConnections((cur) => cur.map((c) => (c.id === id ? { ...c, ...(p as Partial<ConnectionDTO>) } : c)));
    await fetch("/api/connect", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id, ...p }),
    }).catch(() => undefined);
    if (typeof p.secret === "string" && p.secret.length) {
      const con = await fetch("/api/connect").then((x) => x.json()).catch(() => null);
      if (con?.connections) setConnections(con.connections as ConnectionDTO[]);
    }
  }, []);

  const onInstall = useCallback(async () => {
    const result = await promptInstall();
    if (result === "accepted") setStandalone(true);
    else if (result === "unavailable") {
      setToast("Open your browser menu and choose “Add to Home Screen”");
      window.setTimeout(() => setToast(null), 4000);
    }
  }, []);

  /* ------------------- urgent multi-ping alerts ------------------- */
  useEffect(() => {
    if (!snapshot || !settings.urgentAlerts) return;
    const a = snapshot.analysis;
    if (a.decision === "WAIT" || a.rsiZone.state === "neutral") return;
    if (ackRef.current === a.snapshotId || urgentRef.current === a.snapshotId) return;
    urgentRef.current = a.snapshotId;
    setUrgent(a);
    setUrgentPing(1);
  }, [snapshot, settings.urgentAlerts]);

  useEffect(() => {
    if (!urgent) return;
    const fire = () => {
      if (settings.alerts.sound) chime("alert");
      if (settings.alerts.vibrate) vibrate([80, 110, 80, 110, 240]);
      if (settings.alerts.push) {
        void notify(
          "TRADE READY ON XAUUSD — OPEN XM / EXNESS NOW!",
          `${urgent.headline} · Entry ${urgent.headlineNumbers.entry} · Lot ${urgent.headlineNumbers.lot} · SL ${urgent.headlineNumbers.sl} · TP ${urgent.headlineNumbers.tp}`,
          "goldpulse-urgent",
        );
      }
      setUrgentPing((p) => p + 1);
    };
    fire();
    const id = window.setInterval(fire, 5000);
    return () => window.clearInterval(id);
  }, [urgent, settings.alerts]);

  const onCapture = useCallback(async () => {
    setCapturing(true);
    try {
      const res = await fetch("/api/ticks", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "capture" }),
      }).then((r) => r.json());
      if (res.snapshot) {
        setSnapshot(res.snapshot as Snapshot);
        setToast(`New chart snapshot captured · ${res.snapshot.analysis.pair} · re-analysing`);
        window.setTimeout(() => setToast(null), 3000);
      }
    } finally {
      window.setTimeout(() => setCapturing(false), 700);
    }
  }, []);

  const onTestUrgent = useCallback(() => {
    const base = snapshot?.analysis;
    const dir = base?.direction ?? "BUY";
    const forced = {
      ...(base ?? ({} as Snapshot["analysis"])),
      snapshotId: `test-${Date.now().toString(36)}`,
      decision: dir === "SELL" ? ("STRONG_SELL" as const) : ("STRONG_BUY" as const),
      headline: dir === "SELL" ? "STRONG SELL (ABHI SELL KAREIN)" : "STRONG BUY (ABHI BUY KAREIN)",
    };
    ackRef.current = null;
    urgentRef.current = forced.snapshotId;
    setUrgent(forced);
    setUrgentPing(1);
  }, [snapshot]);

  const onTestBridge = useCallback(async () => {
    setBridgeTest("Testing bridge route…");
    try {
      const r = await fetch("/api/connect/test", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id: settings.mode === "xm" ? "xm" : "sim" }),
      }).then((x) => x.json());
      if (r.ok) setBridgeTest(`Bridge OK · ${r.latencyMs} ms · spread ${r.spread}`);
      else setBridgeTest("Bridge unreachable — check the feed URL");
    } catch {
      setBridgeTest("Bridge unreachable — check the feed URL");
    }
    window.setTimeout(() => setBridgeTest(null), 5000);
  }, [settings.mode]);

  /* ------------------------- derived ------------------------- */
  const sparkData = useMemo(() => {
    const s = snapshot?.spark;
    return Array.isArray(s) && s.length > 1 ? s : [];
  }, [snapshot]);

  const price = snapshot?.price ?? 0;
  const priceStr = price ? price.toFixed(2) : "·····";
  const flashClass = flash === "up" ? "tick-up" : flash === "down" ? "tick-down" : "";
  const armed = snapshot?.armed ?? false;
  const lockInfo = snapshot?.drawdownLocked ? snapshot.drawdownReason : null;

  const tabs: Array<{ id: Tab; label: string; icon: typeof IconPulse }> = [
    { id: "agent", label: "Agent", icon: IconPulse },
    { id: "rules", label: "Rules", icon: IconRules },
    { id: "log", label: "Log", icon: IconLog },
    { id: "connect", label: "Connect", icon: IconPlug },
  ];

  return (
    <div className="relative min-h-[100dvh] bg-void">
      {/* material backdrop */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 opacity-[0.16] mix-blend-luminosity"
        style={{
          backgroundImage: "url(images/panel-texture.jpg)",
          backgroundSize: "cover",
          backgroundPosition: "center",
          maskImage: "linear-gradient(180deg, rgba(0,0,0,0.9), rgba(0,0,0,0) 60%)",
          WebkitMaskImage: "linear-gradient(180deg, rgba(0,0,0,0.9), rgba(0,0,0,0) 60%)",
        }}
      />

      {/* ── sticky ticker rail ── */}
      <header className={`sticky top-0 z-30 border-b border-rule bg-void/94 backdrop-blur-md ${armed ? "rail-armed" : ""}`}>
        <div className="mx-auto max-w-[1180px]">
          <div className="flex items-center justify-between gap-2 px-3 pt-2.5">
            <div className="flex items-center gap-2">
              <img src="/icon.svg" alt="" width="22" height="22" className="shrink-0" />
              <div>
                <div className="text-[11px] leading-none font-extrabold tracking-[0.16em] text-bone uppercase">GoldPulse</div>
                <div className="micro mt-[3px] text-slate">$30 Agent · XAUUSD</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setWatchOn((v) => !v)}
                className="flex items-center gap-2 border border-rule2 bg-panel px-2.5 py-1.5 transition-colors hover:border-gold focus:outline-none focus-visible:ring-2 focus-visible:ring-gold/60"
                aria-pressed={watchOn}
              >
                <span className={`relative h-[16px] w-[32px] border transition-colors ${watchOn ? "border-gold bg-gold/25" : "border-rule2 bg-void"}`}>
                  <span className={`absolute top-[1px] h-[12px] w-[13px] transition-all duration-150 ${watchOn ? "left-[17px] bg-gold" : "left-[1px] bg-slate"}`} />
                </span>
                <span className="micro text-left">
                  <span className="block">24/7 Watch</span>
                  <span className={`block ${watchOn ? "text-gold" : "text-slate"}`}>{watchOn ? "ON" : "OFF"}</span>
                </span>
              </button>
            </div>
          </div>

          <div className="flex items-end justify-between gap-3 px-3 pt-1.5 pb-2">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-1.5">
                <Pill tone="gold">{settings.accountMode === "cent" ? "3,000 USC · CENT" : "$30.00 · STANDARD"}</Pill>
                <Pill tone={settings.broker === "sim" ? "neutral" : "up"}>
                  {settings.broker === "xm" ? "XM MT5" : settings.broker === "exness" ? "EXNESS" : "SIM FEED"}
                </Pill>
                {lockInfo ? <Pill tone="down">DRAW LOCK</Pill> : null}
              </div>
              <div className="mt-1.5 flex items-baseline gap-2">
                <span className={`num text-[36px] leading-none font-bold text-gold phosphor ${flashClass}`}>{priceStr}</span>
                {snapshot ? (
                  <span className={`num text-[11px] ${snapshot.changeAbs >= 0 ? "text-up" : "text-down"}`}>
                    {snapshot.changeAbs >= 0 ? "+" : ""}
                    {snapshot.changeAbs.toFixed(2)} ({snapshot.changePct >= 0 ? "+" : ""}
                    {snapshot.changePct.toFixed(2)}%)
                  </span>
                ) : null}
              </div>
            </div>

            <div className="shrink-0 text-right">
              {sparkData.length > 2 ? (
                <div className="flex justify-end opacity-80">
                  <Spark data={sparkData} up={(snapshot?.changeAbs ?? 0) >= 0} />
                </div>
              ) : null}
              <div className="num mt-1 text-[10px] text-graphite">
                SPREAD {snapshot ? snapshot.spread.toFixed(2) : "—"} <span className="text-slate">({snapshot ? Math.round(snapshot.spread * 100) : 0} pts)</span>
              </div>
              <div className="micro mt-[3px] text-slate">{snapshot?.session.label ?? "connecting…"}</div>
            </div>
          </div>

          {armed ? (
            <div className="flex items-center gap-2 border-t border-gold/40 bg-gold/12 px-3 py-1.5">
              <span className="h-[6px] w-[6px] bg-gold" />
              <span className="micro text-gold">99.9% confirmation reached — trade ready</span>
            </div>
          ) : null}
          {lockInfo ? (
            <div className="flex items-center gap-2 border-t border-down/40 bg-down/12 px-3 py-1.5">
              <span className="h-[6px] w-[6px] bg-down" />
              <span className="micro text-down">{lockInfo}</span>
            </div>
          ) : null}
        </div>
      </header>

      {/* ── content ── */}
      <main className="relative z-10 mx-auto max-w-[1180px] px-3 pt-3 pb-[104px]">
        {tab === "agent" ? (
          <AgentScreen
            snapshot={snapshot}
            settings={settings}
            patch={patch}
            onArmScenario={onArmScenario}
            onCopy={onCopy}
            onLog={onLog}
            loggedIds={loggedIds}
            watchOn={watchOn}
            onCapture={onCapture}
            capturing={capturing}
            onTestUrgent={onTestUrgent}
            onTestBridge={onTestBridge}
            bridgeTest={bridgeTest}
          />
        ) : null}
        {tab === "rules" ? <RulesScreen settings={settings} patch={patch} onReset={() => patch(DEFAULT_SETTINGS)} /> : null}
        {tab === "log" ? (
          <LogScreen signals={signals} stats={stats} startBalance={30} accountMode={settings.accountMode} onOutcome={onOutcome} />
        ) : null}
        {tab === "connect" ? (
          <ConnectScreen
            connections={connections}
            testResult={testResult}
            testingId={testingId}
            onTest={onTest}
            onUpdate={onUpdate}
            onInstall={onInstall}
            canInstall={canInstall}
            standalone={standalone}
            onNotifyTest={() => {
              void ensureNotificationPermission().then((p) => {
                if (p === "granted" || p === "default") {
                  void notify("GoldPulse alert test", "Push delivery is working. You will only hear from us at 99.9% confirmation.", "goldpulse-test");
                  setToast("Test notification sent");
                } else {
                  setToast("Notifications are blocked in your browser settings");
                }
                window.setTimeout(() => setToast(null), 2800);
              });
            }}
            onSoundTest={() => {
              chime("alert");
              setToast("Alert chime played");
              window.setTimeout(() => setToast(null), 1800);
            }}
            onVibrateTest={() => {
              vibrate([60, 90, 60, 90, 180]);
              setToast("Haptic pattern sent");
              window.setTimeout(() => setToast(null), 1800);
            }}
          />
        ) : null}
      </main>

      {/* ── bottom navigation ── */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-rule bg-void/96 backdrop-blur-md">
        <div className="mx-auto max-w-[1180px]">
          <div className="grid grid-cols-4">
            {tabs.map((t) => {
              const active = t.id === tab;
              const Icon = t.icon;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTab(t.id)}
                  className={`relative flex flex-col items-center gap-1.5 py-2.5 transition-colors duration-150 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold/60 ${
                    active ? "text-gold" : "text-slate hover:text-graphite"
                  }`}
                  aria-current={active ? "page" : undefined}
                >
                  {active ? <span className="absolute inset-x-3 top-0 h-[2px] bg-gold" /> : null}
                  <Icon size={19} />
                  <span className="micro">{t.label}</span>
                </button>
              );
            })}
          </div>
          <div className="h-[env(safe-area-inset-bottom)]" />
        </div>
      </nav>

      {/* ── urgent multi-ping overlay ── */}
      {urgent ? (
        <UrgentOverlay
          analysis={urgent}
          ping={urgentPing}
          onAck={() => {
            ackRef.current = urgent.snapshotId;
            setUrgent(null);
            setToast("Alert acknowledged — the agent keeps watching");
            window.setTimeout(() => setToast(null), 2600);
          }}
        />
      ) : null}

      {/* ── toast ── */}
      {toast ? (
        <div className="sheet-up pointer-events-none fixed inset-x-3 bottom-[104px] z-50">
          <div className="border border-gold/50 bg-panel px-3 py-2.5 shadow-[0_10px_40px_-12px_rgba(232,178,58,0.45)]">
            <div className="flex items-center gap-2">
              <span className="h-[6px] w-[6px] shrink-0 bg-gold" />
              <span className="text-[11px] leading-snug text-bone">{toast}</span>
            </div>
          </div>
        </div>
      ) : null}

      {/* footer disclaimer strip */}
      <div className="relative z-10 mx-auto max-w-[1180px] px-3 pb-[104px]">
        <Micro className="text-slate">
          Technical confluence only · not financial advice · gold CFDs carry high risk on small balances
        </Micro>
      </div>
    </div>
  );
}

function Spark({ data, up }: { data: number[]; up: boolean }) {
  const w = 108;
  const h = 30;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const span = Math.max(0.001, max - min);
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / span) * (h - 4) - 2}`).join(" ");
  const color = up ? "#35d07f" : "#ff4d4d";
  return (
    <svg width={w} height={h} className="block">
      <polyline points={`0,${h} ${pts} ${w},${h}`} fill={color} opacity="0.1" stroke="none" />
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.3" strokeLinejoin="round" />
    </svg>
  );
}
