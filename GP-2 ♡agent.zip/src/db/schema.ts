import { boolean, integer, jsonb, numeric, pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const signals = pgTable("signals", {
  id: text("id").primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  symbol: text("symbol").notNull(),
  broker: text("broker").notNull(),
  accountMode: text("account_mode").notNull(),
  direction: text("direction").notNull(),
  score: numeric("score", { precision: 6, scale: 3 }).notNull(),
  entry: numeric("entry", { precision: 12, scale: 5 }).notNull(),
  entryLow: numeric("entry_low", { precision: 12, scale: 5 }).notNull(),
  entryHigh: numeric("entry_high", { precision: 12, scale: 5 }).notNull(),
  sl: numeric("sl", { precision: 12, scale: 5 }).notNull(),
  tp1: numeric("tp1", { precision: 12, scale: 5 }).notNull(),
  tp2: numeric("tp2", { precision: 12, scale: 5 }).notNull(),
  tp3: numeric("tp3", { precision: 12, scale: 5 }).notNull(),
  lotSize: numeric("lot_size", { precision: 10, scale: 4 }).notNull(),
  riskUsd: numeric("risk_usd", { precision: 10, scale: 2 }).notNull(),
  rr: numeric("rr", { precision: 6, scale: 2 }).notNull(),
  session: text("session").notNull(),
  outcome: text("outcome").notNull().default("pending"),
  pnlUsd: numeric("pnl_usd", { precision: 10, scale: 2 }).notNull().default("0"),
  gates: jsonb("gates"),
  note: text("note"),
});

export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const connections = pgTable("connections", {
  id: text("id").primaryKey(),
  kind: text("kind").notNull(),
  label: text("label").notNull(),
  endpoint: text("endpoint"),
  account: text("account"),
  secretMasked: text("secret_masked"),
  symbol: text("symbol").notNull(),
  suffix: text("suffix").notNull().default(""),
  status: text("status").notNull().default("idle"),
  enabled: boolean("enabled").notNull().default(false),
  lastHeartbeat: timestamp("last_heartbeat", { withTimezone: true }),
  spread: numeric("spread", { precision: 10, scale: 3 }),
  latencyMs: integer("latency_ms"),
});

export const ticks = pgTable("ticks", {
  id: text("id").primaryKey(),
  recordedAt: timestamp("recorded_at", { withTimezone: true }).notNull().defaultNow(),
  price: numeric("price", { precision: 12, scale: 5 }).notNull(),
  spread: numeric("spread", { precision: 10, scale: 3 }).notNull(),
  session: text("session").notNull(),
  source: text("source").notNull(),
});
