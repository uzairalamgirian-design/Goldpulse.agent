/* Client-side PWA plumbing: install prompt, service worker, wake lock,
   notifications, audio chime and haptics. */

let deferredInstall: BeforeInstallPromptEvent | null = null;

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export function registerSW() {
  if (typeof window === "undefined") return;
  if (!("serviceWorker" in navigator)) return;
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => undefined);
  });
  if (document.readyState === "complete") {
    navigator.serviceWorker.register("/sw.js").catch(() => undefined);
  }
}

export function trackInstallPrompt(onAvailable: () => void) {
  if (typeof window === "undefined") return () => undefined;
  const handler = (e: Event) => {
    e.preventDefault();
    deferredInstall = e as BeforeInstallPromptEvent;
    onAvailable();
  };
  window.addEventListener("beforeinstallprompt", handler);
  return () => window.removeEventListener("beforeinstallprompt", handler);
}

export async function promptInstall(): Promise<"accepted" | "dismissed" | "unavailable"> {
  if (!deferredInstall) return "unavailable";
  await deferredInstall.prompt();
  const choice = await deferredInstall.userChoice;
  deferredInstall = null;
  return choice.outcome;
}

export function isStandalone() {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(display-mode: standalone)").matches || (window.navigator as unknown as { standalone?: boolean }).standalone === true;
}

export function isIOS() {
  if (typeof window === "undefined") return false;
  return /iphone|ipad|ipod/i.test(window.navigator.userAgent);
}

/* --------------------------- audio chime --------------------------- */
let ctx: AudioContext | null = null;
export function chime(variant: "alert" | "ok" | "soft" = "alert") {
  if (typeof window === "undefined") return;
  try {
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    ctx = ctx ?? new AC();
    if (ctx.state === "suspended") void ctx.resume();
    const now = ctx.currentTime;
    const notes =
      variant === "alert"
        ? [740, 988, 1319, 1760]
        : variant === "ok"
          ? [660, 880]
          : [520];
    notes.forEach((freq, i) => {
      const osc = ctx!.createOscillator();
      const gain = ctx!.createGain();
      osc.type = variant === "alert" ? "triangle" : "sine";
      osc.frequency.setValueAtTime(freq, now + i * 0.11);
      gain.gain.setValueAtTime(0.0001, now + i * 0.11);
      gain.gain.exponentialRampToValueAtTime(variant === "alert" ? 0.24 : 0.14, now + i * 0.11 + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.11 + 0.34);
      osc.connect(gain).connect(ctx!.destination);
      osc.start(now + i * 0.11);
      osc.stop(now + i * 0.11 + 0.38);
    });
  } catch {
    /* audio is a nicety, never a blocker */
  }
}

export function vibrate(pattern: number | number[] = [40, 60, 40, 60, 120]) {
  if (typeof window === "undefined") return;
  try {
    navigator.vibrate?.(pattern);
  } catch {
    /* ignore */
  }
}

export async function notify(title: string, body: string, tag = "goldpulse") {
  if (typeof window === "undefined") return;
  if (!("Notification" in window)) return;
  if (Notification.permission !== "granted") return;
  const reg = await navigator.serviceWorker?.getRegistration().catch(() => undefined);
  const icon = "/icon.svg";
  const options = {
    body,
    tag,
    icon,
    badge: icon,
    vibrate: [60, 80, 60, 80, 160],
    requireInteraction: true,
  } as unknown as NotificationOptions;
  if (reg) {
    reg.showNotification(title, options);
  } else {
    new Notification(title, { body, tag, icon });
  }
}

export async function ensureNotificationPermission(): Promise<NotificationPermission | "unsupported"> {
  if (typeof window === "undefined" || !("Notification" in window)) return "unsupported";
  if (Notification.permission === "granted") return "granted";
  return Notification.requestPermission();
}

/* ---------------------------- wake lock ---------------------------- */
let wakeSentinel: WakeLockSentinel | null = null;
export async function setWakeLock(on: boolean) {
  if (typeof window === "undefined") return false;
  try {
    if (on) {
      if (wakeSentinel) return true;
      const nav = navigator as Navigator & { wakeLock?: { request(type: "screen"): Promise<WakeLockSentinel> } };
      if (!nav.wakeLock) return false;
      wakeSentinel = await nav.wakeLock.request("screen");
      wakeSentinel.addEventListener("release", () => {
        wakeSentinel = null;
      });
      return true;
    }
    await wakeSentinel?.release();
    wakeSentinel = null;
    return true;
  } catch {
    return false;
  }
}

export function copyText(text: string): Promise<boolean> {
  if (typeof navigator === "undefined") return Promise.resolve(false);
  if (navigator.clipboard?.writeText) {
    return navigator.clipboard.writeText(text).then(
      () => true,
      () => false,
    );
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return Promise.resolve(ok);
  } catch {
    return Promise.resolve(false);
  }
}
