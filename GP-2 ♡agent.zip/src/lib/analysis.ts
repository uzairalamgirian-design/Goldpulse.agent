import { TF_MS, candlePattern } from "./indicators";
import type {
  Candle,
  ChartSnapshotAnalysis,
  Decision,
  Direction,
  Gate,
  GhostCandle,
  IndicatorSet,
  PatternMark,
  RiskReason,
  RsiZone,
  SessionInfo,
  Settings,
  SrLevel,
  TF,
  TradePlan,
  WinReason,
} from "./types";

const r2 = (n: number) => Math.round(n * 100) / 100;
const r5 = (n: number) => Math.round(n * 100000) / 100000;

/* ------------------------------------------------------------------ *
 *  Chart pattern recognition                                          *
 * ------------------------------------------------------------------ */

function doubleTopBottom(candles: Candle[], atr: number): PatternMark[] {
  const out: PatternMark[] = [];
  const win = candles.slice(-34);
  if (win.length < 12) return out;
  const peaks: Array<{ i: number; v: number }> = [];
  const troughs: Array<{ i: number; v: number }> = [];
  for (let i = 2; i < win.length - 2; i++) {
    const c = win[i];
    if (c.h > win[i - 1].h && c.h > win[i - 2].h && c.h > win[i + 1].h && c.h > win[i + 2].h) peaks.push({ i, v: c.h });
    if (c.l < win[i - 1].l && c.l < win[i - 2].l && c.l < win[i + 1].l && c.l < win[i + 2].l) troughs.push({ i, v: c.l });
  }
  for (let a = 0; a < peaks.length; a++) {
    for (let b = a + 1; b < peaks.length; b++) {
      const p1 = peaks[a];
      const p2 = peaks[b];
      if (p2.i - p1.i < 5) continue;
      if (Math.abs(p1.v - p2.v) > atr * 0.55) continue;
      const mid = win.slice(p1.i, p2.i);
      const low = Math.min(...mid.map((c) => c.l));
      if (p1.v - low < atr * 0.9) continue;
      out.push({
        id: `dbl-top-${p1.i}-${p2.i}`,
        name: "Double Top",
        tone: "bearish",
        at: win[p2.i].t,
        price: p2.v,
        note: "Two equal highs — sellers are defending this level",
      });
      return out;
    }
  }
  for (let a = 0; a < troughs.length; a++) {
    for (let b = a + 1; b < troughs.length; b++) {
      const t1 = troughs[a];
      const t2 = troughs[b];
      if (t2.i - t1.i < 5) continue;
      if (Math.abs(t1.v - t2.v) > atr * 0.55) continue;
      const mid = win.slice(t1.i, t2.i);
      const high = Math.max(...mid.map((c) => c.h));
      if (high - t1.v < atr * 0.9) continue;
      out.push({
        id: `dbl-bot-${t1.i}-${t2.i}`,
        name: "Double Bottom",
        tone: "bullish",
        at: win[t2.i].t,
        price: t2.v,
        note: "Two equal lows — buyers keep stepping in here",
      });
      return out;
    }
  }
  return out;
}

function liquiditySweep(candles: Candle[]): PatternMark[] {
  const out: PatternMark[] = [];
  const win = candles.slice(-40);
  if (win.length < 22) return out;
  const recent = win.slice(-6);
  const prior = win.slice(-26, -6);
  const priorLow = Math.min(...prior.map((c) => c.l));
  const priorHigh = Math.max(...prior.map((c) => c.h));
  for (const c of recent) {
    if (c.l < priorLow && c.c > priorLow) {
      out.push({
        id: `sweep-low-${c.t}`,
        name: "Liquidity Sweep / Stop Hunt",
        tone: "bullish",
        at: c.t,
        price: priorLow,
        note: "Price dipped below the old low, grabbed stops, then closed back above — classic sweep",
      });
      break;
    }
    if (c.h > priorHigh && c.c < priorHigh) {
      out.push({
        id: `sweep-high-${c.t}`,
        name: "Liquidity Sweep / Stop Hunt",
        tone: "bearish",
        at: c.t,
        price: priorHigh,
        note: "Price spiked above the old high, took out stops, then closed back below — classic sweep",
      });
      break;
    }
  }
  return out;
}

function breakout(candles: Candle[]): PatternMark[] {
  const out: PatternMark[] = [];
  if (candles.length < 26) return out;
  const last = candles[candles.length - 1];
  const prior = candles.slice(-26, -1);
  const high = Math.max(...prior.map((c) => c.h));
  const low = Math.min(...prior.map((c) => c.l));
  if (last.c > high) {
    out.push({
      id: `brk-res-${last.t}`,
      name: "Resistance Breakout",
      tone: "bullish",
      at: last.t,
      price: high,
      note: `Close above the ${prior.length}-bar high — breakout buyers are in control`,
    });
  } else if (last.c < low) {
    out.push({
      id: `brk-sup-${last.t}`,
      name: "Support Breakdown",
      tone: "bearish",
      at: last.t,
      price: low,
      note: `Close below the ${prior.length}-bar low — sellers have taken control`,
    });
  }
  return out;
}

function engulfing(candles: Candle[], tf: string): PatternMark[] {
  const p = candlePattern(candles);
  if (!p.name.includes("Engulfing")) return [];
  return [
    {
      id: `eng-${tf}-${candles[candles.length - 1].t}`,
      name: `${p.name} on ${tf}`,
      tone: p.dir > 0 ? "bullish" : "bearish",
      at: candles[candles.length - 1].t,
      price: candles[candles.length - 1].c,
      note: `The last ${tf} candle completely swallowed the previous one — momentum shift`,
    },
  ];
}

/* ------------------------------------------------------------------ *
 *  Support / resistance from historical price action                  *
 * ------------------------------------------------------------------ */

const LOOKBACKS = [
  { bars: 2, label: "2 hours ago" },
  { bars: 48, label: "2 days ago" },
  { bars: 96, label: "4 days ago" },
];

function buildLevels(candles: Candle[], price: number, atr: number): SrLevel[] {
  const h1 = candles;
  const out: SrLevel[] = [];
  const seen = new Set<number>();

  const push = (level: number, kind: "support" | "resistance", strength: number, seenAgo: string, note: string) => {
    const rounded = r2(level);
    if (seen.has(rounded)) return;
    if (Math.abs(level - price) > atr * 7) return;
    seen.add(rounded);
    out.push({
      id: `${kind}-${rounded}-${seenAgo.replace(/\s/g, "")}`,
      price: rounded,
      kind,
      strength,
      seenAgo,
      note,
    });
  };

  for (const ref of LOOKBACKS) {
    const idx = h1.length - 1 - ref.bars;
    if (idx < 1) continue;
    const c = h1[idx];
    push(c.h, "resistance", 0.72, ref.label, `Price turned down from here ${ref.label} (H1 high)`);
    push(c.l, "support", 0.72, ref.label, `Price bounced from here ${ref.label} (H1 low)`);
    push((c.h + c.l + c.c) / 3, "neutral" as never, 0.4, ref.label, `Mid-point of the ${ref.label} H1 candle`);
  }

  // swing pivots over the last 120 H1 bars
  const win = h1.slice(-120);
  for (let i = 3; i < win.length - 3; i++) {
    const c = win[i];
    const isHigh = c.h > win[i - 1].h && c.h > win[i - 2].h && c.h > win[i + 1].h && c.h > win[i + 2].h;
    const isLow = c.l < win[i - 1].l && c.l < win[i - 2].l && c.l < win[i + 1].l && c.l < win[i + 2].l;
    const hoursAgo = Math.round((win.length - i) * 1);
    const label = hoursAgo >= 48 ? `${Math.round(hoursAgo / 24)} days ago` : `${hoursAgo} hours ago`;
    if (isHigh) push(c.h, "resistance", 0.6, label, `Swing high formed ${label}`);
    if (isLow) push(c.l, "support", 0.6, label, `Swing low formed ${label}`);
  }

  return out
    .map((l) => ({ ...l, kind: (l.price > price ? "resistance" : "support") as "support" | "resistance" }))
    .sort((a, b) => Math.abs(a.price - price) - Math.abs(b.price - price))
    .slice(0, 7);
}

/* ------------------------------------------------------------------ *
 *  Blue ghost candle projection                                       *
 * ------------------------------------------------------------------ */

function projectPath(params: {
  price: number;
  atr: number;
  direction: Direction | null;
  rsi: number;
  levels: SrLevel[];
  timestamp: number;
  tfMs: number;
}): GhostCandle[] {
  const { price, atr, direction, rsi, levels, timestamp, tfMs } = params;
  const dir = direction === "BUY" ? 1 : direction === "SELL" ? -1 : 0;
  const rsiPush = (rsi - 50) / 50;
  const bias = dir !== 0 ? dir : rsiPush * 0.6;
  const step = atr * 0.3 * bias + rsiPush * atr * 0.06;

  const wall = levels.find((l) => Math.abs(l.price - price) < atr * 2.2 && (dir >= 0 ? l.price > price : l.price < price));
  const target = wall ? wall.price : price + step * 5.2;

  const out: GhostCandle[] = [];
  let base = price;
  for (let i = 0; i < 5; i++) {
    const pull = (target - base) * 0.32;
    const c = base + pull + step * 0.35;
    const h = Math.max(base, c) + atr * 0.16 * (1 + i * 0.06);
    const l = Math.min(base, c) - atr * 0.16 * (1 + i * 0.06);
    out.push({
      i,
      t: timestamp + tfMs * (i + 1),
      o: r5(base),
      h: r5(h),
      l: r5(l),
      c: r5(c),
      note: i === 4 ? "Projected target bar" : `Projected bar +${i + 1}`,
    });
    base = c;
  }
  return out;
}

/* ------------------------------------------------------------------ *
 *  Probability model                                                  *
 * ------------------------------------------------------------------ */

function winProbability(params: {
  direction: Direction | null;
  indicators: Record<TF, IndicatorSet>;
  patterns: PatternMark[];
  rsiZone: RsiZone;
  session: SessionInfo;
  riskReasons: RiskReason[];
  gates: Gate[];
}): { win: number; reasons: WinReason[] } {
  const { direction, indicators, patterns, rsiZone, session, riskReasons } = params;
  const H4 = indicators.H4;
  const H1 = indicators.H1;
  const M15 = indicators.M15;
  const dirSign = direction === "BUY" ? 1 : direction === "SELL" ? -1 : 0;

  const reasons: WinReason[] = [];
  let score = 40;

  if (dirSign !== 0) {
    score += 6;
    reasons.push({
      id: "dir",
      text: direction === "BUY" ? "The higher timeframes point up" : "The higher timeframes point down",
      urdu: direction === "BUY" ? "Bade timeframe (H1 + H4) upar ki taraf dikha rahe hain" : "Bade timeframe (H1 + H4) neeche ki taraf dikha rahe hain",
    });
  }

  const h4Ok = dirSign > 0 ? H4.ema50 > H4.ema200 : dirSign < 0 ? H4.ema50 < H4.ema200 : false;
  if (h4Ok) {
    score += 10;
    reasons.push({
      id: "h4",
      text: "H4 higher timeframe trend agrees",
      urdu: "H4 (bada chart) ka trend humare trade ke saath match kar raha hai",
    });
  }

  const stack =
    dirSign > 0
      ? H1.ema9 > H1.ema21 && H1.ema21 > H1.ema50
      : dirSign < 0
        ? H1.ema9 < H1.ema21 && H1.ema21 < H1.ema50
        : false;
  if (stack) {
    score += 9;
    reasons.push({
      id: "h1",
      text: direction === "BUY" ? "H1 trend is bullish" : "H1 trend is bearish",
      urdu: direction === "BUY" ? "H1 trend bullish hai — market upar ja rahi hai" : "H1 trend bearish hai — market neeche ja rahi hai",
    });
  }

  const ribbon =
    dirSign > 0
      ? M15.ema9 >= M15.ema21 && M15.ema21 >= M15.ema50
      : dirSign < 0
        ? M15.ema9 <= M15.ema21 && M15.ema21 <= M15.ema50
        : false;
  if (ribbon) {
    score += 7;
    reasons.push({
      id: "ribbon",
      text: "EMA 9 / 21 / 50 are stacked in the right order",
      urdu: "Saare moving averages (9, 21, 50) sahi order mein hain — trend clean hai",
    });
  }

  const pat = patterns.find((p) => p.tone !== "neutral");
  if (pat && (dirSign === 0 || (pat.tone === "bullish") === (dirSign > 0))) {
    score += 11;
    reasons.push({
      id: "pattern",
      text: `${pat.name} pattern confirmed on the chart`,
      urdu: `${pat.name} pattern chart par confirm ho gaya hai`,
    });
  }

  if (rsiZone.state === "oversold") {
    score += 8;
    reasons.push({
      id: "rsi-low",
      text: "RSI dropped below 30 (oversold bounce)",
      urdu: "RSI 30 se neeche chala gaya — upside reversal ka strong chance",
    });
  } else if (rsiZone.state === "overbought") {
    score += 8;
    reasons.push({
      id: "rsi-high",
      text: "RSI is above 70 (overbought reversal zone)",
      urdu: "RSI 70 se upar hai — downside reversal ka strong chance",
    });
  } else if (dirSign !== 0 && (dirSign > 0 ? M15.rsi >= 48 && M15.rsi <= 68 : M15.rsi >= 32 && M15.rsi <= 52)) {
    score += 6;
    reasons.push({
      id: "rsi-ok",
      text: `RSI ${M15.rsi.toFixed(0)} is in the healthy zone (not over-extended)`,
      urdu: `RSI ${M15.rsi.toFixed(0)} theek range mein hai — trade overbought/oversold nahi hai`,
    });
  }

  const macdOk = dirSign > 0 ? M15.macd > 0 : dirSign < 0 ? M15.macd < 0 : false;
  if (macdOk) {
    score += 5;
    reasons.push({
      id: "macd",
      text: "MACD momentum is on our side",
      urdu: "MACD momentum humare trade ke favour mein hai",
    });
  }

  if (M15.adx > 22) {
    score += 6;
    reasons.push({
      id: "adx",
      text: `Trend strength ADX ${M15.adx.toFixed(0)} — real trend, not dead chop`,
      urdu: `ADX ${M15.adx.toFixed(0)} — market mein asli trend hai, sideways chop nahi`,
    });
  }

  if (session.liquidity === "high") {
    score += 5;
    reasons.push({
      id: "session",
      text: `${session.label} — deep liquidity, cleanest fills`,
      urdu: `${session.label} — liquidity full hai, order clean execute hoga`,
    });
  }

  for (const r of riskReasons) {
    if (r.severity === "high") score -= 7;
    else if (r.severity === "medium") score -= 3;
    else score -= 1;
  }

  const win = Math.max(12, Math.min(97, Math.round(score)));
  return { win, reasons };
}

/* ------------------------------------------------------------------ *
 *  Risk / failure analysis                                            *
 * ------------------------------------------------------------------ */

function riskAnalysis(params: {
  direction: Direction | null;
  price: number;
  atr: number;
  levels: SrLevel[];
  candles: Record<TF, Candle[]>;
  indicators: Record<TF, IndicatorSet>;
  spread: number;
  rsiZone: RsiZone;
}): RiskReason[] {
  const { direction, price, atr, levels, candles, indicators, spread, rsiZone } = params;
  const out: RiskReason[] = [];
  const dirSign = direction === "BUY" ? 1 : direction === "SELL" ? -1 : 0;

  const ahead = levels
    .filter((l) => (dirSign >= 0 ? l.price > price : l.price < price))
    .sort((a, b) => Math.abs(a.price - price) - Math.abs(b.price - price));

  const wall = ahead[0];
  if (wall) {
    const dist = Math.abs(wall.price - price);
    const severity = dist < atr * 1.1 ? "high" : dist < atr * 2.4 ? "medium" : "low";
    out.push({
      id: `wall-${wall.id}`,
      title: dirSign >= 0 ? "Major resistance wall above" : "Major support wall below",
      detail: `There is a ${wall.kind} at ${wall.price.toFixed(2)} — only ${dist.toFixed(2)} away. ${wall.note}. Price can reverse there and your trade would lose.`,
      severity,
      price: wall.price,
    });
  }

  // liquidity sweep risk — recent stop hunt above/below the entry
  const m15 = candles.M15;
  const win = m15.slice(-30);
  if (win.length > 12) {
    const prior = win.slice(-16, -4);
    const recent = win.slice(-4);
    const priorLow = Math.min(...prior.map((c) => c.l));
    const priorHigh = Math.max(...prior.map((c) => c.h));
    const sweptLow = recent.some((c) => c.l < priorLow);
    const sweptHigh = recent.some((c) => c.h > priorHigh);
    if (sweptLow && dirSign >= 0) {
      out.push({
        id: "sweep-risk",
        title: "Liquidity sweep risk below",
        detail: `Price already swept below ${priorLow.toFixed(2)} recently. Market makers often re-test that zone — a drop back there would stop you out.`,
        severity: "medium",
        price: priorLow,
      });
    }
    if (sweptHigh && dirSign <= 0) {
      out.push({
        id: "sweep-risk-hi",
        title: "Liquidity sweep risk above",
        detail: `Price already spiked above ${priorHigh.toFixed(2)} recently. Another push up there would stop you out before the move down.`,
        severity: "medium",
        price: priorHigh,
      });
    }
  }

  // fake breakout zone
  const h1 = candles.H1;
  if (h1.length > 30) {
    const range = h1.slice(-30, -1);
    const hi = Math.max(...range.map((c) => c.h));
    const lo = Math.min(...range.map((c) => c.l));
    const inside = price > lo && price < hi;
    const nearEdge = Math.min(Math.abs(price - hi), Math.abs(price - lo)) < atr * 0.8;
    if (inside && nearEdge) {
      out.push({
        id: "fake-brk",
        title: "Fake breakout zone",
        detail: `Price is sitting at the edge of the ${h1.slice(-30).length}-bar range (${lo.toFixed(2)} – ${hi.toFixed(2)}). Breakouts here fail often and snap back inside.`,
        severity: "medium",
        price: price > (hi + lo) / 2 ? hi : lo,
      });
    }
  }

  if (rsiZone.state === "overbought" && dirSign >= 0) {
    out.push({
      id: "rsi-against-buy",
      title: "RSI is overbought",
      detail: `RSI(14) reads ${rsiZone.value.toFixed(0)}. Buying right after RSI goes above 70 is where most beginners get caught in the pullback.`,
      severity: "high",
      price: null,
    });
  }
  if (rsiZone.state === "oversold" && dirSign <= 0) {
    out.push({
      id: "rsi-against-sell",
      title: "RSI is oversold",
      detail: `RSI(14) reads ${rsiZone.value.toFixed(0)}. Selling right after RSI drops below 30 is where most beginners get squeezed.`,
      severity: "high",
      price: null,
    });
  }

  const roundLevel = Math.round(price / 10) * 10;
  if (Math.abs(price - roundLevel) < atr * 0.6) {
    out.push({
      id: "round-number",
      title: "Round number nearby",
      detail: `Price is right next to ${roundLevel.toLocaleString()}. Big orders cluster at round numbers and often push price back.`,
      severity: "low",
      price: roundLevel,
    });
  }

  if (spread > 0.45) {
    out.push({
      id: "spread",
      title: "Spread is unusually wide",
      detail: `Live spread is ${spread.toFixed(2)} (${Math.round(spread * 100)} points). Wide spread eats your profit on a $30 account — wait for it to tighten.`,
      severity: "medium",
      price: null,
    });
  }

  if (indicators.H4.structure === "RANGE") {
    out.push({
      id: "h4-range",
      title: "H4 is ranging, not trending",
      detail: "The 4-hour chart has no clear direction yet. Range breakouts fail more often than they hold.",
      severity: "low",
      price: null,
    });
  }

  return out;
}

/* ------------------------------------------------------------------ *
 *  Entry point                                                        *
 * ------------------------------------------------------------------ */

export function buildAnalysis(params: {
  snapshotId: string;
  candles: Record<TF, Candle[]>;
  indicators: Record<TF, IndicatorSet>;
  price: number;
  spread: number;
  settings: Settings;
  plan: TradePlan | null;
  session: SessionInfo;
  direction: Direction | null;
}): ChartSnapshotAnalysis {
  const { snapshotId, candles, indicators, price, spread, settings, plan, session } = params;
  const M5 = candles.M5;
  const M15 = candles.M15;
  const H1 = indicators.H1;
  const M15i = indicators.M15;
  const atr = Math.max(0.2, M15i.atr);
  const tfMs = TF_MS.M5;

  const rsiValue = M15i.rsi;
  const rsiZone: RsiZone =
    rsiValue < 30
      ? {
          state: "oversold",
          value: rsiValue,
          note: `RSI(14) is ${rsiValue.toFixed(1)} — below 30. Sellers are exhausted and an upside reversal is forming.`,
        }
      : rsiValue > 70
        ? {
            state: "overbought",
            value: rsiValue,
            note: `RSI(14) is ${rsiValue.toFixed(1)} — above 70. Buyers are exhausted and a downside reversal is forming.`,
          }
        : { state: "neutral", value: rsiValue, note: `RSI(14) is ${rsiValue.toFixed(1)} — inside the normal range, no reversal signal.` };

  const patterns: PatternMark[] = [
    ...engulfing(M15, "M15"),
    ...engulfing(M5, "M5"),
    ...liquiditySweep(M15),
    ...breakout(M15),
    ...doubleTopBottom(M15, atr),
  ];

  const levels = buildLevels(candles.H1, price, atr);

  const riskReasons = riskAnalysis({
    direction: plan?.direction ?? params.direction,
    price,
    atr,
    levels,
    candles,
    indicators,
    spread,
    rsiZone,
  });

  const { win, reasons } = winProbability({
    direction: plan?.direction ?? params.direction,
    indicators,
    patterns,
    rsiZone,
    session,
    riskReasons,
    gates: [],
  });

  const loss = 100 - win;
  const direction = plan?.direction ?? params.direction;

  const projection = projectPath({
    price,
    atr,
    direction,
    rsi: rsiValue,
    levels,
    timestamp: Date.now(),
    tfMs,
  });
  const targetPrice = projection[projection.length - 1].c;

  const threshold = settings.alertThreshold ?? 85;
  const hardBlock = plan?.blocked === true;
  // Only a genuinely un-tradeable condition silences the decision. Structural
  // obstacles (resistance walls, sweeps) are shown in the red box instead — the
  // trader should see them and decide, not be hidden from them.
  const blockingRisk = riskReasons.some(
    (r) => r.severity === "high" && (r.id.startsWith("rsi-against") || r.id === "spread"),
  );
  let decision: Decision = "WAIT";
  if (direction && win >= threshold && !hardBlock && !blockingRisk) {
    decision = direction === "BUY" ? "STRONG_BUY" : "STRONG_SELL";
  }

  const headline =
    decision === "STRONG_BUY"
      ? "STRONG BUY (ABHI BUY KAREIN)"
      : decision === "STRONG_SELL"
        ? "STRONG SELL (ABHI SELL KAREIN)"
        : "WAIT — NO TRADE (ABHI RUKEN)";

  const subline =
    decision === "WAIT"
      ? hardBlock
        ? (plan?.blockReason ?? "The $30 risk guard is blocking this setup.")
        : blockingRisk
          ? "A hard warning is active right now (over-extended RSI or a wide spread). Let this one go."
          : `Confirmation is ${win}% — below your ${threshold}% bar. The agent keeps watching.`
      : `${win}% win confirmation · ${loss}% loss risk · risk $${(plan?.riskUsd ?? 0).toFixed(2)} to make $${((plan?.riskUsd ?? 0) * 2.5).toFixed(2)}`;

  const cent = settings.accountMode === "cent";
  const entry = plan?.entry ?? price;

  return {
    snapshotId,
    capturedAt: Date.now(),
    pair: settings.symbol,
    timeframe: "M15 + M5 execution · H1 / H4 bias",
    brokerMode: settings.mode,
    decision,
    headline,
    subline,
    winProb: win,
    lossProb: loss,
    direction,
    entry,
    entryLow: plan?.entryLow ?? price - atr * 0.12,
    entryHigh: plan?.entryHigh ?? price + atr * 0.12,
    sl: plan?.sl ?? price - atr * 1.25,
    tp1: plan?.tp1 ?? price + atr * 2.5,
    tp2: plan?.tp2 ?? price + atr * 3.1,
    tp3: plan?.tp3 ?? price + atr * 4.4,
    rr: 2.5,
    lotSize: plan?.lotSize ?? settings.minLot,
    riskUsd: plan?.riskUsd ?? 0.6,
    riskPct: plan?.riskPct ?? 2,
    rewardUsd: (plan?.riskUsd ?? 0.6) * 2.5,
    accountCurrency: cent ? "USC" : "USD",
    projection,
    targetPrice,
    patterns,
    levels,
    rsiZone,
    winReasons: reasons.slice(0, 8),
    riskReasons: riskReasons.slice(0, 6),
    zones: [
      {
        high: r2(price + atr * 0.5),
        low: r2(price - atr * 0.5),
        label: "Live price zone",
      },
      {
        high: r2(Math.max(...M15.slice(-24).map((c) => c.h))),
        low: r2(Math.min(...M15.slice(-24).map((c) => c.l))),
        label: "Last 2 hours range",
      },
    ],
    headlineNumbers: {
      entry: entry.toFixed(2),
      lot: (plan?.lotSize ?? settings.minLot).toFixed(2),
      sl: (plan?.sl ?? price - atr * 1.25).toFixed(2),
      tp: (plan?.tp1 ?? price + atr * 2.5).toFixed(2),
    },
  };
}
