import type { Candle, IndicatorSet, TF } from "./types";

export function ema(values: number[], period: number): number[] {
  const out: number[] = [];
  if (values.length === 0) return out;
  const k = 2 / (period + 1);
  let prev = values[0];
  for (let i = 0; i < values.length; i++) {
    prev = i === 0 ? values[0] : values[i] * k + prev * (1 - k);
    out.push(prev);
  }
  return out;
}

export function lastEma(values: number[], period: number): number {
  const e = ema(values, period);
  return e.length ? e[e.length - 1] : 0;
}

export function rsi(values: number[], period = 14): number[] {
  const out: number[] = [];
  if (values.length <= period) return values.map(() => 50);
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = values[i] - values[i - 1];
    if (d >= 0) gain += d;
    else loss -= d;
  }
  gain /= period;
  loss /= period;
  for (let i = 0; i < values.length; i++) {
    if (i < period) {
      out.push(50);
      continue;
    }
    if (i > period) {
      const d = values[i] - values[i - 1];
      gain = (gain * (period - 1) + (d > 0 ? d : 0)) / period;
      loss = (loss * (period - 1) + (d < 0 ? -d : 0)) / period;
    }
    const rs = loss === 0 ? 100 : gain / loss;
    out.push(loss === 0 ? 100 : 100 - 100 / (1 + rs));
  }
  return out;
}

export function macd(values: number[], fast = 12, slow = 26, signal = 9) {
  const ef = ema(values, fast);
  const es = ema(values, slow);
  const line = ef.map((v, i) => v - es[i]);
  const sig = ema(line, signal);
  const hist = line.map((v, i) => v - sig[i]);
  return { line, signal: sig, hist };
}

export function atr(candles: Candle[], period = 14): number {
  if (candles.length < 2) return candles.length ? candles[0].h - candles[0].l : 1;
  const trs: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const c = candles[i];
    const p = candles[i - 1];
    trs.push(Math.max(c.h - c.l, Math.abs(c.h - p.c), Math.abs(c.l - p.c)));
  }
  const slice = trs.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / Math.max(1, slice.length);
}

export function adx(candles: Candle[], period = 14): number {
  if (candles.length < period * 2 + 2) return 18;
  const plusDM: number[] = [];
  const minusDM: number[] = [];
  const trs: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const c = candles[i];
    const p = candles[i - 1];
    const up = c.h - p.h;
    const down = p.l - c.l;
    plusDM.push(up > down && up > 0 ? up : 0);
    minusDM.push(down > up && down > 0 ? down : 0);
    trs.push(Math.max(c.h - c.l, Math.abs(c.h - p.c), Math.abs(c.l - p.c)));
  }
  const smooth = (arr: number[]) => {
    const s = arr.slice(0, period).reduce((a, b) => a + b, 0);
    const out = [s];
    let cur = s;
    for (let i = period; i < arr.length; i++) {
      cur = cur - cur / period + arr[i];
      out.push(cur);
    }
    return out;
  };
  const str = smooth(trs);
  const sp = smooth(plusDM);
  const sm = smooth(minusDM);
  const dx: number[] = [];
  for (let i = 0; i < str.length; i++) {
    const pdi = str[i] === 0 ? 0 : (100 * sp[i]) / str[i];
    const mdi = str[i] === 0 ? 0 : (100 * sm[i]) / str[i];
    const sum = pdi + mdi;
    dx.push(sum === 0 ? 0 : (100 * Math.abs(pdi - mdi)) / sum);
  }
  const tail = dx.slice(-period);
  const value = tail.reduce((a, b) => a + b, 0) / Math.max(1, tail.length);
  return Math.min(85, value);
}

export function structureOf(candles: Candle[]): "HH-HL" | "LH-LL" | "RANGE" {
  if (candles.length < 12) return "RANGE";
  const recent = candles.slice(-12);
  const first = recent.slice(0, 6);
  const second = recent.slice(6);
  const hi = (a: Candle[]) => Math.max(...a.map((c) => c.h));
  const lo = (a: Candle[]) => Math.min(...a.map((c) => c.l));
  // A structural break has to exceed a fraction of the recent range — a couple
  // of ticks of drift is not a change of market structure.
  const tol = Math.max(1e-6, Math.max(...recent.map((c) => c.h - c.l)) * 0.08);
  const hh = hi(second) > hi(first) + tol;
  const hl = lo(second) > lo(first) + tol;
  const lh = hi(second) < hi(first) - tol;
  const ll = lo(second) < lo(first) - tol;
  if (hh && hl) return "HH-HL";
  if (lh && ll) return "LH-LL";
  return "RANGE";
}

export interface CandleSignal {
  name: string;
  dir: 1 | -1 | 0;
  strength: number;
}

export function candlePattern(candles: Candle[]): CandleSignal {
  if (candles.length < 4) return { name: "—", dir: 0, strength: 0 };
  const [p2, p1, c] = candles.slice(-3);
  const body = c.c - c.o;
  const range = Math.max(1e-6, c.h - c.l);
  const upper = c.h - Math.max(c.c, c.o);
  const lower = Math.min(c.c, c.o) - c.l;
  const prevBody = p1.c - p1.o;

  if (body > 0 && prevBody < 0 && c.c >= p1.o && c.o <= p1.c)
    return { name: "Bullish Engulfing", dir: 1, strength: 1 };
  if (body < 0 && prevBody > 0 && c.o >= p1.c && c.c <= p1.o)
    return { name: "Bearish Engulfing", dir: -1, strength: 1 };
  if (lower > range * 0.6 && upper < range * 0.15 && body >= 0)
    return { name: "Bullish Pin Bar", dir: 1, strength: 0.8 };
  if (upper > range * 0.6 && lower < range * 0.15 && body <= 0)
    return { name: "Bearish Pin Bar", dir: -1, strength: 0.8 };
  if (Math.abs(body) > range * 0.65 && body > 0 && c.c > p1.h)
    return { name: "Bullish Marubozu Break", dir: 1, strength: 0.75 };
  if (Math.abs(body) > range * 0.65 && body < 0 && c.c < p1.l)
    return { name: "Bearish Marubozu Break", dir: -1, strength: 0.75 };
  if (Math.abs(body) < range * 0.18)
    return { name: "Doji / Indecision", dir: 0, strength: 0.2 };
  if (p2.c - p2.o > 0 && p1.c - p1.o > 0 && body > 0)
    return { name: "Three White Soldiers", dir: 1, strength: 0.7 };
  if (p2.c - p2.o < 0 && p1.c - p1.o < 0 && body < 0)
    return { name: "Three Black Crows", dir: -1, strength: 0.7 };
  return { name: body > 0 ? "Bullish Candle" : "Bearish Candle", dir: body > 0 ? 1 : -1, strength: 0.45 };
}

export function computeIndicators(candles: Candle[]): IndicatorSet {
  const closes = candles.map((c) => c.c);
  const m = macd(closes);
  const i = closes.length - 1;
  return {
    ema9: lastEma(closes, 9),
    ema21: lastEma(closes, 21),
    ema50: lastEma(closes, 50),
    ema200: lastEma(closes, 200),
    rsi: rsi(closes)[i] ?? 50,
    macd: m.line[i] ?? 0,
    macdSignal: m.signal[i] ?? 0,
    macdHist: m.hist[i] ?? 0,
    adx: adx(candles),
    atr: atr(candles),
    structure: structureOf(candles),
  };
}

export function emaSeries(candles: Candle[], period: number): number[] {
  return ema(candles.map((c) => c.c), period);
}

export const TF_MS: Record<TF, number> = { M5: 300_000, M15: 900_000, H1: 3_600_000, H4: 14_400_000 };
