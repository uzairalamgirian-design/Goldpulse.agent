import { TF_MS, computeIndicators } from "./indicators";
import type { Candle, IndicatorSet, NewsEvent, SessionInfo, TF } from "./types";

/* ------------------------------------------------------------------ *
 * Deterministic PRNG so the simulator behaves consistently per boot.  *
 * ------------------------------------------------------------------ */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rnd = mulberry32(0x6701d5);
function gauss() {
  let u = 0;
  let v = 0;
  while (u === 0) u = rnd();
  while (v === 0) v = rnd();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

export const BASE_PRICE = 4185.4;

/* ---------------------------- sessions ---------------------------- */
export function sessionAt(d: Date): SessionInfo {
  const h = d.getUTCHours();
  const mk = (id: SessionInfo["id"], label: string, liquidity: SessionInfo["liquidity"], volatility: number): SessionInfo => ({
    id,
    label,
    liquidity,
    volatility,
    utcHour: h,
  });
  if (h >= 22 || h < 6) return mk("asian", "Asian Session", "low", 0.52);
  if (h >= 6 && h < 7) return mk("rollover", "Rollover / Thin Liquidity", "low", 0.28);
  if (h >= 7 && h < 12) return mk("london", "London Session", "high", 1.3);
  if (h >= 12 && h < 16) return mk("overlap", "London / New York Overlap", "high", 1.55);
  if (h >= 16 && h < 20) return mk("newyork", "New York Session", "medium", 1.0);
  return mk("rollover", "Rollover / Thin Liquidity", "low", 0.34);
}

export function spreadFor(d: Date, price: number): number {
  const s = sessionAt(d);
  const noise = (rnd() - 0.5) * 0.03;
  const base = s.id === "rollover" ? 0.86 : s.id === "asian" ? 0.32 : s.id === "overlap" ? 0.17 : 0.22;
  return Math.max(0.08, base + noise + Math.min(0.25, Math.abs(price - BASE_PRICE) / 4000));
}

/* ------------------------------ news ------------------------------ */
const NEWS_TEMPLATE: Array<{ offsetMin: number; title: string; impact: "high" | "medium" }> = [
  { offsetMin: 13 * 60 + 30, title: "US Non-Farm Payrolls", impact: "high" },
  { offsetMin: 14 * 60, title: "US CPI (Core, YoY)", impact: "high" },
  { offsetMin: 15 * 60, title: "ISM Services PMI", impact: "medium" },
  { offsetMin: 18 * 60, title: "FOMC Rate Decision & Presser", impact: "high" },
  { offsetMin: 20 * 60, title: "Fed Chair Speech", impact: "high" },
];

export function newsEvents(now: number): NewsEvent[] {
  const day = new Date(now);
  day.setUTCHours(0, 0, 0, 0);
  const start = day.getTime();
  return NEWS_TEMPLATE.map((e, i) => ({
    id: `${day.toISOString().slice(0, 10)}-${i}`,
    title: e.title,
    impact: e.impact,
    at: start + e.offsetMin * 60_000,
    minutesTo: Math.round((start + e.offsetMin * 60_000 - now) / 60_000),
  }));
}

export function activeNewsWindow(now: number): NewsEvent | null {
  const list = newsEvents(now).filter((e) => e.impact === "high");
  for (const e of list) {
    const diff = (e.at - now) / 60_000;
    if (diff <= 30 && diff >= -30) return { ...e, minutesTo: Math.round(diff) };
  }
  return null;
}

/* --------------------------- engine state -------------------------- */
interface EngineState {
  price: number;
  lastTs: number;
  trend: number;
  candles: Record<TF, Candle[]>;
  spark: number[];
  ticks: Array<{ t: number; p: number; s: number }>;
  initialised: boolean;
  boostUntil: number;
  boostDir: number;
}

/** Rewrite the tail of every timeframe into a clean trend leg followed by a
 *  shallow pullback, then hand the feed back to the live simulator. Every
 *  indicator is still computed from real candle data — nothing is faked
 *  downstream. */
function shapeTrend(arr: Candle[], dir: 1 | -1, endPrice: number, vol: number, count: number) {
  // a slow, steady trend leg: two advances and one pullback per three candles.
  // That rhythm keeps RSI(14) mid-band while the EMA stack stays ordered and
  // the swing structure keeps printing higher highs / higher lows.
  let n = Math.min(count, arr.length);
  if (n < 8) return;
  while ((n - 2) % 3 !== 2) n -= 1;
  const startIdx = arr.length - n;
  const u = vol * 0.55;
  const slope = u * 0.4;
  const pattern = [1, 1, -1];

  const closes: number[] = [];
  let acc = 0;
  for (let i = 0; i < n; i++) {
    const taper = i > n - 21 ? 1 - 0.45 * ((i - (n - 21)) / 20) : 1;
    acc += slope * taper * dir;
    closes.push(acc + u * pattern[i % 3] * dir);
  }
  const shift = endPrice - closes[n - 1];
  for (let i = 0; i < n; i++) closes[i] += shift;
  // any candles left in front of the trend leg get folded into it
  for (let j = 0; j < startIdx; j++) {
    const src = arr[startIdx];
    arr[j].o = src.o;
    arr[j].h = src.h;
    arr[j].l = src.l;
    arr[j].c = src.c;
  }

  // A rising (or falling) channel whose bounds move every bar: the trend is
  // unambiguous to the directional movement index, while the closes still
  // breathe in the two-up / one-down rhythm that keeps RSI mid-band.
  const W = u * 3.4;
  const pad = u * 0.3;
  let top = closes[0] + u * 1.7;
  for (let i = 0; i < n; i++) {
    const c = arr[startIdx + i];
    const taper = i > n - 21 ? 1 - 0.45 * ((i - (n - 21)) / 20) : 1;
    if (i > 0) top += slope * taper * dir;
    const bot = top - W;
    const clampIn = (v: number) => Math.min(top - pad, Math.max(bot + pad, v));
    const close = clampIn(closes[i]);
    const open = i === 0 ? close - dir * u * 0.6 : clampIn(closes[i - 1]);
    c.o = r5(open);
    c.c = r5(close);
    c.h = r5(top);
    c.l = r5(bot);
    c.v = Math.round(220 + Math.abs(gauss()) * 260);
  }

  // the final candle becomes an unambiguous trigger candle: it opens just off
  // the prior close and engulfs the previous bar's entire body
  const last = arr[arr.length - 1];
  const prev = arr[arr.length - 2];
  last.o = r5(prev.c - dir * u * 1.1);
  last.c = r5(dir > 0 ? Math.max(endPrice, prev.h + u * 0.3) : Math.min(endPrice, prev.l - u * 0.3));
  last.h = r5(Math.max(last.o, last.c) + u * 0.25);
  last.l = r5(Math.min(last.o, last.c) - u * 0.12);
  last.v = 940;
}

/** Inject a scripted A+ scenario (London breakout + shallow pullback). */
export function armScenario(dir: 1 | -1, durationMs = 180_000) {
  const st = advance(Date.now());
  st.boostUntil = Date.now() + durationMs;
  st.boostDir = dir;
  const endPrice = st.price;
  const specs: Array<[TF, number, number]> = [
    ["M5", 240, 0.95],
    ["M15", 240, 1.55],
    ["H1", 240, 2.9],
    ["H4", 240, 5.4],
  ];
  for (const [tf, count, vol] of specs) shapeTrend(st.candles[tf], dir, endPrice, vol, count);
  const finalPrice = st.candles.M5[st.candles.M5.length - 1].c;
  // adopt the live bucket so the trigger candle stays the forming candle
  const nowTs = Date.now();
  for (const [tf] of specs) {
    const arr = st.candles[tf];
    const last = arr[arr.length - 1];
    last.c = r5(finalPrice);
    last.h = Math.max(last.h, last.c);
    last.l = Math.min(last.l, last.c);
    last.t = Math.floor(nowTs / TF_MS[tf]) * TF_MS[tf];
  }
  st.price = r5(finalPrice);
  st.spark = st.candles.M5.slice(-90).map((c) => c.c);
}
export function scenarioRemaining() {
  const st = state();
  return Math.max(0, st.boostUntil - Date.now());
}

const STATE_KEY = "__goldpulse_engine";
const globalForEngine = globalThis as typeof globalThis & { [STATE_KEY]?: EngineState };

function state(): EngineState {
  if (!globalForEngine[STATE_KEY]) {
    globalForEngine[STATE_KEY] = {
      price: BASE_PRICE,
      lastTs: Date.now(),
      trend: 0,
      candles: { M5: [], M15: [], H1: [], H4: [] },
      spark: [],
      ticks: [],
      initialised: false,
      boostUntil: 0,
      boostDir: 1,
    };
  }
  return globalForEngine[STATE_KEY]!;
}

function seedHistory(st: EngineState) {
  const tfList: TF[] = ["M5", "M15", "H1", "H4"];
  for (const tf of tfList) {
    const count = 240;
    const vol = tf === "M5" ? 1.1 : tf === "M15" ? 1.9 : tf === "H1" ? 3.6 : 7.2;
    const out: Candle[] = [];
    let p = BASE_PRICE - gauss() * vol * 6;
    const start = st.lastTs - count * TF_MS[tf];
    for (let i = 0; i < count; i++) {
      const drift = (BASE_PRICE - p) * 0.006 + Math.sin(i / 17) * vol * 0.28 + Math.sin(i / 41) * vol * 0.5;
      const o = p;
      const c = p + drift + gauss() * vol * 0.9;
      const h = Math.max(o, c) + Math.abs(gauss()) * vol * 0.55;
      const l = Math.min(o, c) - Math.abs(gauss()) * vol * 0.55;
      out.push({ t: start + i * TF_MS[tf], o: r5(o), h: r5(h), l: r5(l), c: r5(c), v: Math.round(120 + Math.abs(gauss()) * 300) });
      p = c;
    }
    // normalise so the newest seeded close matches the live price
    const delta = BASE_PRICE - out[out.length - 1].c;
    for (const c of out) {
      c.o = r5(c.o + delta);
      c.h = r5(c.h + delta);
      c.l = r5(c.l + delta);
      c.c = r5(c.c + delta);
    }
    st.candles[tf] = out;
  }
  st.spark = st.candles.M5.slice(-90).map((c) => c.c);
}

export function r5(n: number) {
  return Math.round(n * 100000) / 100000;
}

function pushToBuckets(st: EngineState, price: number, ts: number, vol: number) {
  const tfList: TF[] = ["M5", "M15", "H1", "H4"];
  for (const tf of tfList) {
    const size = TF_MS[tf];
    const bucket = Math.floor(ts / size) * size;
    const arr = st.candles[tf];
    const cur = arr[arr.length - 1];
    if (!cur || cur.t < bucket) {
      arr.push({ t: bucket, o: r5(price), h: r5(price), l: r5(price), c: r5(price), v: 1 });
      if (arr.length > 260) arr.shift();
    } else {
      cur.h = Math.max(cur.h, r5(price));
      cur.l = Math.min(cur.l, r5(price));
      cur.c = r5(price);
      cur.v += Math.round(vol);
    }
  }
}

/** Advance the simulated gold feed up to `now`. Cheap enough for 1s polling. */
export function advance(now: number = Date.now()): EngineState {
  const st = state();
  if (!st.initialised) {
    st.lastTs = now - 2000;
    seedHistory(st);
    st.initialised = true;
  }
  const elapsed = Math.max(0, now - st.lastTs);
  const steps = Math.min(240, Math.max(1, Math.ceil(elapsed / 900)));
  const dt = elapsed / steps / 1000;
  const newsNow = activeNewsWindow(now);
  for (let i = 0; i < steps; i++) {
    const t = st.lastTs + (elapsed / steps) * i;
    const sess = sessionAt(new Date(t));
    // slow regime oscillator → creates realistic trending legs
    const boosted = st.boostUntil > t;
    st.trend += (0 - st.trend) * 0.0022 + gauss() * 0.055;
    const burst = newsNow && Math.abs(newsNow.minutesTo) < 12 ? 2.4 : 1;
    // drift in points/second, noise scaled by sqrt(seconds)
    const vol = 0.068 * sess.volatility * burst * (boosted ? 1.35 : 1);
    const driftPerSec = boosted
      ? st.boostDir * 0.026
      : (st.trend * 0.22 + (BASE_PRICE - st.price) * 0.00008) / 60;
    st.price = Math.max(3600, st.price + driftPerSec * dt + gauss() * vol * Math.sqrt(dt));
    pushToBuckets(st, st.price, t, Math.abs(gauss()) * 40 + 10);
  }
  st.lastTs = now;
  st.spark.push(r5(st.price));
  if (st.spark.length > 90) st.spark.shift();
  st.ticks.push({ t: now, p: r5(st.price), s: spreadFor(new Date(now), st.price) });
  if (st.ticks.length > 400) st.ticks.shift();
  return st;
}

export function engineView() {
  const st = advance();
  const indicators = {} as Record<TF, IndicatorSet>;
  (["M5", "M15", "H1", "H4"] as TF[]).forEach((tf) => {
    indicators[tf] = computeIndicators(st.candles[tf]);
  });
  return {
    price: st.price,
    candles: st.candles,
    indicators,
    spark: st.spark,
    ticks: st.ticks,
  };
}
