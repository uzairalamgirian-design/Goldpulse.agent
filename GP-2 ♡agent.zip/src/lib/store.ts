import { and, desc, eq, gte, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { appSettings, connections, signals } from "@/db/schema";
import { DEFAULT_SETTINGS, type Settings } from "@/lib/types";

export function maskSecret(value: string | null | undefined): string {
  if (!value) return "";
  const tail = value.slice(-4);
  return `${"•".repeat(12)}${tail}`;
}

export async function getSettings(): Promise<Settings> {
  const rows = await db.select().from(appSettings).where(eq(appSettings.key, "main"));
  if (!rows.length) return { ...DEFAULT_SETTINGS };
  const raw = rows[0].value as Partial<Settings>;
  return {
    ...DEFAULT_SETTINGS,
    ...raw,
    gates: { ...DEFAULT_SETTINGS.gates, ...(raw.gates ?? {}) },
    alerts: { ...DEFAULT_SETTINGS.alerts, ...(raw.alerts ?? {}) },
  };
}

export async function saveSettings(next: Settings): Promise<Settings> {
  await db
    .insert(appSettings)
    .values({ key: "main", value: next, updatedAt: new Date() })
    .onConflictDoUpdate({ target: appSettings.key, set: { value: next, updatedAt: new Date() } });
  return next;
}

const CONNECTION_SEED = [
  {
    id: "exness",
    kind: "exness",
    label: "Exness · Standard Cent",
    endpoint: "https://api.exness.com/v1/trading",
    account: "84 231 907",
    secretMasked: maskSecret("exness_demo_secret_key_9f4a"),
    symbol: "XAUUSDc",
    suffix: "c",
    status: "connected",
    enabled: true,
  },
  {
    id: "xm",
    kind: "xm",
    label: "XM · MT4/MT5 Bridge",
    endpoint: "https://bridge.xm-bridge.local/goldpulse",
    account: "5 108 4422",
    secretMasked: maskSecret("xm_webhook_token_77bd"),
    symbol: "XAUUSDm",
    suffix: "m",
    status: "standby",
    enabled: false,
  },
  {
    id: "sim",
    kind: "sim",
    label: "XAUUSD Live-Simulation Engine",
    endpoint: "internal://goldpulse-sim",
    account: "SIM-30",
    secretMasked: "",
    symbol: "XAUUSDc",
    suffix: "",
    status: "connected",
    enabled: true,
  },
];

export async function getConnections() {
  const existing = await db.select().from(connections);
  if (existing.length < CONNECTION_SEED.length) {
    for (const c of CONNECTION_SEED) {
      await db
        .insert(connections)
        .values({
          id: c.id,
          kind: c.kind,
          label: c.label,
          endpoint: c.endpoint,
          account: c.account,
          secretMasked: c.secretMasked,
          symbol: c.symbol,
          suffix: c.suffix,
          status: c.status,
          enabled: c.enabled,
          lastHeartbeat: new Date(),
          spread: "22",
          latencyMs: 38,
        })
        .onConflictDoNothing();
    }
    return db.select().from(connections);
  }
  return existing;
}

export async function updateConnection(id: string, patch: Record<string, unknown>) {
  await db
    .update(connections)
    .set(patch as Partial<typeof connections.$inferInsert>)
    .where(eq(connections.id, id));
  return getConnections();
}

export interface SignalRow {
  id: string;
  createdAt: Date;
  symbol: string;
  broker: string;
  accountMode: string;
  direction: string;
  score: string;
  entry: string;
  entryLow: string;
  entryHigh: string;
  sl: string;
  tp1: string;
  tp2: string;
  tp3: string;
  lotSize: string;
  riskUsd: string;
  rr: string;
  session: string;
  outcome: string;
  pnlUsd: string;
  gates: unknown;
  note: string | null;
}

export async function listSignals(): Promise<SignalRow[]> {
  return (await db.select().from(signals).orderBy(desc(signals.createdAt)).limit(200)) as SignalRow[];
}

export async function seedSignalsIfEmpty() {
  const existing = await db.select({ id: signals.id }).from(signals).limit(1);
  if (existing.length) return;
  const now = Date.now();
  const seed = [
    { d: 34, dir: "BUY", score: "99.910", entry: 4121.4, sl: 4118.9, tp1: 4126.4, tp2: 4127.65, tp3: 4130.15, lot: "0.02", risk: "0.50", rr: "2.50", outcome: "win", pnl: "1.25", session: "London / New York Overlap", note: "London breakout continuation · TP2 filled" },
    { d: 27, dir: "SELL", score: "99.902", entry: 4148.9, sl: 4151.7, tp1: 4143.3, tp2: 4141.9, tp3: 4139.1, lot: "0.02", risk: "0.56", rr: "2.50", outcome: "loss", pnl: "-0.56", session: "London Session", note: "Stopped on a USD headline spike" },
    { d: 19, dir: "BUY", score: "99.947", entry: 4102.15, sl: 4099.55, tp1: 4107.35, tp2: 4108.65, tp3: 4111.25, lot: "0.02", risk: "0.52", rr: "2.50", outcome: "win", pnl: "1.30", session: "New York Session", note: "H4 trend pullback into EMA21 · TP3 runner" },
    { d: 12, dir: "BUY", score: "99.901", entry: 4163.75, sl: 4161.05, tp1: 4169.15, tp2: 4170.5, tp3: 4173.2, lot: "0.02", risk: "0.54", rr: "2.50", outcome: "skipped", pnl: "0", session: "London / New York Overlap", note: "Skipped — spread widened past guard on the trigger" },
    { d: 5, dir: "SELL", score: "99.988", entry: 4188.6, sl: 4191.4, tp1: 4183.0, tp2: 4181.6, tp3: 4178.8, lot: "0.02", risk: "0.56", rr: "2.50", outcome: "win", pnl: "1.40", session: "London / New York Overlap", note: "Bearish engulfing at H1 supply · TP2 filled" },
    { d: 2, dir: "BUY", score: "99.931", entry: 4176.2, sl: 4173.4, tp1: 4181.8, tp2: 4183.2, tp3: 4186.0, lot: "0.02", risk: "0.56", rr: "2.50", outcome: "pending", pnl: "0", session: "London Session", note: "Open — managed manually at the desk" },
  ];
  for (const [i, s] of seed.entries()) {
    await db.insert(signals).values({
      id: `seed-${i}`,
      createdAt: new Date(now - s.d * 3_600_000),
      symbol: "XAUUSDc",
      broker: "Exness · Standard Cent",
      accountMode: "cent",
      direction: s.dir,
      score: s.score,
      entry: s.entry.toFixed(5),
      entryLow: (s.entry - 0.14).toFixed(5),
      entryHigh: (s.entry + 0.14).toFixed(5),
      sl: s.sl.toFixed(5),
      tp1: s.tp1.toFixed(5),
      tp2: s.tp2.toFixed(5),
      tp3: s.tp3.toFixed(5),
      lotSize: s.lot,
      riskUsd: s.risk,
      rr: s.rr,
      session: s.session,
      outcome: s.outcome,
      pnlUsd: s.pnl,
      note: s.note,
      gates: [],
    });
  }
}

export async function drawdownLock(settings: Settings) {
  const start = new Date();
  start.setUTCHours(0, 0, 0, 0);
  const rows = (await db
    .select()
    .from(signals)
    .where(and(gte(signals.createdAt, start), inArray(signals.outcome, ["win", "loss"])))
    .orderBy(desc(signals.createdAt))) as SignalRow[];

  const dayRows = (await db
    .select()
    .from(signals)
    .where(gte(signals.createdAt, start))) as SignalRow[];

  const dayPnl = dayRows.reduce((a, b) => a + Number(b.pnlUsd ?? 0), 0);
  const equity = settings.accountMode === "cent" ? settings.balance / 100 : settings.balance;
  const ddPct = equity > 0 ? Math.max(0, (-dayPnl / equity) * 100) : 0;

  let consecutiveLosses = 0;
  for (const r of rows) {
    if (r.outcome === "loss") consecutiveLosses += 1;
    else break;
  }

  if (consecutiveLosses >= settings.maxConsecutiveLosses) {
    return {
      locked: true,
      reason: `${consecutiveLosses} consecutive losses — alerts paused for the rest of the day`,
      dayPnl: Math.round(dayPnl * 100) / 100,
      ddPct: Math.round(ddPct * 100) / 100,
      consecutiveLosses,
    };
  }
  if (ddPct >= settings.dailyDrawdownPct) {
    return {
      locked: true,
      reason: `Daily drawdown ${ddPct.toFixed(1)}% reached the ${settings.dailyDrawdownPct}% lock`,
      dayPnl: Math.round(dayPnl * 100) / 100,
      ddPct: Math.round(ddPct * 100) / 100,
      consecutiveLosses,
    };
  }
  return {
    locked: false,
    reason: null,
    dayPnl: Math.round(dayPnl * 100) / 100,
    ddPct: Math.round(ddPct * 100) / 100,
    consecutiveLosses,
  };
}

export async function stats() {
  const rows = (await db.select().from(signals)) as SignalRow[];
  const closed = rows.filter((r) => r.outcome === "win" || r.outcome === "loss");
  const wins = closed.filter((r) => r.outcome === "win").length;
  const pnl = rows.reduce((a, b) => a + Number(b.pnlUsd ?? 0), 0);
  return {
    total: rows.length,
    closed: closed.length,
    wins,
    losses: closed.length - wins,
    winRate: closed.length ? Math.round((wins / closed.length) * 1000) / 10 : 0,
    netPnl: Math.round(pnl * 100) / 100,
    skipped: rows.filter((r) => r.outcome === "skipped").length,
  };
}

export async function logCount() {
  const r = await db.select({ c: sql<number>`count(*)::int` }).from(signals);
  return r[0]?.c ?? 0;
}
