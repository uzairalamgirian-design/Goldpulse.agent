import { buildAnalysis } from "./analysis";
import { activeNewsWindow, engineView, r5, sessionAt, spreadFor } from "./market";
import { candlePattern, TF_MS } from "./indicators";
import { computeRisk } from "./risk";
import type { Direction, Gate, NewsEvent, SessionInfo, Settings, Snapshot, TF, TradePlan } from "./types";

const clamp = (n: number, a = 0, b = 1) => Math.max(a, Math.min(b, n));
const r2 = (n: number) => Math.round(n * 100) / 100;
const pct = (n: number) => `${n.toFixed(1)}%`;

function gate(
  id: string,
  index: number,
  label: string,
  short: string,
  detail: string,
  state: Gate["state"],
  weight: number,
  contribution: number,
): Gate {
  return { id, index, label, short, detail, state, weight, contribution: Math.round(contribution * 1000) / 1000 };
}

export function buildSnapshot(
  settings: Settings,
  lock: { locked: boolean; reason: string | null } = { locked: false, reason: null },
  captureId?: string,
): Snapshot {
  const view = engineView();
  const now = Date.now();
  const date = new Date(now);
  const session = sessionAt(date);
  const spread = spreadFor(date, view.price);
  const news: NewsEvent | null = activeNewsWindow(now);

  const H4 = view.indicators.H4;
  const H1 = view.indicators.H1;
  const M15 = view.indicators.M15;
  const M5 = view.indicators.M5;

  /* ---------------- directional bias from H4 + H1 ---------------- */
  const bias = (i: typeof H4): number => {
    let s = 0;
    if (i.ema50 > i.ema200) s += 1;
    if (i.ema50 < i.ema200) s -= 1;
    if (i.structure === "HH-HL") s += 1;
    if (i.structure === "LH-LL") s -= 1;
    return s;
  };
  const b4 = bias(H4);
  const b1 = bias(H1);
  let direction: Direction | null = null;
  if (b4 >= 2 && b1 >= 1) direction = "BUY";
  else if (b4 <= -2 && b1 <= -1) direction = "SELL";
  const dirSign = direction === "BUY" ? 1 : direction === "SELL" ? -1 : 0;

  /* ------------------------- trade plan -------------------------- */
  const riskInput = {
    accountMode: settings.accountMode,
    balance: settings.balance,
    riskPct: settings.riskPct,
    maxRiskUsd: settings.maxRiskUsd,
    slDistance: 1,
    minLot: settings.minLot,
    lotStep: settings.lotStep,
    rr: 2.5,
    minRR: settings.minRR,
  };

  // Start from the ATR stop, then fit it to the smallest executable lot so a
  // $30 account is never asked to take a position it cannot survive.
  const atrStop = r2(Math.max(0.35, M15.atr * 1.25));
  const probe = computeRisk({ ...riskInput, slDistance: atrStop });
  let slDistance = atrStop;
  const tightened = probe.blocked && probe.maxSlForMinLot >= 0.3;
  if (tightened) slDistance = r2(Math.max(0.3, probe.maxSlForMinLot * 0.96));

  const risk = computeRisk({ ...riskInput, slDistance });
  const planWarnings = tightened
    ? [
        `ATR(14) implies a $${atrStop.toFixed(2)} stop — tightened to $${slDistance.toFixed(2)} so the ${settings.minLot.toFixed(2)} lot minimum stays inside your ${settings.riskPct.toFixed(1)}% risk budget.`,
        "A tighter stop needs a precise entry. Skip the trade if price has already left the entry zone.",
        ...risk.warnings,
      ]
    : risk.warnings;

  const entry = r5(view.price);
  const sl = r5(dirSign >= 0 ? entry - slDistance : entry + slDistance);
  const tp1 = r5(dirSign >= 0 ? entry + slDistance * 2 : entry - slDistance * 2);
  const tp2 = r5(dirSign >= 0 ? entry + slDistance * 2.5 : entry - slDistance * 2.5);
  const tp3 = r5(dirSign >= 0 ? entry + slDistance * 3.5 : entry - slDistance * 3.5);
  const zone = Math.max(0.08, M15.atr * 0.12);

  const plan: TradePlan | null = direction
    ? {
        direction,
        symbol: settings.symbol,
        entry,
        entryLow: r5(entry - zone),
        entryHigh: r5(entry + zone),
        sl,
        tp1,
        tp2,
        tp3,
        slDistance,
        rr1: 2,
        rr2: 2.5,
        rr3: 3.5,
        atr: r2(M15.atr),
        lotSize: risk.lot,
        riskUsd: risk.riskUsd,
        riskPct: risk.riskPct,
        rewardUsd1: risk.rewardUsd1,
        contractNote: risk.contractNote,
        blocked: risk.blocked,
        blockReason: risk.blockReason,
        warnings: planWarnings,
      }
    : null;

  /* --------------------------- gates ----------------------------- */
  const enabled = (id: string) => settings.gates[id] !== false;
  const g: Gate[] = [];

  // 1 — H4 higher-timeframe trend bias
  {
    const ok = direction !== null && Math.abs(b4) >= 2 && H4.adx >= 18;
    const conf = ok ? clamp(0.55 + (H4.adx - 18) / 26) : direction ? 0.25 : 0;
    g.push(
      gate(
        "h4",
        1,
        "Higher-Timeframe Trend Bias (H4)",
        "H4 BIAS",
        direction
          ? `H4 ${direction === "BUY" ? "HH/HL structure" : "LH/LL structure"} · EMA50 ${direction === "BUY" ? ">" : "<"} EMA200 · ADX ${H4.adx.toFixed(1)} · ${H4.structure}`
          : `H4 structure is ${H4.structure} — EMA50/200 conflict, no higher-timeframe bias`,
        ok ? "green" : direction ? "wait" : "wait",
        16,
        enabled("h4") ? 16 * conf : 0,
      ),
    );
  }

  // 2 — H1 trend + EMA stack
  {
    const e = H1;
    const stack =
      dirSign > 0
        ? [e.ema9 > e.ema21, e.ema21 > e.ema50, e.ema50 > e.ema200]
        : dirSign < 0
          ? [e.ema9 < e.ema21, e.ema21 < e.ema50, e.ema50 < e.ema200]
          : [false, false, false];
    const held = stack.filter(Boolean).length;
    const priceOk = dirSign > 0 ? view.price > e.ema50 : dirSign < 0 ? view.price < e.ema50 : false;
    const conf = dirSign ? clamp(held / 3) * 0.7 + (priceOk ? 0.3 : 0) : 0;
    g.push(
      gate(
        "h1",
        2,
        "H1 Trend & EMA 50/200 Alignment",
        "H1 TREND",
        dirSign
          ? `EMA9 ${e.ema9 > e.ema21 ? "above" : "below"} EMA21 · ${held}/3 stack legs held · price ${priceOk ? "on the trend side" : "wrong side"} of EMA50`
          : "H1 has no directional stack — waiting for structure to resolve",
        dirSign && held === 3 && priceOk ? "green" : "wait",
        16,
        enabled("h1") ? 16 * conf : 0,
      ),
    );
  }

  // 3 — M15 pullback into dynamic value
  {
    const dist = view.price - M15.ema21;
    const ratio = dist / Math.max(0.01, M15.atr);
    const side = ratio * dirSign;
    const inZone = dirSign !== 0 && side >= -1.5 && side <= 2.5;
    const alignOk = dirSign > 0 ? view.price > M15.ema50 : dirSign < 0 ? view.price < M15.ema50 : false;
    const conf = dirSign ? (inZone ? 0.7 : clamp(1 - Math.abs(side) / 5) * 0.35) + (alignOk ? 0.3 : 0) : 0;
    g.push(
      gate(
        "m15",
        3,
        "M15 Pullback to Dynamic Value Zone",
        "M15 PULLBACK",
        dirSign
          ? `Price ${Math.abs(dist) < 0.02 ? "inside" : `$${Math.abs(dist).toFixed(2)} ${dist * dirSign > 0 ? "above" : "below"}`} the EMA21 zone · ${side.toFixed(2)}×ATR on the trend side · ${alignOk ? "holding" : "losing"} the EMA50 floor`
          : "No pullback geometry until the H4/H1 bias resolves",
        inZone && alignOk ? "green" : "wait",
        14,
        enabled("m15") ? 14 * conf : 0,
      ),
    );
  }

  // 4 — M5 candlestick confirmation
  {
    const pat = candlePattern(view.candles.M5);
    const match = dirSign !== 0 && pat.dir === dirSign;
    const conf = match ? clamp(pat.strength) : dirSign ? 0.12 : 0;
    g.push(
      gate(
        "m5",
        4,
        "M5 Candlestick Confirmation",
        "M5 CANDLE",
        pat.dir ? `${pat.name} on the last closed M5 candle` : "Last M5 candle is indecision — no trigger candle",
        match ? "green" : "wait",
        12,
        enabled("m5") ? 12 * conf : 0,
      ),
    );
  }

  // 5 — Multi-indicator consensus
  {
    const ribbon =
      dirSign > 0
        ? [M15.ema9, M15.ema21, M15.ema50, M15.ema200].every((v, i, a) => i === 0 || a[i - 1] >= v)
        : dirSign < 0
          ? [M15.ema9, M15.ema21, M15.ema50, M15.ema200].every((v, i, a) => i === 0 || a[i - 1] <= v)
          : false;
    const rsiOk = dirSign > 0 ? M15.rsi >= 48 && M15.rsi <= 72 : dirSign < 0 ? M15.rsi >= 28 && M15.rsi <= 52 : false;
    // MACD line on the trend side of zero, with the histogram not rolling over
    const macdOk =
      dirSign > 0
        ? M15.macd > 0 && M15.macdHist > -Math.abs(M15.macd) * 0.6
        : dirSign < 0
          ? M15.macd < 0 && M15.macdHist < Math.abs(M15.macd) * 0.6
          : false;
    const adxOk = M15.adx > 22;
    const parts = [ribbon, rsiOk, macdOk, adxOk];
    const conf = dirSign ? parts.filter(Boolean).length / 4 : 0;
    g.push(
      gate(
        "indicators",
        5,
        "EMA Ribbon · RSI · MACD · ADX Consensus",
        "INDICATORS",
        `Ribbon ${ribbon ? "stacked" : "mixed"} · RSI ${M15.rsi.toFixed(1)}${rsiOk ? "" : " (outside band)"} · MACD hist ${M15.macdHist >= 0 ? "+" : ""}${M15.macdHist.toFixed(2)} · ADX ${M15.adx.toFixed(1)}${adxOk ? "" : " (< 22)"}`,
        conf === 1 ? "green" : "wait",
        18,
        enabled("indicators") ? 18 * conf : 0,
      ),
    );
  }

  // 6 — ATR volatility-adjusted R:R
  {
    const rr = plan ? 2.5 : 0;
    const ok = plan !== null && rr >= settings.minRR && slDistance > 0.25;
    g.push(
      gate(
        "rr",
        6,
        `ATR Stop Geometry · ${settings.minRR.toFixed(1)}:1 Minimum Reward`,
        "ATR R:R",
        plan
          ? `ATR(14) M15 = $${M15.atr.toFixed(2)} · SL $${slDistance.toFixed(2)} · TP2 at 1:${rr.toFixed(1)}`
          : "Waiting for a directional setup before measuring reward",
        ok ? "green" : "wait",
        10,
        enabled("rr") && ok ? 10 : 0,
      ),
    );
  }

  // 7 — Session / liquidity filter
  {
    const weight = 8;
    let conf = 0;
    let state: Gate["state"] = "wait";
    let detail = `${session.label} · ${session.liquidity} liquidity · UTC ${String(session.utcHour).padStart(2, "0")}:00`;
    if (session.id === "overlap") {
      conf = 1;
      state = "green";
      detail += " — peak gold liquidity, best fills";
    } else if (session.id === "london") {
      conf = 1;
      state = "green";
      detail += " — London open drive, deep books";
    } else if (session.id === "newyork") {
      conf = 1;
      state = "green";
      detail += " — US session, USD flows dominate gold";
    } else if (session.id === "rollover") {
      conf = 0;
      state = settings.sessionFilter ? "veto" : "wait";
      detail += " — rollover window, thin books";
    } else {
      conf = 0;
      state = "wait";
      detail += " — Asian range, prone to false breaks";
    }
    g.push(gate("session", 7, "Session & Liquidity Filter", "SESSION", detail, state, weight, enabled("session") ? weight * conf : 0));
  }

  // 8 — Gold market safety gates
  {
    const weight = 6;
    const spreadOk = spread <= 0.45;
    const newsOk = news === null;
    const lockOk = !lock.locked;
    const reasons: string[] = [];
    if (!spreadOk) reasons.push(`spread ${spread.toFixed(2)} above the 0.45 guard`);
    if (!newsOk) reasons.push(`${news!.title} in ${news!.minutesTo} min — news blackout`);
    if (!lockOk) reasons.push(lock.reason ?? "daily drawdown lock active");
    const ok = spreadOk && newsOk && lockOk;
    const conf = ok ? 1 : (spreadOk ? 0.4 : 0) * (newsOk ? 1 : 0.2);
    g.push(
      gate(
        "safety",
        8,
        "Spread Spike · USD News · Drawdown Lock",
        "SAFETY",
        ok
          ? `Spread ${spread.toFixed(2)} (${Math.round(spread * 100)} pts) · no high-impact USD event within 30 min · no drawdown lock`
          : `VETO: ${reasons.join(" · ")}`,
        ok ? "green" : "veto",
        weight,
        enabled("safety") && ok ? weight * conf : 0,
      ),
    );
  }

  const score = Math.round(g.reduce((a, b) => a + b.contribution, 0) * 1000) / 1000;
  const anyVeto = g.some((x) => x.state === "veto");
  const allGreen = g.every((x) => x.state === "green" || !enabled(x.id));
  const armed = !anyVeto && allGreen && score >= settings.threshold && direction !== null && plan !== null;

  const first = view.candles.M5[view.candles.M5.length - 2] ?? view.candles.M5[view.candles.M5.length - 1];
  const changeAbs = first ? view.price - first.o : 0;

  const analysis = buildAnalysis({
    snapshotId: captureId ?? `snap-${now.toString(36)}`,
    candles: view.candles,
    indicators: view.indicators,
    price: view.price,
    spread,
    settings,
    plan,
    session,
    direction,
  });

  return {
    ts: now,
    price: r5(view.price),
    bid: r5(view.price - spread / 2),
    ask: r5(view.price + spread / 2),
    spread: Math.round(spread * 1000) / 1000,
    changeAbs: Math.round(changeAbs * 100) / 100,
    changePct: first ? Math.round((changeAbs / first.o) * 10000) / 100 : 0,
    session,
    news,
    candles: view.candles,
    indicators: view.indicators,
    gates: g,
    score,
    armed,
    direction,
    plan,
    drawdownLocked: lock.locked,
    drawdownReason: lock.reason,
    heartbeat: now,
    spark: view.spark,
    analysis,
  };
}

export { pct, TF_MS };
export type { SessionInfo, TF };
