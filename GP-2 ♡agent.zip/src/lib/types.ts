export type TF = "M5" | "M15" | "H1" | "H4";

export interface Candle {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
}

export interface IndicatorSet {
  ema9: number;
  ema21: number;
  ema50: number;
  ema200: number;
  rsi: number;
  macd: number;
  macdSignal: number;
  macdHist: number;
  adx: number;
  atr: number;
  structure: "HH-HL" | "LH-LL" | "RANGE";
}

export type GateState = "green" | "wait" | "veto";

export interface Gate {
  id: string;
  index: number;
  label: string;
  short: string;
  detail: string;
  state: GateState;
  weight: number;
  contribution: number;
}

export type Direction = "BUY" | "SELL";

export interface TradePlan {
  direction: Direction;
  symbol: string;
  entry: number;
  entryLow: number;
  entryHigh: number;
  sl: number;
  tp1: number;
  tp2: number;
  tp3: number;
  slDistance: number;
  rr1: number;
  rr2: number;
  rr3: number;
  atr: number;
  lotSize: number;
  riskUsd: number;
  riskPct: number;
  rewardUsd1: number;
  contractNote: string;
  blocked: boolean;
  blockReason: string | null;
  warnings: string[];
}

export interface SessionInfo {
  id: "asian" | "london" | "overlap" | "newyork" | "rollover";
  label: string;
  liquidity: "low" | "medium" | "high";
  volatility: number;
  utcHour: number;
}

export interface NewsEvent {
  id: string;
  title: string;
  impact: "high" | "medium";
  at: number;
  minutesTo: number;
}

/* ---------------------- visual prediction model ---------------------- */

export interface GhostCandle {
  i: number;
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  note: string;
}

export interface PatternMark {
  id: string;
  name: string;
  tone: "bullish" | "bearish" | "neutral";
  at: number;
  price: number;
  note: string;
}

export interface SrLevel {
  id: string;
  price: number;
  kind: "support" | "resistance";
  strength: number;
  seenAgo: string;
  note: string;
}

export interface RiskReason {
  id: string;
  title: string;
  detail: string;
  severity: "high" | "medium" | "low";
  price: number | null;
}

export interface WinReason {
  id: string;
  text: string;
  urdu: string;
}

export interface RsiZone {
  state: "oversold" | "overbought" | "neutral";
  value: number;
  note: string;
}

export type Decision = "STRONG_BUY" | "STRONG_SELL" | "WAIT";

export interface ChartSnapshotAnalysis {
  snapshotId: string;
  capturedAt: number;
  pair: string;
  timeframe: string;
  brokerMode: "preview" | "xm";
  decision: Decision;
  headline: string;
  subline: string;
  winProb: number;
  lossProb: number;
  direction: Direction | null;
  entry: number;
  entryLow: number;
  entryHigh: number;
  sl: number;
  tp1: number;
  tp2: number;
  tp3: number;
  rr: number;
  lotSize: number;
  riskUsd: number;
  riskPct: number;
  rewardUsd: number;
  accountCurrency: "USD" | "USC";
  projection: GhostCandle[];
  targetPrice: number;
  patterns: PatternMark[];
  levels: SrLevel[];
  rsiZone: RsiZone;
  winReasons: WinReason[];
  riskReasons: RiskReason[];
  zones: Array<{ high: number; low: number; label: string }>;
  headlineNumbers: { entry: string; lot: string; sl: string; tp: string };
}

export interface Snapshot {
  ts: number;
  price: number;
  bid: number;
  ask: number;
  spread: number;
  changeAbs: number;
  changePct: number;
  session: SessionInfo;
  news: NewsEvent | null;
  candles: Record<TF, Candle[]>;
  indicators: Record<TF, IndicatorSet>;
  gates: Gate[];
  score: number;
  armed: boolean;
  direction: Direction | null;
  plan: TradePlan | null;
  drawdownLocked: boolean;
  drawdownReason: string | null;
  heartbeat: number;
  spark: number[];
  analysis: ChartSnapshotAnalysis;
}

export interface XmBridge {
  server: string;
  accountMode: "demo" | "real";
  accountNumber: string;
  symbol: string;
  feedUrl: string;
  connected: boolean;
  lastSync: number | null;
}

export interface Settings {
  threshold: number;
  alertThreshold: number;
  urgentAlerts: boolean;
  accountMode: "cent" | "standard";
  balance: number;
  riskPct: number;
  maxRiskUsd: number;
  minRR: number;
  cooldownMin: number;
  maxConsecutiveLosses: number;
  dailyDrawdownPct: number;
  broker: "exness" | "xm" | "sim";
  symbol: string;
  minLot: number;
  lotStep: number;
  gates: Record<string, boolean>;
  alerts: { push: boolean; sound: boolean; vibrate: boolean; wakeLock: boolean };
  newsFilter: boolean;
  spreadGuard: boolean;
  sessionFilter: boolean;
  mode: "preview" | "xm";
  xm: XmBridge;
}

export const DEFAULT_XM: XmBridge = {
  server: "XMGlobal-MT5 4",
  accountMode: "demo",
  accountNumber: "",
  symbol: "XAUUSDm",
  feedUrl: "",
  connected: false,
  lastSync: null,
};

export const DEFAULT_SETTINGS: Settings = {
  threshold: 99.9,
  alertThreshold: 85,
  urgentAlerts: true,
  accountMode: "cent",
  balance: 3000,
  riskPct: 2,
  maxRiskUsd: 1.5,
  minRR: 2.5,
  cooldownMin: 30,
  maxConsecutiveLosses: 2,
  dailyDrawdownPct: 10,
  broker: "sim",
  symbol: "XAUUSDc",
  minLot: 0.01,
  lotStep: 0.01,
  gates: {
    h4: true,
    h1: true,
    m15: true,
    m5: true,
    indicators: true,
    rr: true,
    session: true,
    safety: true,
  },
  alerts: { push: true, sound: true, vibrate: true, wakeLock: false },
  newsFilter: true,
  spreadGuard: true,
  sessionFilter: true,
  mode: "preview",
  xm: DEFAULT_XM,
};
