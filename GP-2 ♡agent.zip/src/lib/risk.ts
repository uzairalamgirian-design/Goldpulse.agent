export interface RiskInput {
  accountMode: "cent" | "standard";
  balance: number;
  riskPct: number;
  maxRiskUsd: number;
  slDistance: number;
  minLot: number;
  lotStep: number;
  rr: number;
  minRR: number;
}

export interface RiskResult {
  accountCurrency: "USD" | "USC";
  balanceLabel: string;
  equityUsd: number;
  riskBudgetUsd: number;
  riskBudgetLabel: string;
  lotExact: number;
  lot: number;
  lotBlocked: boolean;
  riskUsd: number;
  riskLabel: string;
  riskPct: number;
  rewardUsd1: number;
  maxSlForMinLot: number;
  contractNote: string;
  blocked: boolean;
  blockReason: string | null;
  warnings: string[];
}

const round = (n: number, dp: number) => Math.round(n * 10 ** dp) / 10 ** dp;

export function computeRisk(input: RiskInput): RiskResult {
  const cent = input.accountMode === "cent";
  const currency = cent ? "USC" : "USD";
  const equityUsd = cent ? input.balance / 100 : input.balance;
  const riskBudgetUsd = Math.min((equityUsd * input.riskPct) / 100, input.maxRiskUsd);
  const warnings: string[] = [];
  let blocked = false;
  let blockReason: string | null = null;

  const perLotPerDollar = 100; // 1.00 lot of XAUUSD = 100 oz → $1 move = $100
  const lotExact = input.slDistance > 0 ? riskBudgetUsd / (input.slDistance * perLotPerDollar) : 0;
  let lot = Math.floor(lotExact / input.lotStep) * input.lotStep;
  lot = round(lot, 4);
  let lotBlocked = false;

  if (lot < input.minLot) {
    lotBlocked = true;
    lot = input.minLot;
    warnings.push(
      `Broker minimum is ${input.minLot.toFixed(2)} lot — smaller size is not available on this account type.`,
    );
  }

  const riskUsd = round(lot * input.slDistance * perLotPerDollar, 2);
  const riskPct = equityUsd > 0 ? (riskUsd / equityUsd) * 100 : 0;
  const maxSlForMinLot = input.minLot > 0 ? riskBudgetUsd / (input.minLot * perLotPerDollar) : 0;

  if (riskPct > 5) {
    blocked = true;
    blockReason = `STOP TOO WIDE FOR ${input.minLot.toFixed(2)} LOT — ${riskPct.toFixed(2)}% of equity at risk. Hard cap is 5%.`;
  } else if (lotBlocked && riskPct > input.riskPct) {
    blocked = true;
    blockReason = `Minimum lot overshoots the ${input.riskPct.toFixed(2)}% risk budget (${riskPct.toFixed(2)}%). Skip this setup.`;
  } else if (lotBlocked) {
    warnings.push(`Minimum lot forces ${riskPct.toFixed(2)}% risk vs your ${input.riskPct.toFixed(2)}% target.`);
  }

  if (input.rr < input.minRR) {
    blocked = true;
    blockReason = `Risk-to-reward ${input.rr.toFixed(2)}R is below your ${input.minRR.toFixed(1)}R minimum.`;
  }

  if (input.slDistance < 0.3) {
    warnings.push("Stop is inside normal gold noise (< $0.30). Expect to be wicked out.");
    if (input.slDistance < 0.18) {
      blocked = true;
      blockReason = "Stop distance is smaller than the live spread — trade is not executable.";
    }
  }

  if (equityUsd < 20) warnings.push("Equity under $20 — a single standard lot step can exceed 5% risk.");
  if (input.riskPct > 3) warnings.push("Risk above 3% on a $30 account compounds drawdown very fast.");

  return {
    accountCurrency: currency,
    balanceLabel: cent ? `${(input.balance).toLocaleString("en-US", { minimumFractionDigits: 2 })} USC` : `$${input.balance.toFixed(2)}`,
    equityUsd,
    riskBudgetUsd: round(riskBudgetUsd, 2),
    riskBudgetLabel: cent
      ? `${(riskBudgetUsd * 100).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USC`
      : `$${riskBudgetUsd.toFixed(2)}`,
    lotExact: round(lotExact, 4),
    lot,
    lotBlocked,
    riskUsd,
    riskLabel: cent ? `${(riskUsd * 100).toFixed(2)} USC` : `$${riskUsd.toFixed(2)}`,
    riskPct: round(riskPct, 3),
    rewardUsd1: round(lot * input.slDistance * perLotPerDollar * input.rr, 2),
    maxSlForMinLot: round(maxSlForMinLot, 3),
    contractNote: cent
      ? `XAUUSDc · 1.00 lot = 100 oz · $1.00 price move = 10,000 USC`
      : `XAUUSD · 1.00 lot = 100 oz · $1.00 price move = $100.00`,
    blocked,
    blockReason,
    warnings: Array.from(new Set(warnings)),
  };
}
